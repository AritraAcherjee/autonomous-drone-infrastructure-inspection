from pathlib import Path
import subprocess,json,hashlib,sqlite3,sys,os,signal,time,re,struct
R=Path('/mnt/c/Dev/aegisinspect-p18-integration');E=R/'outputs/evidence/stop_b_p18_retry1_dashboard_completion';OLD=R/'outputs/evidence/stop_b_p18_first_integrated_run_retry1'
def read(p):return json.loads((E/p).read_text(encoding='utf-8-sig'))
def save(p,x):(E/p).write_text(json.dumps(x,indent=2)+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name in ['p18_dashboard_cleanup.ps1','p18_dashboard_finish.py']:(E/'browser'/name).write_bytes((Path('/tmp')/name).read_bytes())
browser_cmd=['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',r'C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_retry1_dashboard_completion\browser\p18_dashboard_cleanup.ps1']
browser=subprocess.run(browser_cmd,capture_output=True,text=True,timeout=30)
save('shutdown/browser_command.json',{'argv':browser_cmd,'exit_code':browser.returncode,'stdout':browser.stdout,'stderr':browser.stderr})
assert browser.returncode==0,browser.stderr
pid=read('dashboard/launch.json')['pid']
cmdline=Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\x00',b' ').decode()
assert 'streamlit run /mnt/c/Dev/aegisinspect-p18-integration/dashboard/app.py' in cmdline
assert os.getpgid(pid)==pid
os.killpg(pid,signal.SIGINT)
for _ in range(30):
 proc=Path(f'/proc/{pid}/stat')
 if not proc.exists() or proc.read_text().split()[2]=='Z':break
 time.sleep(.2)
else:raise RuntimeError('Dashboard did not stop')
sys.path.insert(0,str(OLD/'runtime/harness'))
from evidence import inventory
remaining=inventory();assert remaining['count']==0
save('shutdown/linux_processes.json',remaining)
save('shutdown/dashboard.json',{'pid':pid,'verified_cmdline':cmdline,'signal':'SIGINT','running_after_shutdown':False})

identity=read('database/identity.json')
assert sha(Path(identity['sealed_source']))==sha(Path(identity['dashboard_input']))==identity['source_sha256']
db=Path(identity['dashboard_input'])
c=sqlite3.connect(db.as_uri()+'?mode=ro&immutable=1',uri=True);c.row_factory=sqlite3.Row
data={t:[dict(r) for r in c.execute('SELECT * FROM '+t)] for t in ['structures','inspections','defects','evidence']};c.close()
assert data==read('database/readonly_query.json')['tables']
record=data['defects'][0];ev=data['evidence'][0]
body=read('dashboard/final_view_state.json')['text']
for text in [record['defect_id'],record['class_name'],repr(record['confidence']),record['review_status'],record['model_version'],'(3.889, 0.082, -0.041)','These fields are persisted machine output. They are not a human confirmation.']:
 assert text in body,text
assert re.search(r'Observation count:\s*1',body)
assert re.search(r'Current review status:\s*UNREVIEWED',body)
assert ev['defect_id']==record['defect_id'] and ev['confidence']==record['confidence']
assert Path(ev['image_path']).exists()
source_image_hash=sha(Path(ev['image_path']))
assert source_image_hash==json.loads((OLD/'provenance/lineage.json').read_text())['source_image']['sha256']
shots={}
for name in ['dashboard_overview_final.png','dashboard_detail.png','dashboard_overview.png']:
 p=E/'dashboard'/name;header=p.read_bytes()[:24];assert header[:8]==b'\x89PNG\r\n\x1a\n'
 shots[name]={'sha256':sha(p),'bytes':p.stat().st_size,'dimensions':list(struct.unpack('>II',header[16:24])),'preferred':name!='dashboard_overview.png'}
save('validation/screenshot_to_record.json',{'PASS':True,'record':record,'evidence':ev,'linked_source_image_sha256':source_image_hash,'dashboard_db_hash_unchanged':True,'sealed_db_hash_unchanged':True,'database_sha256':sha(db),'screenshots':shots,'visible_xyz':'(3.889, 0.082, -0.041)','exact_xyz':[record[k] for k in ['x_m','y_m','z_m']],'confidence_display':'0.026687312871217728','review_action_submitted':False,'visual_inspection':'Both preferred screenshots visually inspected: actual dashboard, all requested fields represented, clear machine-output/unreviewed language. Initial overview retained; final overview corrects partially clipped sidebar framing via ordinary viewport/scroll capture only.','unsupported_claims_present':False})
save('validation/apptest_reference.json',{'rerun':False,'accepted_prior_result':str(OLD/'p16/dashboard_apptest.json'),'sha256':sha(OLD/'p16/dashboard_apptest.json'),'PASS':json.loads((OLD/'p16/dashboard_apptest.json').read_text())['PASS']})
sources=read('validation/source_hashes_before.json')
assert all(sha(Path(p))==h for p,h in sources.items())
save('validation/source_hashes_after.json',sources)
manifest=OLD/'SHA256SUMS.txt'
assert sha(manifest)=='17e6f6964511a3200c77b14cb343513a64dfc4f63c79e6d965e07772561a243d'
for line in manifest.read_text().splitlines():
 h,p=line.split('  ',1);assert sha(OLD/p)==h,p
assert len(manifest.read_text().splitlines())==285
zip_sha=sha(R/'outputs/cache/stop_b_p18_first_integrated_run_retry1.zip')
assert zip_sha=='afdf4aa12d589c5984d637fcb122f6ef2a810cfa1111434e9135fee63f3d2f2d'
save('validation/sealed_retry_after.json',{'ORIGINAL_RETRY_PACKAGE_MODIFIED':'NO','artifact_count':285,'verified':285,'missing':0,'mismatches':0,'manifest_sha256':sha(manifest),'zip_sha256':zip_sha,'p17_report_sha256':sha(OLD/'p17/inspection_report.md')})
git={}
for args in [['rev-parse','--show-toplevel'],['branch','--show-current'],['rev-parse','HEAD'],['status','--short'],['diff','--check'],['diff','--cached','--check']]:
 p=subprocess.run(['git',*args],cwd=R,text=True,capture_output=True,check=True);git[' '.join(args)]={'stdout':p.stdout,'stderr':p.stderr,'exit_code':p.returncode}
assert git['status --short']['stdout']==''
assert git['rev-parse HEAD']['stdout'].strip()=='7b9ff556956c9c8995262515f53ff5382ffacf1b'
save('git/final_state.json',git)
safety={k:0 for k in ['NEW_P18_RUNTIME_ATTEMPTS','NEW_P13_START_CALLS','RESET_CALL_COUNT','NEW_DETECTOR_INFERENCE','NEW_P15_OBSERVATIONS','NEW_P16_INGESTION']}
save('validation/safety.json',safety)
diag=read('browser/windows_diagnosis.json')
probes=read('browser/wsl_cdp_probes.json')
assert diag['listeners'][0]['LocalAddress']=='127.0.0.1' and all(not p['success'] for p in probes)
save('browser/diagnosis.json',{'facts':['Windows Chrome PID '+str(diag['root_pid'])+' listens only on Windows 127.0.0.1:9241.','Windows-local /json/version succeeds.','WSL /json/version requests to 127.0.0.1 and Windows gateway 172.17.128.1 both return connection refused.','Windows localhost:8519 reaches the WSL-hosted dashboard; same-side Windows CDP automation rendered and captured it.','WSL has separate eth0 address 172.17.138.143/20, default gateway 172.17.128.1; no user .wslconfig is present.'],
 'best_supported_cause':'The previous WSL helper addressed Windows Chrome through WSL loopback. The reproduced Windows-loopback-only CDP listener is reachable on Windows but not through WSL loopback or the host gateway. Same-side Windows automation removes that cross-OS control connection.',
 'hypotheses_and_limits':['Observed topology is consistent with WSL NAT; no networking-mode command was available, so mode is inferred rather than reported as a direct query.','Firewall policy was not changed or attributed as the cause; listener/address evidence was sufficient.','Current connectivity reproduces the earlier failure pattern, not a historical packet trace of the consumed retry.'],
 'working_method':'Windows PowerShell .NET ClientWebSocket -> Windows Chrome CDP 127.0.0.1:9241; Chrome -> WSL Streamlit through localhost:8519 forwarding.',
 'production_changes':False,'network_configuration_changes':False,'astra_high_escalation_needed':False})
print(json.dumps({'PASS':True,'screenshots':shots,'database_unchanged':True,'sealed_retry_285_verified':True,'cleanup_residuals':0,'safety':safety},indent=2))
