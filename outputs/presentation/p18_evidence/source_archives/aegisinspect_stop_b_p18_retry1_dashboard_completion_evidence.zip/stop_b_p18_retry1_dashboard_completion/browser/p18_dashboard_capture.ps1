$ErrorActionPreference='Stop'
$root='C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_retry1_dashboard_completion'
$tabs=Invoke-RestMethod -Uri 'http://127.0.0.1:9241/json/list' -TimeoutSec 5
$tab=@($tabs | Where-Object {$_.type -eq 'page'})[0]
$socket=[System.Net.WebSockets.ClientWebSocket]::new()
$socket.ConnectAsync([Uri]$tab.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult()
$script:cdpId=0
$script:events=[Collections.Generic.List[object]]::new()
function Cdp([string]$method, $parameters=@{}) {
 $script:cdpId++
 $id=$script:cdpId
 $message=@{id=$id;method=$method;params=$parameters}|ConvertTo-Json -Depth 30 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($message)
 $socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
 while($true) {
  $stream=[IO.MemoryStream]::new()
  $buffer=[byte[]]::new(1048576)
  $cancel=[Threading.CancellationTokenSource]::new(20000)
  try {
   do {
    $received=$socket.ReceiveAsync([ArraySegment[byte]]::new($buffer),$cancel.Token).GetAwaiter().GetResult()
    $stream.Write($buffer,0,$received.Count)
   } while(-not $received.EndOfMessage)
  } finally {$cancel.Dispose()}
  $text=[Text.Encoding]::UTF8.GetString($stream.ToArray());$stream.Dispose()
  $item=$text|ConvertFrom-Json
  if($item.id -eq $id) {if($null -ne $item.error){throw ($item.error|ConvertTo-Json)};return $item.result}
  if($item.method -in @('Runtime.exceptionThrown','Network.loadingFailed','Network.webSocketFrameError')) {$script:events.Add($item)}
 }
}
try {
 Cdp 'Page.enable' | Out-Null
 Cdp 'Runtime.enable' | Out-Null
 Cdp 'Network.enable' | Out-Null
 $version=Cdp 'Browser.getVersion'
 Cdp 'Emulation.setDeviceMetricsOverride' @{width=1920;height=2000;deviceScaleFactor=1;mobile=$false} | Out-Null
 Cdp 'Page.navigate' @{url='http://127.0.0.1:8519'} | Out-Null
 $required=@('P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd','0.026687312871217728','Honeycombing','UNREVIEWED','DET-FINAL-v1','Observation count:','Map XYZ (m):','Current review status:','Evidence')
 $ready=$false
 $deadline=[DateTime]::UtcNow.AddSeconds(50)
 do {
  $response=Cdp 'Runtime.evaluate' @{expression='document.body.innerText';returnByValue=$true}
  $body=$response.result.value
  $missing=@($required | Where-Object {-not $body.Contains($_)})
  if($missing.Count -eq 0){$ready=$true;break}
  Start-Sleep -Milliseconds 400
 } while([DateTime]::UtcNow -lt $deadline)
 [IO.File]::WriteAllText("$root\dashboard\visible_text.txt",$body,[Text.UTF8Encoding]::new($false))
 if(-not $ready){throw ('Dashboard missing: '+($missing -join ', '))}
 Cdp 'Runtime.evaluate' @{expression='document.fonts.ready';awaitPromise=$true;returnByValue=$true} | Out-Null
 Start-Sleep -Milliseconds 500
 $dom=Cdp 'Runtime.evaluate' @{expression='document.documentElement.outerHTML';returnByValue=$true}
 [IO.File]::WriteAllText("$root\dashboard\browser_dom.html",$dom.result.value,[Text.UTF8Encoding]::new($false))
 $layout=Cdp 'Page.getLayoutMetrics'
 $shot=Cdp 'Page.captureScreenshot' @{format='png';captureBeyondViewport=$true;fromSurface=$true}
 [IO.File]::WriteAllBytes("$root\dashboard\dashboard_overview.png",[Convert]::FromBase64String($shot.data))
 Cdp 'Emulation.setDeviceMetricsOverride' @{width=1600;height=1100;deviceScaleFactor=1;mobile=$false} | Out-Null
 Cdp 'Runtime.evaluate' @{expression="Array.from(document.querySelectorAll('h3')).find(e=>e.innerText.includes('AI suggestion')).scrollIntoView({block:'start'})";returnByValue=$true} | Out-Null
 Start-Sleep -Milliseconds 500
 $detail=Cdp 'Page.captureScreenshot' @{format='png';captureBeyondViewport=$false;fromSurface=$true}
 [IO.File]::WriteAllBytes("$root\dashboard\dashboard_detail.png",[Convert]::FromBase64String($detail.data))
 @{PASS=$true;utc=[DateTime]::UtcNow.ToString('o');browser_side='Windows';automation_side='Windows PowerShell .NET ClientWebSocket';endpoint=$tab.webSocketDebuggerUrl;dashboard_url='http://127.0.0.1:8519';browser_version=$version;required_text=$required;layout=$layout;events=$script:events;capture_method='Native Chrome Page.captureScreenshot; actual existing dashboard; no DOM content or pixel edits; viewport resize and ordinary scrolling only';review_submitted=$false;screenshots=@('dashboard_overview.png','dashboard_detail.png')} | ConvertTo-Json -Depth 30 | Set-Content -Encoding UTF8 "$root\browser\capture_result.json"
 Get-Content "$root\browser\capture_result.json" -Raw
} finally {$socket.Dispose()}
