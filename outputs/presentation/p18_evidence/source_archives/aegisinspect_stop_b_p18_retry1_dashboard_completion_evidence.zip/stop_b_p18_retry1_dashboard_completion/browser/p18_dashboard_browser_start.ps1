$ErrorActionPreference='Stop'
$root='C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_retry1_dashboard_completion'
$chrome='C:\Program Files\Google\Chrome\Application\chrome.exe'
$profile='C:\Dev\aegisinspect-p18-integration\outputs\cache\p18_dashboard_completion_profile'
$argsList=@('--headless=new','--no-first-run','--no-default-browser-check',"--user-data-dir=$profile",'--disable-gpu','--hide-scrollbars','--window-size=1920,2200','--remote-debugging-port=9241','about:blank')
$before=@(Get-NetTCPConnection -LocalPort 9241 -ErrorAction SilentlyContinue)
if ($before.Count -ne 0) { throw 'Port 9241 is not free' }
$proc=Start-Process -FilePath $chrome -ArgumentList $argsList -PassThru -RedirectStandardOutput "$root\browser\chrome_stdout.txt" -RedirectStandardError "$root\browser\chrome_stderr.txt"
$version=$null
for ($i=0;$i -lt 40;$i++) {
  try { $version=Invoke-RestMethod -Uri 'http://127.0.0.1:9241/json/version' -TimeoutSec 2; break } catch { Start-Sleep -Milliseconds 250 }
}
$listeners=@(Get-NetTCPConnection -LocalPort 9241 -State Listen -ErrorAction SilentlyContinue | Select-Object LocalAddress,LocalPort,State,OwningProcess)
$config=Join-Path $env:USERPROFILE '.wslconfig'
$processes=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'chrome.exe' -and $_.CommandLine -and $_.CommandLine.Contains($profile) } | Select-Object ProcessId,ParentProcessId,CommandLine)
$dashboardProbe=$null
try {$dashboardProbe=@{success=$true;response=(Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8519/_stcore/health' -TimeoutSec 5).Content}} catch {$dashboardProbe=@{success=$false;error=$_.Exception.Message}}
@{utc=[DateTime]::UtcNow.ToString('o');browser_side='Windows';automation_side='Windows PowerShell';chrome_path=$chrome;arguments=$argsList;root_pid=$proc.Id;listeners=$listeners;version=$version;processes=$processes;wslconfig_exists=(Test-Path $config);wslconfig_path=$config;wslconfig=$(if(Test-Path $config){Get-Content $config -Raw}else{$null});dashboard_probe=$dashboardProbe} | ConvertTo-Json -Depth 20 | Set-Content -Encoding UTF8 "$root\browser\windows_diagnosis.json"
if($null -eq $version){throw 'Windows-local CDP probe failed'}
Get-Content "$root\browser\windows_diagnosis.json" -Raw
