from pathlib import Path
import hashlib,json,sqlite3,subprocess,datetime,os
R=Path('/mnt/c/Dev/aegisinspect-p18-integration')
OLD=R/'outputs/evidence/stop_b_p18_first_integrated_run_retry1'
E=R/'outputs/evidence/stop_b_p18_retry1_dashboard_completion'
assert not E.exists()
for sub in ['dashboard','database','browser','validation','git','shutdown']:(E/sub).mkdir(parents=True,exist_ok=True)
def save(rel,x):(E/rel).write_text(json.dumps(x,indent=2)+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(args):
 p=subprocess.run(args,cwd=R,capture_output=True,text=True,timeout=30)
 return {'command':args,'code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
git={str(a):run(['git',*a]) for a in [['rev-parse','--show-toplevel'],['branch','--show-current'],['rev-parse','HEAD'],['status','--short'],['diff','--check']]}
assert git[str(['rev-parse','HEAD'])]['stdout'].strip()=='7b9ff556956c9c8995262515f53ff5382ffacf1b'
# The only untracked path is the newly created supplemental evidence directory.
status=git[str(['status','--short'])]['stdout']
assert not status or status.strip()=='?? outputs/evidence/stop_b_p18_retry1_dashboard_completion/'
save('git/initial_state.json',git)
exclude=Path(subprocess.check_output(['git','rev-parse','--git-path','info/exclude'],cwd=R,text=True).strip())
if not exclude.is_absolute():exclude=R/exclude
entry='/outputs/evidence/stop_b_p18_retry1_dashboard_completion/'
if entry not in exclude.read_text().splitlines():
 with exclude.open('a') as f:f.write('\n'+entry+'\n')
save('git/evidence_exclusion.json',{'local_metadata_only':str(exclude),'added_entry':entry,'production_source_changed':False})
expected_manifest='17e6f6964511a3200c77b14cb343513a64dfc4f63c79e6d965e07772561a243d'
assert sha(OLD/'SHA256SUMS.txt')==expected_manifest
entries=(OLD/'SHA256SUMS.txt').read_text().splitlines()
assert len(entries)==285
for line in entries:
 h,p=line.split('  ',1);assert sha(OLD/p)==h,p
zip_path=R/'outputs/cache/stop_b_p18_first_integrated_run_retry1.zip'
assert sha(zip_path)=='afdf4aa12d589c5984d637fcb122f6ef2a810cfa1111434e9135fee63f3d2f2d'
save('validation/sealed_retry_before.json',{'count':285,'PASS':True,'manifest_sha256':expected_manifest,'zip_sha256':sha(zip_path)})
db=OLD/'p16/p18.sqlite3'
conn=sqlite3.connect(db.as_uri()+'?mode=ro&immutable=1',uri=True);conn.row_factory=sqlite3.Row
data={t:[dict(r) for r in conn.execute('SELECT * FROM '+t)] for t in ['structures','inspections','defects','evidence']};conn.close()
record=data['defects'][0]
assert len(data['defects'])==len(data['evidence'])==1
assert record['defect_id']=='P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd'
assert record['confidence']==0.026687312871217728
assert [record[k] for k in ['x_m','y_m','z_m']]==[3.888778309118922,0.08248358558866703,-0.041401481379500414]
assert record['class_name']=='Honeycombing' and record['observation_count']==1 and record['review_status']=='UNREVIEWED'
assert data['evidence'][0]['defect_id']==record['defect_id']
copy=E/'database/frozen_retry.sqlite3';copy.write_bytes(db.read_bytes());copy.chmod(0o444)
assert sha(copy)==sha(db)=='9bf9b16dda29d8435e27982e60a64b936aae7799f86095d812565a5c8354bbdf'
save('database/readonly_query.json',{'connection':'file URI mode=ro&immutable=1','tables':data})
save('database/identity.json',{'sealed_source':str(db),'dashboard_input':str(copy),'source_sha256':sha(db),'served_copy_sha256':sha(copy),'copy_method':'byte-for-byte; no ingestion; original artifact never opened by dashboard','requested_mode':'0444','actual_mode':oct(copy.stat().st_mode&0o777)})
save('browser/network_before.json',{'addresses':run(['ip','-brief','address']),'routes':run(['ip','route']),'listeners':run(['ss','-ltnp'])})
save('validation/source_hashes_before.json',{str(p):sha(p) for p in [R/'dashboard/app.py',R/'dashboard/components.py',R/'src/storage/repository.py',R/'src/storage/service.py',OLD/'p17/inspection_report.md']})
save('validation/model_usage.json',{'requested_model':'GPT-6 Astra Medium','requested_reasoning':'Medium','actual_model':'Current Codex session; exact model identity not exposed by callable tools','actual_reasoning':'Not exposed','model_changed':False,'limitation':'No in-session model switching tool is available; no model transition is claimed.'})
print(json.dumps({'prepared':str(E),'database_sha256':sha(db),'readonly_record':record},indent=2))
