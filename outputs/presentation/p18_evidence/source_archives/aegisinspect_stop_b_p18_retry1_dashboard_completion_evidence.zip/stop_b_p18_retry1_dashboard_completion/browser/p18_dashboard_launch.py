from pathlib import Path
import subprocess,json,os,time,urllib.request
R=Path('/mnt/c/Dev/aegisinspect-p18-integration')
E=R/'outputs/evidence/stop_b_p18_retry1_dashboard_completion'
def save(rel,x):(E/rel).write_text(json.dumps(x,indent=2)+'\n')
for src in ['p18_dashboard_prepare.py','p18_dashboard_browser_start.ps1','p18_dashboard_launch.py']:
 (E/'browser'/src).write_bytes((Path('/tmp')/src).read_bytes())
env=os.environ.copy();env['AEGISINSPECT_DB_PATH']=str(E/'database/frozen_retry.sqlite3');env['PYTHONDONTWRITEBYTECODE']='1'
argv=['/tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python','-B','-m','streamlit','run',str(R/'dashboard/app.py'),'--server.address=127.0.0.1','--server.port=8519','--server.headless=true','--server.fileWatcherType=none','--browser.gatherUsageStats=false']
with (E/'dashboard/server.log').open('wb') as log:
 p=subprocess.Popen(argv,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
save('dashboard/launch.json',{'argv':argv,'pid':p.pid,'pgid':p.pid,'db':env['AEGISINSPECT_DB_PATH'],'production_source_modified':False})
for _ in range(50):
 try:
  with urllib.request.urlopen('http://127.0.0.1:8519/_stcore/health',timeout=1) as r:assert r.read()==b'ok'
  break
 except OSError:time.sleep(.2)
else:raise RuntimeError('Dashboard health failed')
cmd=['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File','C:\\Dev\\aegisinspect-p18-integration\\outputs\\evidence\\stop_b_p18_retry1_dashboard_completion\\browser\\p18_dashboard_browser_start.ps1']
x=subprocess.run(cmd,capture_output=True,text=True,timeout=45)
save('browser/windows_launch_command.json',{'argv':cmd,'code':x.returncode,'stdout':x.stdout,'stderr':x.stderr})
assert x.returncode==0,x.stderr
results=[]
for host in ['127.0.0.1','172.17.128.1']:
 url=f'http://{host}:9241/json/version'
 try:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  with opener.open(url,timeout=2) as r:results.append({'url':url,'success':True,'body':r.read().decode()})
 except Exception as exc:results.append({'url':url,'success':False,'error':repr(exc)})
save('browser/wsl_cdp_probes.json',results)
print(json.dumps({'dashboard_pid':p.pid,'windows':json.loads((E/'browser/windows_diagnosis.json').read_text(encoding='utf-8-sig')),'wsl_probes':results},indent=2))
