$ErrorActionPreference='Stop'
$root='C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_retry1_dashboard_completion'
$tabs=Invoke-RestMethod -Uri 'http://127.0.0.1:9241/json/list' -TimeoutSec 5
$tab=@($tabs | Where-Object {$_.type -eq 'page'})[0]
$socket=[System.Net.WebSockets.ClientWebSocket]::new()
$socket.ConnectAsync([Uri]$tab.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult()
$script:cdpId=0
$script:events=[Collections.Generic.List[object]]::new()
function Cdp([string]$method, $parameters=@{}) {
 $script:cdpId++
 $id=$script:cdpId
 $message=@{id=$id;method=$method;params=$parameters}|ConvertTo-Json -Depth 30 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($message)
 $socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
 while($true) {
  $stream=[IO.MemoryStream]::new()
  $buffer=[byte[]]::new(1048576)
  $cancel=[Threading.CancellationTokenSource]::new(20000)
  try {
   do {
    $received=$socket.ReceiveAsync([ArraySegment[byte]]::new($buffer),$cancel.Token).GetAwaiter().GetResult()
    $stream.Write($buffer,0,$received.Count)
   } while(-not $received.EndOfMessage)
  } finally {$cancel.Dispose()}
  $text=[Text.Encoding]::UTF8.GetString($stream.ToArray());$stream.Dispose()
  $item=$text|ConvertFrom-Json
  if($item.id -eq $id) {if($null -ne $item.error){throw ($item.error|ConvertTo-Json)};return $item.result}
  if($item.method -in @('Runtime.exceptionThrown','Network.loadingFailed','Network.webSocketFrameError')) {$script:events.Add($item)}
 }
}
try {
 Cdp 'Page.enable' | Out-Null
 Cdp 'Emulation.setDeviceMetricsOverride' @{width=1600;height=1900;deviceScaleFactor=1;mobile=$false} | Out-Null
 Cdp 'Runtime.evaluate' @{expression='document.querySelector("[data-testid=stMain]").scrollTo(0,0)';returnByValue=$true} | Out-Null
 Start-Sleep -Seconds 2
 $shot=Cdp 'Page.captureScreenshot' @{format='png';captureBeyondViewport=$false;fromSurface=$true}
 [IO.File]::WriteAllBytes("$root\dashboard\dashboard_overview_final.png",[Convert]::FromBase64String($shot.data))
 $state=Cdp 'Runtime.evaluate' @{expression='JSON.stringify({text:document.body.innerText,mainScrollTop:document.querySelector("[data-testid=stMain]").scrollTop,viewport:[innerWidth,innerHeight]})';returnByValue=$true}
 [IO.File]::WriteAllText("$root\dashboard\final_view_state.json",$state.result.value,[Text.UTF8Encoding]::new($false))
} finally {$socket.Dispose()}
