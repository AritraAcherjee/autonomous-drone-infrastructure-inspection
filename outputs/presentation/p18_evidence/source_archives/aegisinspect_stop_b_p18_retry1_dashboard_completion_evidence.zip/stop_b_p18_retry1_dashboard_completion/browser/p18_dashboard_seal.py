from pathlib import Path
import json,hashlib,subprocess,shlex,datetime
R=Path('/mnt/c/Dev/aegisinspect-p18-integration');E=R/'outputs/evidence/stop_b_p18_retry1_dashboard_completion'
def load(p):return json.loads((E/p).read_text(encoding='utf-8-sig'))
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert not (E/'SHA256SUMS.txt').exists()
(E/'browser/p18_dashboard_seal.py').write_bytes(Path('/tmp/p18_dashboard_seal.py').read_bytes())
record=load('validation/screenshot_to_record.json')
identity=load('database/identity.json')
launch=load('dashboard/launch.json')
model=load('validation/model_usage.json')
shotrows='\n'.join(f"| [{name}](dashboard/{name}) | {' × '.join(map(str,v['dimensions']))} | `{v['sha256']}` |" for name,v in record['screenshots'].items())
report=f'''# P18 DASHBOARD EVIDENCE COMPLETION — PASS

The missing browser evidence is complete. Real Windows Chrome screenshots show the unchanged P16 dashboard loaded from a byte-identical copy of the accepted retry database. Screenshot text, persisted record, evidence linkage, and database hashes match. No upstream scientific pipeline, ingestion, inference, START or RESET was run. The sealed retry package remains unchanged.

## A. Model usage

MODEL_USED = Current Codex session; exact active model identity is not exposed by the available controls.

REASONING_LEVEL = Not exposed by the available controls.

The requested setting was GPT-6 Astra Medium, followed by Sol Medium or Terra after diagnosis. No in-session model-switch tool is available, so that transition could not be performed and is not claimed. All work remained in the current session. No Astra High/Extreme High escalation was made or needed: the listener and connection evidence was consistent. See [validation/model_usage.json](validation/model_usage.json).

## B. Browser/CDP diagnosis

Observed facts:

- Chrome ran on **Windows**, root PID **49688**, version `153.0.8010.48`, isolated profile `C:\\Dev\\aegisinspect-p18-integration\\outputs\\cache\\p18_dashboard_completion_profile`.
- Windows TCP inspection showed Chrome listening only on **Windows `127.0.0.1:9241`**.
- Windows PowerShell successfully retrieved `/json/version` on that listener.
- Direct WSL HTTP probes to both `127.0.0.1:9241` and Windows gateway `172.17.128.1:9241` returned connection refused.
- WSL had `eth0=172.17.138.143/20` and default gateway `172.17.128.1`; no user `.wslconfig` existed. This is consistent with NAT topology; networking mode is an inference because the direct mode-query utility was unavailable.
- Windows successfully retrieved `http://127.0.0.1:8519/_stcore/health` from the WSL Streamlit server through localhost forwarding.
- Windows-side CDP WebSocket automation then rendered and captured the real dashboard successfully.

Best-supported cause: the previous helper ran in WSL and treated a Windows-loopback Chrome CDP endpoint as WSL loopback. Current probes reproduce that address/OS mismatch. The Windows-only loopback listener is not reachable through either tested WSL address. These are current reproduction facts, not a historical packet capture of the consumed retry. No firewall cause was assumed, and no firewall, forwarding or network configuration was changed.

Chosen method: **Windows Chrome + Windows PowerShell .NET ClientWebSocket automation**. Both browser control endpoints stayed on Windows loopback. Chrome loaded the real WSL dashboard through the already-working localhost forwarding path. No browser installation, dashboard patch, or networking workaround was required.

Evidence: [browser/windows_diagnosis.json](browser/windows_diagnosis.json), [browser/wsl_cdp_probes.json](browser/wsl_cdp_probes.json), [browser/network_before.json](browser/network_before.json), [browser/diagnosis.json](browser/diagnosis.json), and [browser/capture_result.json](browser/capture_result.json).

The initial Python wrapper waiting for the Windows diagnostic process timed out after 45 seconds even though the Windows diagnostic JSON had already been written and local CDP was working. An independent probe confirmed the existing browser listener. That browser was reused; it was not relaunched. This wrapper observation is recorded in [browser/launch_wrapper_note.json](browser/launch_wrapper_note.json).

## C. Dashboard and screenshots

Dashboard working directory: `/mnt/c/Dev/aegisinspect-p18-integration`.

Exact input environment:

```text
AEGISINSPECT_DB_PATH={identity['dashboard_input']}
PYTHONDONTWRITEBYTECODE=1
```

Exact command:

```bash
{shlex.join(launch['argv'])}
```

Dashboard PID: `{launch['pid']}`. Health check, real browser rendering and browser text readiness passed. Existing production `dashboard/app.py` and storage code were not changed. The dashboard's schema initialization uses existing `CREATE ... IF NOT EXISTS` statements; no schema or data change occurred. No review form was submitted.

Frozen source database: `{identity['sealed_source']}`.

Served database copy: `{identity['dashboard_input']}`.

Both before and after capture, their SHA-256 was identical:

`{identity['source_sha256']}`

The copy was made byte-for-byte, without import, ingestion or SQL writes. It was write-protected before launch (DrvFs reports mode `0555`, with no write bits, after requesting `0444`). The sealed database was queried only with SQLite URI `mode=ro&immutable=1`, and the dashboard never opened that original file. Full before/after table equality was independently verified.

Preferred screenshots: **dashboard_overview_final.png** and **dashboard_detail.png**. They were visually inspected. The overview shows the inspection context, low-confidence warning, record table, machine-output details, evidence row and UNREVIEWED status. The detail shows the record fields and evidence/review area at a larger readable scale.

| Native browser screenshot | Pixels | SHA-256 |
| --- | --- | --- |
{shotrows}

The initial `dashboard_overview.png` is retained for transparency; its sidebar framing was partially clipped. The final overview uses a stable 1600 × 1900 viewport and ordinary scrolling to the top. Screenshots are unedited native `Page.captureScreenshot` outputs. No synthetic HTML, generated image, DOM content alteration, CSS injection, or pixel editing was used. Only viewport sizing and normal scrolling changed presentation.

Capture scripts/commands, stdout/stderr, DOM and visible text are preserved under `browser/` and `dashboard/`. Capture scripts used .NET CDP on Windows, with no production-source change.

## D. Record validation

| Field | Frozen value |
| --- | --- |
| P15 ID | `P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd` |
| Detector class | Honeycombing |
| Confidence | `0.026687312871217728` |
| Map X | `3.888778309118922` m |
| Map Y | `0.08248358558866703` m |
| Map Z | `-0.041401481379500414` m |
| Frame | map |
| Observation count | 1 |
| Review | UNREVIEWED |
| Model | DET-FINAL-v1 |
| Observation time | 28.678 s ROS simulation time |
| Stored timestamp | `1970-01-01T00:00:28.678000Z` |

The UI detail faithfully rounds XYZ to `(3.889, 0.082, -0.041)`; the exact underlying values remain in [database/readonly_query.json](database/readonly_query.json) and [validation/screenshot_to_record.json](validation/screenshot_to_record.json). Full confidence is visible without masking its low value. The screenshot's evidence row links the same defect ID, source frame `camera_optical_frame`, timestamp, confidence, bbox and original retry image path. The linked image hash matches the accepted lineage.

The dashboard explicitly labels this as machine output, separates human review, and states that no physical-defect confirmation, engineering diagnosis or structural-safety conclusion is asserted. No severity, dimensions, repair urgency or recommendation was added. Existing inspection status `PROCESSING` and completed timestamp `N/A` were preserved as stored; they were not changed merely for presentation.

Accepted AppTest remains PASS and was not rerun: [validation/apptest_reference.json](validation/apptest_reference.json). P17 was not regenerated. Its accepted report hash remains `e2d35168e078f39992cdab5bec918481c5642ec43918285e500113805c8a6ed8`.

## E. Scientific safety and cleanup

```text
NEW_P18_RUNTIME_ATTEMPTS = 0
NEW_P13_START_CALLS = 0
RESET_CALL_COUNT = 0
NEW_DETECTOR_INFERENCE = 0
NEW_P15_OBSERVATIONS = 0
NEW_P16_INGESTION = 0
```

Only the dashboard, isolated browser, browser automation and read-only validation were run. Gazebo/P13/localization/ICP/detector/depth/projection/P15 runtime were not launched. The already-consumed retry accounting remains historical START=1, RESET=0; this task adds zero.

Chrome was closed via CDP `Browser.close`. The exact dashboard process group received SIGINT and stopped. Final inventories show zero relevant Linux processes, zero owned Chrome processes, and zero owned Windows screenshot-helper processes. See `shutdown/`. Parameter_bridge was not reopened or involved.

## F. Repository and supplemental integrity

Worktree `/mnt/c/Dev/aegisinspect-p18-integration`, branch `P18/full-integration`, HEAD `7b9ff556956c9c8995262515f53ff5382ffacf1b` throughout. Worktree CLEAN, no staged source, both diff checks PASS, no commit/merge/push. Dashboard/storage/report hashes are unchanged. The only repository metadata addition was an exact local `info/exclude` entry for this generated evidence directory; it is not a production-source change.

Supplemental directory: `outputs/evidence/stop_b_p18_retry1_dashboard_completion/`.

All supplemental artifacts except `SHA256SUMS.txt` itself are hashed in [SHA256SUMS.txt](SHA256SUMS.txt). Verification runs `sha256sum --check --quiet SHA256SUMS.txt` from this directory. The resulting count/status and manifest hash are recorded outside the sealed directory in `outputs/cache/stop_b_p18_retry1_dashboard_completion.seal.json` to avoid a self-referential manifest.

## G. Sealed retry preservation

ORIGINAL_RETRY_PACKAGE_MODIFIED = NO.

Original manifest: **285/285 PASS, 0 missing, 0 mismatches**, checked before and after dashboard capture.

Original manifest SHA-256 remains:

`17e6f6964511a3200c77b14cb343513a64dfc4f63c79e6d965e07772561a243d`

Accepted retry ZIP SHA-256 remains:

`afdf4aa12d589c5984d637fcb122f6ef2a810cfa1111434e9135fee63f3d2f2d`

The historical retry report and its BLOCKED classification were not rewritten. This separate PASS classifies only completion of the missing dashboard evidence. No new integrated-run result was manufactured.

**STOP AND RETURN TO 00.** No additional P18 runtime, repeatability, freeze or canonical merge was performed.
'''
(E/'REPORT.md').write_text(report)
result={'classification':'P18 DASHBOARD EVIDENCE COMPLETION — PASS','frozen_database_used':True,'database_unchanged':True,'real_browser_screenshots':True,'record_match':True,'unsupported_claims':False,'production_source_modified':False,'sealed_retry_unchanged':True,'model_usage':model,'preferred_screenshots':['dashboard/dashboard_overview_final.png','dashboard/dashboard_detail.png'],'safety':load('validation/safety.json'),'residual_processes':0}
(E/'result.json').write_text(json.dumps(result,indent=2)+'\n')
files=sorted(p for p in E.rglob('*') if p.is_file())
assert not any(p.is_symlink() for p in files)
(E/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(E).as_posix()}\n' for p in files))
check=subprocess.run(['sha256sum','--check','--quiet','SHA256SUMS.txt'],cwd=E,text=True,capture_output=True)
assert check.returncode==0,(check.stdout,check.stderr)
receipt={'classification':result['classification'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'directory':str(E),'artifact_count':len(files),'verified':len(files),'missing':0,'mismatches':0,'manifest_sha256':sha(E/'SHA256SUMS.txt'),'verification_command':['sha256sum','--check','--quiet','SHA256SUMS.txt'],'exit_code':0,'screenshots':record['screenshots']}
(R/'outputs/cache/stop_b_p18_retry1_dashboard_completion.seal.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
