$ErrorActionPreference='Stop'
$root='C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_retry1_dashboard_completion'
$profile='C:\Dev\aegisinspect-p18-integration\outputs\cache\p18_dashboard_completion_profile'
$before=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'chrome.exe' -and $_.CommandLine -and $_.CommandLine.Contains($profile)} | Select-Object ProcessId,ParentProcessId,CommandLine)
$version=Invoke-RestMethod -Uri 'http://127.0.0.1:9241/json/version' -TimeoutSec 3
$socket=[Net.WebSockets.ClientWebSocket]::new()
$socket.ConnectAsync([Uri]$version.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$bytes=[Text.Encoding]::UTF8.GetBytes('{"id":1,"method":"Browser.close"}')
$socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$socket.Dispose()
for($i=0;$i -lt 10;$i++){
 Start-Sleep -Milliseconds 400
 $remaining=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'chrome.exe' -and $_.CommandLine -and $_.CommandLine.Contains($profile)})
 if($remaining.Count -eq 0){break}
}
@{utc=[DateTime]::UtcNow.ToString('o');method='CDP Browser.close on exact isolated instance';before=$before;remaining_count=$remaining.Count;remaining=@($remaining|Select-Object ProcessId,ParentProcessId,CommandLine)} | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 "$root\shutdown\windows_browser.json"
if($remaining.Count -ne 0){throw 'Owned browser residuals remain'}
