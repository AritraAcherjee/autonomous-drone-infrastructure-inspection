# AegisInspect Inspection Report

## 1. Inspection Summary

- Inspection ID: 2026091904
- Inspection Status: PROCESSING
- Started At: 2026-09-19T21:26:09.942525Z
- Completed At: Unavailable
- Structure ID: 1
- Defect Count: 1
- System Version: P18 7b9ff556956c9c8995262515f53ff5382ffacf1b

## 2. Structure / Inspection Metadata

### Structure

- Structure ID: 1
- Name: P18 Stop-B inspection_bay simulation session
- Description: Simulated infrastructure scene; container for this P18 runtime detector output.
- Location: Unavailable
- Structure Created At: 2026-09-19T21:27:00Z

### Inspection

- Inspection ID: 2026091904
- Structure ID: 1
- Status: PROCESSING
- Started At: 2026-09-19T21:26:09.942525Z
- Completed At: Unavailable
- System Version: P18 7b9ff556956c9c8995262515f53ff5382ffacf1b
- Notes: Detector classification: Honeycombing. Full detector confidence: 0.011138029396533966. Unreviewed machine output; no physical defect confirmation, engineering diagnosis or structural safety conclusion is asserted. Source observation is ROS simulation time 28249000000 ns. First/last seen and evidence timestamps are its epoch encoding, not wall-clock capture time. Map coordinates are metric and session-local to the operational odometry origin; no globally drift-corrected SLAM or ground-truth correction is used.

## 3. Defect Summary

- Total Defects: 1

### Defect IDs

- P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13

## 4. Individual Defect Records

### Defect `P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13`

#### Machine-Produced Fields

- Defect ID: P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13
- Inspection ID: 2026091904
- Track ID: Unavailable
- Class: Honeycombing
- Confidence: 0.011138029396533966
- X (m): 3.888158290345951
- Y (m): 0.07118321516450377
- Z (m): -0.0034923355787129795
- Coordinate Frame: map
- Observation Count: 1
- First Seen: 1970-01-01T00:00:28.249000Z
- Last Seen: 1970-01-01T00:00:28.249000Z
- Model Version: DET-FINAL-v1
- Created At: 2026-09-19T21:27:00Z
- Updated At: 2026-09-19T21:27:00Z

## 5. Evidence / Provenance

### Defect `P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13`

- Evidence Record Count: 1

#### Evidence 1

- Evidence ID: 1
- Defect ID: P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13
- Frame ID: camera_optical_frame
- Timestamp: 1970-01-01T00:00:28.249000Z
- Image Path: /mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_clean_repeatability_run/runtime/capture/rgb_28249000000.png
- Crop Path: Unavailable
- Confidence: 0.011138029396533966
- Bounding Box X1: 14.036376953125
- Bounding Box Y1: 0.0
- Bounding Box X2: 628.8465576171875
- Bounding Box Y2: 480.0

## 6. Human Review Status

### Defect `P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13`

- Review Status: UNREVIEWED
- Review Notes: Unavailable

## 7. Method / Model Metadata

- Inspection System Version: P18 7b9ff556956c9c8995262515f53ff5382ffacf1b
- Defect Model Versions:

  - DET-FINAL-v1

## 8. Limitations

- This report presents persisted deterministic inspection, defect, evidence, and human-review facts.
- Defect dimensions are not reported because no canonical P16 dimension field is available to P17.
- Structural severity is not inferred from detector confidence or human-review status.
- This report does not provide structural-safety conclusions.
- Inspection completeness is not inferred. The inspection status shown in this report is the persisted status.
- Missing optional values are rendered exactly as `Unavailable`.
