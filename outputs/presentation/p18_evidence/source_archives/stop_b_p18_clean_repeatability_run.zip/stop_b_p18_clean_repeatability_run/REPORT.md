# P18 CLEAN REPEATABILITY RUN — PASS

One clean execution repeated the accepted Stop-B chain under the exact frozen source/configuration: P13 → sensors → accepted LiDAR ICP localization → session-local map relation → DET-FINAL-v1 → original-image bbox → robust depth → camera XYZ → exact-time map XYZ → P15 → P16/dashboard → deterministic P17. A genuine new observation was persisted and photographed in the real browser. START was called exactly once, RESET zero times. No automatic retry or production-source/configuration change occurred.

## A. Git and preflight

- Canonical repository: `/mnt/c/Dev/autonomous-drone-infrastructure-inspection`.
- Worktree: `/mnt/c/Dev/aegisinspect-p18-integration`.
- Branch: `P18/full-integration`.
- Starting and final HEAD: `7b9ff556956c9c8995262515f53ff5382ffacf1b`.
- Worktree/source CLEAN before and after; staged files 0; `git diff --check` and `git diff --cached --check` PASS.
- SOURCE_CHANGES=NONE. No source/config commit, merge, reset or tuning.
- Initial relevant residual process count **0**; independent Linux and Windows checks also confirmed clean browser state and free capture port.
- All **102** recorded source/configuration inputs match the accepted first run. DET-FINAL-v1 checkpoint hash matches. Existing accepted ROS build reused; fresh overlay-prefix, binary-linkage and downstream import checks PASS. No rebuild or regression-suite rerun was needed for unchanged source. The runtime exercised the actual integration contracts.

Evidence: `git/initial_state.json`, `git/final_state.json`, `runtime/preflight.json`, `tests/`, `provenance/source_hashes.json`. A local `info/exclude` entry hides only this generated evidence directory from source status; it is recorded separately.

## B. Model usage

MODEL_USED = Current Codex session; exact active model identity is not exposed by available controls.

REASONING_LEVEL = Not exposed by available controls.

Sol Medium execution and Terra packaging were requested. No in-session model switching was available, so no transition is claimed. No Astra escalation was performed. Runtime behavior and the teardown evidence were consistent with the accepted contracts; the different top crash frame did not constitute contradictory evidence.

## C. Runtime

Exact supervisor command/environment: [runtime/launch_command.json](runtime/launch_command.json). The tracked `scripts/p18/supervisor.py` was executed unchanged. Evidence helper bindings changed only the package path and inspection identity; the new database target was empty. The browser uses the proven Windows-side PowerShell/CDP method with the current record's required text, isolated profile and port 9244. No WSL-to-Windows-loopback CDP path was retried.

1. `description` (PID 1617072, 2026-09-19T21:26:10.596258+00:00):

   ```bash
   ros2 launch aegisinspect_description description.launch.py
   ```

2. `p13` (PID 1617129, 2026-09-19T21:26:13.714662+00:00):

   ```bash
   ros2 launch aegisinspect_sim sim.launch.py headless:=true
   ```

3. `localization` (PID 1617522, 2026-09-19T21:26:29.295633+00:00):

   ```bash
   ros2 launch aegisinspect_localization rtabmap_icp_fallback.launch.py
   ```

4. `committed_graph_helper` (PID 1617561, 2026-09-19T21:26:31.854408+00:00):

   ```bash
   python3 -B /mnt/c/Dev/aegisinspect-p18-integration/scripts/diagnostics/icp_graph_ready.py --icp-pid 1617558 --adapter-pid 1617559
   ```

5. `session_map` (PID 1618120, 2026-09-19T21:26:35.861382+00:00):

   ```bash
   ros2 launch aegisinspect_mapping session_map.launch.py
   ```

6. `camera_projection` (PID 1618672, 2026-09-19T21:26:38.871627+00:00):

   ```bash
   ros2 launch aegisinspect_mapping camera_projection.launch.py
   ```

7. `spatial_detector` (PID 1618913, 2026-09-19T21:26:42.772083+00:00):

   ```bash
   /home/aritra/.venvs/aegis-detector-runtime/bin/python -B /mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_clean_repeatability_run/runtime/harness/p18_worker.py --ros-args -p 'model_path:=/mnt/c/Users/79aa3/OneDrive/Documents/INbetween Folder MSI/3/best.pt' -p use_sim_time:=true
   ```

8. `p16_p17_handoff` (PID 1619100, 2026-09-19T21:26:59.521979+00:00):

   ```bash
   /tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python -B /mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_clean_repeatability_run/runtime/harness/p18_downstream.py
   ```

9. `dashboard` (PID 1619174, 2026-09-19T21:27:03.570326+00:00):

   ```bash
   env AEGISINSPECT_DB_PATH=/mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_clean_repeatability_run/p16/p18.sqlite3 /tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python -B -m streamlit run /mnt/c/Dev/aegisinspect-p18-integration/dashboard/app.py --server.address=127.0.0.1 --server.port=8518 --server.headless=true --server.fileWatcherType=none --browser.gatherUsageStats=false
   ```

10. `dashboard_capture` (PID 1619175, 2026-09-19T21:27:03.594105+00:00):

   ```bash
   /tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python -B /mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_clean_repeatability_run/runtime/harness/p18_browser.py
   ```


The corrected supervisor completed its Git integrity check before ROS initialization. All existing readiness/liveness gates remained enabled with the **2.0-second** production threshold. P13 START was accepted at `2026-09-19T21:26:50.950535+00:00`, simulation time `21219000000` ns. `P13_START_CALL_COUNT=1`, `RESET_CALL_COUNT=0`. The consumed execution was not repeated.

The final observed clock was `42219000000` ns, and the unchanged supervisor's completion-window gate passed. The P13 COMPLETE state is inferred from the accepted 20-second deterministic schedule, accepted START and continued simulator liveness; no separate state topic exists. Trajectory hash is preserved in `runtime/p13_state.json`.

Sensor evidence: **35,640 clock callbacks, 671 RGB, 583 depth, 1,277 CameraInfo, 8,039 IMU, 422 valid LiDAR clouds**. Expected camera/optical, IMU and LiDAR frame IDs were maintained. No active-stream guard failure occurred. Maximum callback intervals for clock/LiDAR/native/canonical/TF were all below 2.0 seconds; LiDAR maximum was `0.2741730169946095` s. Exact stream summaries and raw messages are preserved under `sensors/` and `runtime/capture/`.

Localization: **250 native odometry samples, 246 canonical samples**, valid frames and unit orientations. The adapter began after native backend readiness; each canonical pose equals a captured native pose at the same timestamp. Full ICP parameter dictionaries equal the accepted first run. `/vio_adapter` remained the sole actual `odom → base_link` owner; `/aegis/mapping/session_map_origin` owned the fixed session-local `map → odom`; `/aegis/robot_state_publisher` owned sensor extrinsics. No competing actual edge owner was found. The map relation is not globally drift-corrected SLAM.

All captured GT graphs have zero operational subscribers. GT_OPERATIONAL_USE=NO. Detector inference arguments remain `imgsz=640`, `device=0`, `conf=0.001`, `max_det=300`, with checkpoint SHA-256 `4c7a32c9b40c0795bbe59aca5952a0631e1524ec731ad2c7441cccb1b44f71c3`. No locked GYU access or alternate detector was used.

The worker processed 9 frames, submitted 15 detections and recorded 5 projection successes / 10 rejections. All outcomes are retained; one genuine observation was selected and mapped. Rejected candidates were not manually repaired or substituted.

## D. New observation

| Field | Exact value |
| --- | --- |
| Detection identity | `28.249000000-0` |
| Detector class | Honeycombing, class ID 2 |
| Confidence | `0.011138029396533966` |
| Timestamp | `28249000000` ns = 28.249 s ROS simulation time |
| Epoch encoding | `1970-01-01T00:00:28.249000Z` — simulation time, not wall-clock capture time |
| Original image / frame | 640 × 480 / camera_optical_frame |
| Original bbox XYXY | `[14.036376953125, 0.0, 628.8465576171875, 480.0]` |
| Integer ROI | `[14, 0, 629, 480]` |
| Central sampled region | `[167, 120, 475, 360]` |
| Valid / invalid depth count | 73,920 / 0 |
| Depth, metric optical-axis Z | `3.1250760555267334` m |
| Camera XYZ | `[0.005638323544624228, -0.002819161772312114, 3.1250760555267334]` m |
| Map XYZ | `[3.888158290345951, 0.07118321516450377, -0.0034923355787129795]` m |
| Requested / returned TF stamp | `28249000000` / `28249000000` ns |
| Latest-TF fallback | NO |
| New P15 ID | `P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13` |
| Inspection ID | 2026091904 |
| Observation count / review | 1 / UNREVIEWED |

This is **low-confidence detector output**, not confirmed physical Honeycombing, an engineering diagnosis or a structural-safety conclusion. It is a new source image/observation from this execution. The previous P15 ID was not reused. Identity, timestamp and numerical values were not required to equal the first run.

Depth used the unchanged central fraction 0.5, minimum valid fraction 0.5 and median positive finite optical-axis Z. Exact-time RGB/depth/CameraInfo and actual TF are preserved. [runtime/capture/rgb_28249000000.png](runtime/capture/rgb_28249000000.png), [p15/mapped_defect.json](p15/mapped_defect.json), [depth/summary.json](depth/summary.json), [spatial/summary.json](spatial/summary.json).

## E. P16 and browser

Fresh persistence target: [p16/p18.sqlite3](p16/p18.sqlite3). DB SHA-256 `0b4985e1cda229da4c51b73239891ebd1918a4729b8af9653c4e2af5974976a1`. The target did not exist before this execution. The new P15 ID, class, full confidence, coordinates, source timestamps, frame and count persisted exactly. [p16/persisted_record.json](p16/persisted_record.json), [p16/export.sql](p16/export.sql).

P15 replay returned REPLAY with count 1. P16 duplicate defect/evidence inserts were correctly rejected, with one record, one evidence row and no field mutation. SQLite integrity and foreign-key checks passed. Dashboard AppTest PASS and database unchanged. Review remains UNREVIEWED; no human review action occurred.

Real Windows Chrome plus Windows PowerShell .NET CDP captured the running WSL dashboard at `http://127.0.0.1:8518`. Current P15 ID and confidence were bound from this run's persisted record. No old record was substituted and browser capture performed no additional ingestion. Chrome was closed via CDP within the helper; this avoided leaving the browser alive while its launcher exited.

The screenshots were visually inspected: new ID, full low confidence, rounded map XYZ, count 1, DET-FINAL-v1, simulation timestamp, evidence row and UNREVIEWED are represented. The detail screenshot is the preferred readable view; the overview has partially clipped sidebar framing but complete record content. No DOM content or pixels were edited. `real_dashboard_ready.png` is a byte-identical alias of the native overview capture required by the unchanged supervisor.

| Screenshot | SHA-256 |
| --- | --- |
| [dashboard_detail.png](p16/dashboard/dashboard_detail.png) | `68319d3f9b8ea8e754d7cceae29c411bf924c3cc0ca1cff7824dcbab67da5b05` |
| [dashboard_overview.png](p16/dashboard/dashboard_overview.png) | `6338820ad43d629c39fa7c3761a5ac3809359dfd87f306c980baea6dd50e6fa6` |
| [real_dashboard_ready.png](p16/dashboard/real_dashboard_ready.png) | `6338820ad43d629c39fa7c3761a5ac3809359dfd87f306c980baea6dd50e6fa6` |

## F. P17

[p17/inspection_report.md](p17/inspection_report.md) SHA-256:

`810f1e9dfa9c3e0b4a78e6d4e2448bb2bd2057e595028a32e3e69c49affa3f93`

Two independent report renders were equal and the database remained unchanged. Full detector confidence, coordinates, model, identity, provenance, count, review and simulation timestamps were preserved. No fabricated severity, dimensions, repair recommendation, deterioration grade, engineering diagnosis or structural-safety conclusion was introduced. Factual-policy validation: [p17/validation.json](p17/validation.json).

## G. Same-observation lineage

**SAME_OBSERVATION_LINEAGE=PASS.** [provenance/lineage.json](provenance/lineage.json) and [provenance/lineage_validation.json](provenance/lineage_validation.json) bind DET-FINAL-v1 → detection `28.249000000-0` → actual robust depth → camera XYZ → exact-time map XYZ → new P15 ID → P16 record → P17 report.

Offline replay used the already-recorded CDR messages and actual TF. Deserialized worker/monitor RGB messages were equal; camera projection matched captured depth/CameraInfo; exact-time TF reconstructed the map coordinates; P15 state matched. This validation did not launch ROS runtime or detector inference. Command/result: `tests/offline_replay/`; machine result: `runtime/capture/offline_replay_validation.json`.

Source image SHA-256: `c7403e2b2f1675ae991108135952b835f61841ddeb4cf4bc1eea9bbdbbb40b43`. Runtime mapped artifact SHA-256: `11073e46c33c10f6ffc80f7fd84f8b0d0cbc00068bbfb39b02130f65b0872808`. P15 copies under `p15/` are byte-identical archival organization, not manual intermediate construction.

Metadata caveat: to preserve the committed harness exactly, raw inherited first-run prose and `REPEATABILITY_RUN=false` remain in some raw files. `provenance/execution_identity.json` and `runtime/accounting.json` explicitly identify this authorized execution as CLEAN REPEATABILITY. The runtime ID, fresh inspection ID, fresh database, new observation and recorded launch/START counters establish its identity. No raw evidence was rewritten to hide legacy labels.

## H. Repeatability/configuration comparison

SCIENTIFIC_CONFIGURATION_UNCHANGED=YES. Source inventory, P13 trajectory, complete ICP parameter dictionary and detector inference arguments match the accepted first run. All accepted scientific/runtime semantics and the 2.0-second guard were frozen. Differences are limited to evidence destinations, inspection/database identity and browser capture bindings required for the new record. Numerical observation values and UUID differ legitimately.

Configuration evidence: `provenance/scientific_configuration_comparison.json`, `localization/configuration_comparison.json`, `detector/configuration_comparison.json`, `provenance/frozen_sources_after.json`. Resource/process snapshots are retained, with no invented performance threshold, in `runtime/resource_notes.json` and raw process inventories.

## I. Evidence integrity

Directory: `/mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_clean_repeatability_run/`.

Every artifact except `SHA256SUMS.txt` itself is hashed in [SHA256SUMS.txt](SHA256SUMS.txt). Verification command is `sha256sum --check --quiet SHA256SUMS.txt` from this directory. The artifact count, manifest hash and verification receipt are stored outside the sealed package at `outputs/cache/stop_b_p18_clean_repeatability_run.seal.json`. A ZIP, if produced, is stored alongside that receipt with its hash; the package is not modified after sealing.

All prior directories remain unchanged: integration base 96/96, original failed attempt 200/200, accepted retry 285/285, dashboard supplement 49/49 verified before/after. Accepted first-run ZIP hash remains `afdf4aa12d589c5984d637fcb122f6ef2a810cfa1111434e9135fee63f3d2f2d`. The supplied dashboard-supplement ZIP hash `b52cf8db39c0a0fb936dc25eaf9f3a1af83b26a4310a3ee1e8fc5a671d28ae61` is retained as 00 metadata; that ZIP is absent from local outputs and was not independently verified. Its sealed 49-artifact directory was verified.

## J. Controlled shutdown

Full runtime evidence, including browser screenshots, completed at **2026-09-19T21:27:13.418339+00:00**. Controlled shutdown began at **2026-09-19T21:27:13.428369+00:00**. Bridge PID **1617255** handled SIGINT at wall time **1789853233.459805667** and then exited **-11**.

PARAMETER_BRIDGE_VENDOR_TEARDOWN_DEFECT_REPRODUCED=YES. There was no active-runtime kernel SIGSEGV. The saved core shows `Fast DDS ... on_writer_discovery` faulting while the main exit thread is in `tracetools_fini` / `dlclose`. This is consistent with the accepted vendor/library exit/unload mechanism. The top frame differs from the prior `DataReaderImpl::take` fault; an identical instruction/frame is not claimed. The defect is not fixed and is not hidden. Runtime evidence was complete before shutdown, stored DB/report hashes remain intact, and independent final Linux and Windows inventories are zero.

Core: [shutdown/core.1617255](shutdown/core.1617255), SHA-256 `2107a35f8f722bac6bb3a1ff2005a0f588109f2056bdc061bbd91003153cd0d8`. Stack: [shutdown/gdb/stdout.txt](shutdown/gdb/stdout.txt). Timing/assessment: [shutdown/vendor_assessment.json](shutdown/vendor_assessment.json). All launch parents returned 0; SIGINT-associated -2 child statuses are preserved below.

| Child PID | Exit code | Log |
| --- | --- | --- |
| 1618862 | -2 | `runtime/capture/camera_projection.log` |
| 1617109 | 0 | `runtime/capture/description.log` |
| 1617559 | -2 | `runtime/capture/localization.log` |
| 1617558 | 0 | `runtime/capture/localization.log` |
| 1617255 | -11 | `runtime/capture/p13.log` |
| 1617253 | -2 | `runtime/capture/p13.log` |
| 1617254 | 0 | `runtime/capture/p13.log` |
| 1618621 | -2 | `runtime/capture/session_map.log` |

**RELEVANT_RESIDUAL_PROCESS_COUNT=0** before launch and after controlled shutdown. No cleanup retry of the scientific execution occurred.

## K. Safety and handback

```text
SCIENTIFIC_CONFIGURATION_CHANGED = NO
GT_OPERATIONAL_USE = NO
ADDITIONAL_AUTOMATIC_RETRY = NO
STOP_B_FREEZE_STARTED = NO
MAIN_MERGE_STARTED = NO
SOURCE_CHANGES = NONE
P13_START_CALL_COUNT = 1
RESET_CALL_COUNT = 0
```

**STOP AND RETURN TO 00.** The authorized repeatability execution is consumed. No further P18 execution, actual Stop-B freeze, main merge or Stop C work was performed. No optional freeze-readiness inventory was needed for this handback.
