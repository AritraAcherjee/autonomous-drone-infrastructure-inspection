"""Final acceptance and sealing of the completed repeatability run."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,shlex,re
R=Path('/mnt/c/Dev/aegisinspect-p18-integration');E=R/'outputs/evidence/stop_b_p18_clean_repeatability_run';C=E/'runtime/capture';OLD=R/'outputs/evidence/stop_b_p18_first_integrated_run_retry1'
def read(p):return json.loads((E/p).read_text(encoding='utf-8-sig'))
def save(p,x):
 target=E/p;assert not target.exists(),target;target.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def rows(p):return [json.loads(s) for s in (C/p).read_text().splitlines() if s]
raw=read('runtime/capture/result.json');lineage=read('provenance/lineage.json');record=read('p16/persisted_record.json');depth=read('depth/summary.json');replay=read('runtime/capture/offline_replay_validation.json');liveness=read('runtime/liveness_summary.json');shutdown=read('runtime/capture/shutdown_start.json')
assert raw['runtime_pass'] and raw['errors']==[] and raw['RELEVANT_RESIDUAL_PROCESS_COUNT']==0
assert raw['safety']['P13_START_CALL_COUNT']==1 and raw['safety']['RESET_CALL_COUNT']==0
assert read('runtime/p13_state.json')['completion_window_observed']
assert read('p16/dashboard_apptest.json')['PASS'] and read('p16/idempotency.json')['PASS'] and read('p16/screenshot_validation.json')['PASS']
assert read('p16/browser/capture_result.json')['PASS'] and read('p17/validation.json')['PASS'] and replay['PASS']
assert read('provenance/lineage_validation.json')['SAME_OBSERVATION_LINEAGE']=='PASS'
assert all(liveness['streams'][k]['all_valid'] for k in ['lidar','native','canonical'])
assert all(liveness['streams'][k]['maximum_callback_gap_sec']<2 for k in ['clock','lidar','native','canonical','tf'])
assert all(not g['topics']['/aegis/sim/ground_truth/pose']['subscriptions'] for g in rows('graph.jsonl'))
assert shutdown['active_runtime_evidence_complete'] and raw['runtime_evidence_complete_utc']<shutdown['utc']
native={r['stamp_ns']:r for r in rows('native.jsonl')}
canonical=rows('canonical.jsonl')
for r in canonical:
 n=native[r['stamp_ns']];assert r['position']==n['position'] and r['quaternion']==n['quaternion']
save('localization/adapter_value_validation.json',{'PASS':True,'canonical_samples_matching_native_pose_at_same_stamp':len(canonical),'native_samples':len(native),'note':'Canonical starts after native backend readiness; 250 native and 246 canonical samples are not a requirement for identical callback counts.'})
assert record['review_status']=='UNREVIEWED' and record['observation_count']==1
assert record['defect_id']!='P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd'
assert depth['valid_depth_count']==73920 and depth['invalid_depth_count']==0
gdb=(E/'shutdown/gdb/stdout.txt').read_text();assert all(s in gdb for s in ['SIGSEGV','on_writer_discovery','tracetools_fini','dlclose'])
p13=(C/'p13.log').read_text();assert p13.index('signal_handler(signum=2)')<p13.index('exit code -11')
pre=(C/'kernel_pre_shutdown.txt').read_text();assert not re.search(r'segfault|fatal signal 11|SIGSEGV',pre,re.I)
save('shutdown/vendor_assessment.json',{'PARAMETER_BRIDGE_VENDOR_TEARDOWN_DEFECT_REPRODUCED':'YES','bridge_pid':1617255,'exit_code':-11,'active_runtime_evidence_complete_utc':raw['runtime_evidence_complete_utc'],'controlled_shutdown_utc':shutdown['utc'],'bridge_SIGINT_wall_seconds':1789853233.459805667,'active_kernel_sigsegv':False,'post_shutdown_kernel_faults':True,'core':read('shutdown/core_preservation.json')[0],'mechanism_assessment':'Consistent with the accepted vendor/library exit/unload defect: main exit thread is in tracetools_fini/dlclose while a Fast DDS discovery callback faults. This run faults in on_writer_discovery rather than the prior DataReaderImpl::take frame; exact top frame is not claimed identical.','not_fixed':True,'evidence_intact':True,'final_residual_count':0})
shots=read('p16/screenshot_validation.json')['screenshots']
save('p16/visual_inspection.json',{'PASS':True,'inspected':['p16/dashboard/dashboard_overview.png','p16/dashboard/dashboard_detail.png'],'findings':'Real existing dashboard presents the new ID, full low confidence, rounded map XYZ, count 1, model identity, simulation timestamp, evidence row and UNREVIEWED status. No unsupported engineering claim. Overview has partial sidebar framing; record content is complete. Detail is fully readable. No pixels or DOM content edited.','new_browser_runtime_after_shutdown':False})
peak_rss={}
for p in C.glob('proc_*_status.txt'):
 match=re.search(r'^VmRSS:\s+(\d+) kB',p.read_text(),re.M)
 if match:peak_rss[p.name]=int(match[1])
save('runtime/resource_notes.json',{'process_inventory':'runtime/capture/process_inventory.json','periodic_process_trees':'runtime/capture/process_trees.jsonl','sampled_rss_kib':peak_rss,'interpretation':'These are saved process snapshots, not a peak-memory benchmark or resource acceptance threshold. No performance tuning was performed.'})
checks=[
 'Exact authorized P18 branch and HEAD','Clean source worktree before execution','Zero pre-launch residuals','Frozen P13 trajectory and timing','Accepted runtime/scientific configuration','No scientific parameter changes','Unchanged pre-START readiness gates passed','Exactly one START','Valid live sensors','Accepted ICP and canonical odometry','Frozen TF/map ownership','DET-FINAL-v1 new observation','Valid robust metric depth','Camera XYZ','Exact-observation-time map XYZ','New P15 identity accepted','P16 exact persistence','Dashboard AppTest','Real browser screenshots','P17 deterministic factual report','Same-observation lineage','GT operational use NO','No intermediate substitution','Controlled shutdown complete','Final residuals zero']
save('validation_acceptance.json',{'classification':'P18 CLEAN REPEATABILITY RUN — PASS','checks':[{ 'requirement':x,'result':'PASS'} for x in checks],'manifest_requirement':'Verified by SHA256SUMS.txt and external sealing receipt; no self-referential manifest','SAME_OBSERVATION_LINEAGE':'PASS'})
safety={'SCIENTIFIC_CONFIGURATION_CHANGED':'NO','GT_OPERATIONAL_USE':'NO','ADDITIONAL_AUTOMATIC_RETRY':'NO','STOP_B_FREEZE_STARTED':'NO','MAIN_MERGE_STARTED':'NO','SOURCE_CHANGES':'NONE','P13_START_CALL_COUNT':1,'RESET_CALL_COUNT':0,'REPEATABILITY_EXECUTIONS':1}
save('safety.json',safety)
save('result.json',{'classification':'P18 CLEAN REPEATABILITY RUN — PASS','head':'7b9ff556956c9c8995262515f53ff5382ffacf1b','branch':'P18/full-integration','SAME_OBSERVATION_LINEAGE':'PASS','new_detection_id':lineage['detection']['detection_id'],'new_p15_id':record['defect_id'],'P16':'PASS','dashboard_apptest':'PASS','browser_screenshots':'PASS','P17':'PASS','report_sha256':lineage['p17']['sha256'],'PARAMETER_BRIDGE_VENDOR_TEARDOWN_DEFECT_REPRODUCED':'YES','RELEVANT_RESIDUAL_PROCESS_COUNT':0,'safety':safety,'source_and_configuration_unchanged':True,'raw_legacy_metadata_note':'Unchanged first-run harness contains first-run wording and REPEATABILITY_RUN=false; execution_identity.json and runtime/accounting.json state this authorized run is repeatability. Raw evidence was not rewritten.'})
for name in ['p18_repeat_offline.py','p18_repeat_seal.py']:(E/'runtime/harness'/name).write_bytes((Path('/tmp')/name).read_bytes())
launches=read('runtime/launch_sequence.json')
launch_text='\n'.join(f"{i}. `{v['name']}` (PID {v['pid']}, {v['utc']}):\n\n   ```bash\n   {shlex.join(v['argv'])}\n   ```\n" for i,v in enumerate(launches,1))
shot_text='\n'.join(f"| [{name}](p16/dashboard/{name}) | `{v['sha256']}` |" for name,v in shots.items())
child_text='\n'.join(f"| {r['pid']} | {r['returncode']} | `{r['log']}` |" for r in read('shutdown/all_child_statuses.json'))
report=f'''# P18 CLEAN REPEATABILITY RUN — PASS

One clean execution repeated the accepted Stop-B chain under the exact frozen source/configuration: P13 → sensors → accepted LiDAR ICP localization → session-local map relation → DET-FINAL-v1 → original-image bbox → robust depth → camera XYZ → exact-time map XYZ → P15 → P16/dashboard → deterministic P17. A genuine new observation was persisted and photographed in the real browser. START was called exactly once, RESET zero times. No automatic retry or production-source/configuration change occurred.

## A. Git and preflight

- Canonical repository: `/mnt/c/Dev/autonomous-drone-infrastructure-inspection`.
- Worktree: `/mnt/c/Dev/aegisinspect-p18-integration`.
- Branch: `P18/full-integration`.
- Starting and final HEAD: `7b9ff556956c9c8995262515f53ff5382ffacf1b`.
- Worktree/source CLEAN before and after; staged files 0; `git diff --check` and `git diff --cached --check` PASS.
- SOURCE_CHANGES=NONE. No source/config commit, merge, reset or tuning.
- Initial relevant residual process count **0**; independent Linux and Windows checks also confirmed clean browser state and free capture port.
- All **102** recorded source/configuration inputs match the accepted first run. DET-FINAL-v1 checkpoint hash matches. Existing accepted ROS build reused; fresh overlay-prefix, binary-linkage and downstream import checks PASS. No rebuild or regression-suite rerun was needed for unchanged source. The runtime exercised the actual integration contracts.

Evidence: `git/initial_state.json`, `git/final_state.json`, `runtime/preflight.json`, `tests/`, `provenance/source_hashes.json`. A local `info/exclude` entry hides only this generated evidence directory from source status; it is recorded separately.

## B. Model usage

MODEL_USED = Current Codex session; exact active model identity is not exposed by available controls.

REASONING_LEVEL = Not exposed by available controls.

Sol Medium execution and Terra packaging were requested. No in-session model switching was available, so no transition is claimed. No Astra escalation was performed. Runtime behavior and the teardown evidence were consistent with the accepted contracts; the different top crash frame did not constitute contradictory evidence.

## C. Runtime

Exact supervisor command/environment: [runtime/launch_command.json](runtime/launch_command.json). The tracked `scripts/p18/supervisor.py` was executed unchanged. Evidence helper bindings changed only the package path and inspection identity; the new database target was empty. The browser uses the proven Windows-side PowerShell/CDP method with the current record's required text, isolated profile and port 9244. No WSL-to-Windows-loopback CDP path was retried.

{launch_text}

The corrected supervisor completed its Git integrity check before ROS initialization. All existing readiness/liveness gates remained enabled with the **2.0-second** production threshold. P13 START was accepted at `2026-09-19T21:26:50.950535+00:00`, simulation time `21219000000` ns. `P13_START_CALL_COUNT=1`, `RESET_CALL_COUNT=0`. The consumed execution was not repeated.

The final observed clock was `42219000000` ns, and the unchanged supervisor's completion-window gate passed. The P13 COMPLETE state is inferred from the accepted 20-second deterministic schedule, accepted START and continued simulator liveness; no separate state topic exists. Trajectory hash is preserved in `runtime/p13_state.json`.

Sensor evidence: **35,640 clock callbacks, 671 RGB, 583 depth, 1,277 CameraInfo, 8,039 IMU, 422 valid LiDAR clouds**. Expected camera/optical, IMU and LiDAR frame IDs were maintained. No active-stream guard failure occurred. Maximum callback intervals for clock/LiDAR/native/canonical/TF were all below 2.0 seconds; LiDAR maximum was `0.2741730169946095` s. Exact stream summaries and raw messages are preserved under `sensors/` and `runtime/capture/`.

Localization: **250 native odometry samples, 246 canonical samples**, valid frames and unit orientations. The adapter began after native backend readiness; each canonical pose equals a captured native pose at the same timestamp. Full ICP parameter dictionaries equal the accepted first run. `/vio_adapter` remained the sole actual `odom → base_link` owner; `/aegis/mapping/session_map_origin` owned the fixed session-local `map → odom`; `/aegis/robot_state_publisher` owned sensor extrinsics. No competing actual edge owner was found. The map relation is not globally drift-corrected SLAM.

All captured GT graphs have zero operational subscribers. GT_OPERATIONAL_USE=NO. Detector inference arguments remain `imgsz=640`, `device=0`, `conf=0.001`, `max_det=300`, with checkpoint SHA-256 `4c7a32c9b40c0795bbe59aca5952a0631e1524ec731ad2c7441cccb1b44f71c3`. No locked GYU access or alternate detector was used.

The worker processed 9 frames, submitted 15 detections and recorded 5 projection successes / 10 rejections. All outcomes are retained; one genuine observation was selected and mapped. Rejected candidates were not manually repaired or substituted.

## D. New observation

| Field | Exact value |
| --- | --- |
| Detection identity | `28.249000000-0` |
| Detector class | Honeycombing, class ID 2 |
| Confidence | `0.011138029396533966` |
| Timestamp | `28249000000` ns = 28.249 s ROS simulation time |
| Epoch encoding | `1970-01-01T00:00:28.249000Z` — simulation time, not wall-clock capture time |
| Original image / frame | 640 × 480 / camera_optical_frame |
| Original bbox XYXY | `[14.036376953125, 0.0, 628.8465576171875, 480.0]` |
| Integer ROI | `[14, 0, 629, 480]` |
| Central sampled region | `[167, 120, 475, 360]` |
| Valid / invalid depth count | 73,920 / 0 |
| Depth, metric optical-axis Z | `3.1250760555267334` m |
| Camera XYZ | `[0.005638323544624228, -0.002819161772312114, 3.1250760555267334]` m |
| Map XYZ | `[3.888158290345951, 0.07118321516450377, -0.0034923355787129795]` m |
| Requested / returned TF stamp | `28249000000` / `28249000000` ns |
| Latest-TF fallback | NO |
| New P15 ID | `P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13` |
| Inspection ID | 2026091904 |
| Observation count / review | 1 / UNREVIEWED |

This is **low-confidence detector output**, not confirmed physical Honeycombing, an engineering diagnosis or a structural-safety conclusion. It is a new source image/observation from this execution. The previous P15 ID was not reused. Identity, timestamp and numerical values were not required to equal the first run.

Depth used the unchanged central fraction 0.5, minimum valid fraction 0.5 and median positive finite optical-axis Z. Exact-time RGB/depth/CameraInfo and actual TF are preserved. [runtime/capture/rgb_28249000000.png](runtime/capture/rgb_28249000000.png), [p15/mapped_defect.json](p15/mapped_defect.json), [depth/summary.json](depth/summary.json), [spatial/summary.json](spatial/summary.json).

## E. P16 and browser

Fresh persistence target: [p16/p18.sqlite3](p16/p18.sqlite3). DB SHA-256 `{lineage['p16']['database_sha256']}`. The target did not exist before this execution. The new P15 ID, class, full confidence, coordinates, source timestamps, frame and count persisted exactly. [p16/persisted_record.json](p16/persisted_record.json), [p16/export.sql](p16/export.sql).

P15 replay returned REPLAY with count 1. P16 duplicate defect/evidence inserts were correctly rejected, with one record, one evidence row and no field mutation. SQLite integrity and foreign-key checks passed. Dashboard AppTest PASS and database unchanged. Review remains UNREVIEWED; no human review action occurred.

Real Windows Chrome plus Windows PowerShell .NET CDP captured the running WSL dashboard at `http://127.0.0.1:8518`. Current P15 ID and confidence were bound from this run's persisted record. No old record was substituted and browser capture performed no additional ingestion. Chrome was closed via CDP within the helper; this avoided leaving the browser alive while its launcher exited.

The screenshots were visually inspected: new ID, full low confidence, rounded map XYZ, count 1, DET-FINAL-v1, simulation timestamp, evidence row and UNREVIEWED are represented. The detail screenshot is the preferred readable view; the overview has partially clipped sidebar framing but complete record content. No DOM content or pixels were edited. `real_dashboard_ready.png` is a byte-identical alias of the native overview capture required by the unchanged supervisor.

| Screenshot | SHA-256 |
| --- | --- |
{shot_text}

## F. P17

[p17/inspection_report.md](p17/inspection_report.md) SHA-256:

`{lineage['p17']['sha256']}`

Two independent report renders were equal and the database remained unchanged. Full detector confidence, coordinates, model, identity, provenance, count, review and simulation timestamps were preserved. No fabricated severity, dimensions, repair recommendation, deterioration grade, engineering diagnosis or structural-safety conclusion was introduced. Factual-policy validation: [p17/validation.json](p17/validation.json).

## G. Same-observation lineage

**SAME_OBSERVATION_LINEAGE=PASS.** [provenance/lineage.json](provenance/lineage.json) and [provenance/lineage_validation.json](provenance/lineage_validation.json) bind DET-FINAL-v1 → detection `28.249000000-0` → actual robust depth → camera XYZ → exact-time map XYZ → new P15 ID → P16 record → P17 report.

Offline replay used the already-recorded CDR messages and actual TF. Deserialized worker/monitor RGB messages were equal; camera projection matched captured depth/CameraInfo; exact-time TF reconstructed the map coordinates; P15 state matched. This validation did not launch ROS runtime or detector inference. Command/result: `tests/offline_replay/`; machine result: `runtime/capture/offline_replay_validation.json`.

Source image SHA-256: `{lineage['source_image']['sha256']}`. Runtime mapped artifact SHA-256: `{lineage['p15']['sha256']}`. P15 copies under `p15/` are byte-identical archival organization, not manual intermediate construction.

Metadata caveat: to preserve the committed harness exactly, raw inherited first-run prose and `REPEATABILITY_RUN=false` remain in some raw files. `provenance/execution_identity.json` and `runtime/accounting.json` explicitly identify this authorized execution as CLEAN REPEATABILITY. The runtime ID, fresh inspection ID, fresh database, new observation and recorded launch/START counters establish its identity. No raw evidence was rewritten to hide legacy labels.

## H. Repeatability/configuration comparison

SCIENTIFIC_CONFIGURATION_UNCHANGED=YES. Source inventory, P13 trajectory, complete ICP parameter dictionary and detector inference arguments match the accepted first run. All accepted scientific/runtime semantics and the 2.0-second guard were frozen. Differences are limited to evidence destinations, inspection/database identity and browser capture bindings required for the new record. Numerical observation values and UUID differ legitimately.

Configuration evidence: `provenance/scientific_configuration_comparison.json`, `localization/configuration_comparison.json`, `detector/configuration_comparison.json`, `provenance/frozen_sources_after.json`. Resource/process snapshots are retained, with no invented performance threshold, in `runtime/resource_notes.json` and raw process inventories.

## I. Evidence integrity

Directory: `/mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_clean_repeatability_run/`.

Every artifact except `SHA256SUMS.txt` itself is hashed in [SHA256SUMS.txt](SHA256SUMS.txt). Verification command is `sha256sum --check --quiet SHA256SUMS.txt` from this directory. The artifact count, manifest hash and verification receipt are stored outside the sealed package at `outputs/cache/stop_b_p18_clean_repeatability_run.seal.json`. A ZIP, if produced, is stored alongside that receipt with its hash; the package is not modified after sealing.

All prior directories remain unchanged: integration base 96/96, original failed attempt 200/200, accepted retry 285/285, dashboard supplement 49/49 verified before/after. Accepted first-run ZIP hash remains `afdf4aa12d589c5984d637fcb122f6ef2a810cfa1111434e9135fee63f3d2f2d`. The supplied dashboard-supplement ZIP hash `b52cf8db39c0a0fb936dc25eaf9f3a1af83b26a4310a3ee1e8fc5a671d28ae61` is retained as 00 metadata; that ZIP is absent from local outputs and was not independently verified. Its sealed 49-artifact directory was verified.

## J. Controlled shutdown

Full runtime evidence, including browser screenshots, completed at **2026-09-19T21:27:13.418339+00:00**. Controlled shutdown began at **2026-09-19T21:27:13.428369+00:00**. Bridge PID **1617255** handled SIGINT at wall time **1789853233.459805667** and then exited **-11**.

PARAMETER_BRIDGE_VENDOR_TEARDOWN_DEFECT_REPRODUCED=YES. There was no active-runtime kernel SIGSEGV. The saved core shows `Fast DDS ... on_writer_discovery` faulting while the main exit thread is in `tracetools_fini` / `dlclose`. This is consistent with the accepted vendor/library exit/unload mechanism. The top frame differs from the prior `DataReaderImpl::take` fault; an identical instruction/frame is not claimed. The defect is not fixed and is not hidden. Runtime evidence was complete before shutdown, stored DB/report hashes remain intact, and independent final Linux and Windows inventories are zero.

Core: [shutdown/core.1617255](shutdown/core.1617255), SHA-256 `2107a35f8f722bac6bb3a1ff2005a0f588109f2056bdc061bbd91003153cd0d8`. Stack: [shutdown/gdb/stdout.txt](shutdown/gdb/stdout.txt). Timing/assessment: [shutdown/vendor_assessment.json](shutdown/vendor_assessment.json). All launch parents returned 0; SIGINT-associated -2 child statuses are preserved below.

| Child PID | Exit code | Log |
| --- | --- | --- |
{child_text}

**RELEVANT_RESIDUAL_PROCESS_COUNT=0** before launch and after controlled shutdown. No cleanup retry of the scientific execution occurred.

## K. Safety and handback

```text
SCIENTIFIC_CONFIGURATION_CHANGED = NO
GT_OPERATIONAL_USE = NO
ADDITIONAL_AUTOMATIC_RETRY = NO
STOP_B_FREEZE_STARTED = NO
MAIN_MERGE_STARTED = NO
SOURCE_CHANGES = NONE
P13_START_CALL_COUNT = 1
RESET_CALL_COUNT = 0
```

**STOP AND RETURN TO 00.** The authorized repeatability execution is consumed. No further P18 execution, actual Stop-B freeze, main merge or Stop C work was performed. No optional freeze-readiness inventory was needed for this handback.
'''
(E/'REPORT.md').write_text(report)
assert not (E/'SHA256SUMS.txt').exists()
files=sorted(p for p in E.rglob('*') if p.is_file());assert not any(p.is_symlink() for p in files)
(E/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(E).as_posix()}\n' for p in files))
verify=subprocess.run(['sha256sum','--check','--quiet','SHA256SUMS.txt'],cwd=E,text=True,capture_output=True);assert verify.returncode==0,(verify.stdout,verify.stderr)
receipt={'classification':'P18 CLEAN REPEATABILITY RUN — PASS','directory':str(E),'artifact_count':len(files),'verified':len(files),'missing':0,'mismatches':0,'manifest_sha256':sha(E/'SHA256SUMS.txt'),'verification_command':['sha256sum','--check','--quiet','SHA256SUMS.txt'],'exit_code':0,'sealed_utc':datetime.now(timezone.utc).isoformat()}
(R/'outputs/cache/stop_b_p18_clean_repeatability_run.seal.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
