from pathlib import Path
import subprocess,json,ast,sys,os
R=Path('/mnt/c/Dev/aegisinspect-p18-integration');E=R/'outputs/evidence/stop_b_p18_clean_repeatability_run';OLD=R/'outputs/evidence/stop_b_p18_first_integrated_run_retry1'
def save(p,x):(E/p).write_text(json.dumps(x,indent=2)+'\n')
(E/'runtime/harness/p18_browser.py').write_bytes(Path('/tmp/p18_repeat_browser.py').read_bytes())
for p in (E/'runtime/harness').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
old=r'C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_retry1_dashboard_completion';new=r'C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_clean_repeatability_run\p16'
def bind(name):return (E/'runtime/harness'/name).read_text().replace(old,new).replace('p18_dashboard_completion_profile','p18_repeatability_profile').replace('9241','9244').replace('8519','8518')
start=bind('p18_dashboard_browser_start.ps1');capture=bind('p18_dashboard_capture.ps1');cleanup=bind('p18_dashboard_cleanup.ps1')
assert " $required=@('P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd','0.026687312871217728','Honeycombing','UNREVIEWED','DET-FINAL-v1','Observation count:','Map XYZ (m):','Current review status:','Evidence')" in capture
template=start+'\ntry {\n'+capture+'\n} finally {\n'+cleanup+'\n}\n'
(E/'p16/browser/parse_only_template.ps1').write_text(template)
ps=r'''$ErrorActionPreference='Stop'; $tokens=$null; $errors=$null; [System.Management.Automation.Language.Parser]::ParseFile('C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_clean_repeatability_run\p16\browser\parse_only_template.ps1',[ref]$tokens,[ref]$errors) | Out-Null; $listeners=@(Get-NetTCPConnection -LocalPort 9244 -State Listen -ErrorAction SilentlyContinue); $owned=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'chrome.exe' -and $_.CommandLine -like '*aegisinspect-p18-integration*profile*'}); @{parse_error_count=$errors.Count;parse_errors=@($errors|ForEach-Object {$_.ToString()});listener_count=$listeners.Count;owned_browser_count=$owned.Count} | ConvertTo-Json -Depth 5; if($errors.Count -ne 0 -or $listeners.Count -ne 0 -or $owned.Count -ne 0){exit 2}'''
commands={
 'windows_preflight':['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-Command',ps],
 'package_prefix_and_linkage':json.loads((OLD/'tests/package_prefix_and_linkage/command.json').read_text())['argv'],
 'downstream_imports':['/tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python','-B','-c',"from src.storage.service import InspectionService; from src.integrations.p16_p17_adapter import build_inspection_report; from src.reporting.rendering import render_report; from streamlit.testing.v1 import AppTest; import websockets; print('P15/P16/P17/dashboard dependencies import PASS; no runtime or ingestion')"],
}
for name,argv in commands.items():
 p=subprocess.run(argv,cwd=R,text=True,capture_output=True,timeout=40)
 save('tests/'+name+'.json',{'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 assert p.returncode==0,(name,p.stdout,p.stderr)
sys.path.insert(0,str(E/'runtime/harness'))
from evidence import inventory,digest
inv=inventory();save('runtime/preflight_processes.json',inv);assert inv['count']==0
assert subprocess.check_output(['git','status','--short'],cwd=R,text=True)==''
assert not (E/'runtime/capture/runtime_invocation.json').exists() and not (E/'p16/p18.sqlite3').exists()
save('runtime/preflight.json',{'PASS':True,'SOURCE_CHANGES':'NONE','HEAD':'7b9ff556956c9c8995262515f53ff5382ffacf1b','RELEVANT_RESIDUAL_PROCESS_COUNT':0,'P13_START_CALL_COUNT':0,'RESET_CALL_COUNT':0,'frozen_source_inputs_verified':102,'guard_seconds':2.0,'inspection_id':2026091904,'browser_method':'Proven Windows-side PowerShell/CDP, fresh port 9244 and profile','scientific_configuration_changed':False,'automatic_retry_authorized':False,'build':'Existing accepted build reused; zero source/config changes; fresh prefix/linkage/import checks PASS','browser_helper_sha256':digest(E/'runtime/harness/p18_browser.py')})
(E/'runtime/harness/p18_repeat_preflight.py').write_bytes(Path('/tmp/p18_repeat_preflight.py').read_bytes())
print('REPEATABILITY_PREFLIGHT=PASS; RUNTIME_NOT_LAUNCHED; START=0 RESET=0')
