"""Bind proven Windows-side capture to this run; no scientific changes or ingestion."""
from pathlib import Path
import json,subprocess
from evidence import PACKAGE,ROOT,save,digest

def main():
    record=json.loads((PACKAGE/'p16/persisted_record.json').read_text())
    assert record['defect_id']!='P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd'
    db=PACKAGE/'p16/p18.sqlite3';before=digest(db)
    base=PACKAGE/'runtime/harness'
    old=r'C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_retry1_dashboard_completion'
    new=r'C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_clean_repeatability_run\p16'
    def bind(name):
        source=(base/name).read_text()
        assert old in source
        return source.replace(old,new).replace('p18_dashboard_completion_profile','p18_repeatability_profile').replace('9241','9244').replace('8519','8518')
    start=bind('p18_dashboard_browser_start.ps1')
    capture=bind('p18_dashboard_capture.ps1')
    expected=" $required=@('P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd','0.026687312871217728','Honeycombing','UNREVIEWED','DET-FINAL-v1','Observation count:','Map XYZ (m):','Current review status:','Evidence')"
    assert expected in capture
    required=[record['defect_id'],repr(record['confidence']),record['class_name'],'UNREVIEWED','DET-FINAL-v1','Observation count:','Map XYZ (m):','Current review status:','Evidence']
    replacement=' $required=@('+','.join("'"+value.replace("'","''")+"'" for value in required)+')'
    capture=capture.replace(expected,replacement)
    cleanup=bind('p18_dashboard_cleanup.ps1')
    # The same proven operations run on one Windows process; close the owned
    # browser before its launcher exits, avoiding the prior wrapper wait issue.
    script=start+'\ntry {\n'+capture+'\n} finally {\n'+cleanup+'\n}\n'
    target=PACKAGE/'p16/browser/capture.ps1';target.write_text(script)
    command=['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',new+r'\browser\capture.ps1']
    with (PACKAGE/'p16/browser/helper_stdout.txt').open('w') as out,(PACKAGE/'p16/browser/helper_stderr.txt').open('w') as err:
        proc=subprocess.run(command,stdout=out,stderr=err,timeout=65)
    save(PACKAGE/'p16/browser/command.json',{'argv':command,'exit_code':proc.returncode,'required_record_text':required,'accepted_method':'Windows Chrome + Windows PowerShell CDP; existing WSL dashboard','input_database_sha256':before})
    assert proc.returncode==0,'Windows browser helper failed'
    assert digest(db)==before,'Dashboard changed persisted data'
    shot=PACKAGE/'p16/dashboard/dashboard_overview.png'
    (PACKAGE/'p16/dashboard/real_dashboard_ready.png').write_bytes(shot.read_bytes())
    save(PACKAGE/'p16/browser/database_unchanged.json',{'PASS':True,'before':before,'after':digest(db),'new_ingestion':False,'review_submitted':False})
    print('P18_WINDOWS_BROWSER_CAPTURE=PASS',flush=True)

if __name__=='__main__':main()
