from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
R=Path('/mnt/c/Dev/aegisinspect-p18-integration');E=R/'outputs/evidence/stop_b_p18_clean_repeatability_run';OLD=R/'outputs/evidence/stop_b_p18_first_integrated_run_retry1'
kind=sys.argv[1]
if kind=='replay':
 target=E/'provenance/offline_replay.py';assert not target.exists();target.write_bytes((OLD/'provenance/offline_replay.py').read_bytes())
 shell='set -e\nsource /opt/ros/lyrical/setup.bash\nsource ros2_ws/install/local_setup.bash\nexport PYTHONDONTWRITEBYTECODE=1\nexport PYTHONPATH="$PWD/outputs/evidence/stop_b_p18_clean_repeatability_run/runtime/harness:$PWD:$PYTHONPATH"\npython3 -B '+str(target)+'\n'
 argv=['bash','--noprofile','--norc','-c',shell];dest=E/'tests/offline_replay'
elif kind=='gdb':
 argv=json.loads((OLD/'shutdown/gdb/command.json').read_text())['argv']
 argv=[v.replace(OLD.name,E.name).replace('core.1609930','core.1617255') for v in argv];dest=E/'shutdown/gdb'
else:raise ValueError(kind)
dest.mkdir();meta={'argv':argv,'cwd':str(R),'started_utc':datetime.now(timezone.utc).isoformat(),'new_runtime':False,'new_inference':False}
with (dest/'stdout.txt').open('w') as out,(dest/'stderr.txt').open('w') as err:p=subprocess.run(argv,cwd=R,stdout=out,stderr=err,timeout=90)
meta.update(exit_code=p.returncode,ended_utc=datetime.now(timezone.utc).isoformat());(dest/'command.json').write_text(json.dumps(meta,indent=2)+'\n')
print(kind,'EXIT',p.returncode)
if kind=='replay':print((dest/'stdout.txt').read_text())
assert p.returncode==0
