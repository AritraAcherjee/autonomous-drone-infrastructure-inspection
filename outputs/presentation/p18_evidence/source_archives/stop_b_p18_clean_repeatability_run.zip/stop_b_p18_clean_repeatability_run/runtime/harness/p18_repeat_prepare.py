from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,socket,ast,os
R=Path('/mnt/c/Dev/aegisinspect-p18-integration');OLD=R/'outputs/evidence/stop_b_p18_first_integrated_run_retry1';SUP=R/'outputs/evidence/stop_b_p18_retry1_dashboard_completion';E=R/'outputs/evidence/stop_b_p18_clean_repeatability_run'
assert not E.exists(),'Repeatability evidence already exists; STOP'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(args):
 p=subprocess.run(['git',*args],cwd=R,text=True,capture_output=True,check=True)
 return {'argv':['git',*args],'stdout':p.stdout,'stderr':p.stderr,'exit_code':p.returncode}
state={' '.join(a):git(a) for a in [['rev-parse','--show-toplevel'],['branch','--show-current'],['rev-parse','HEAD'],['status','--short'],['diff','--check'],['diff','--cached','--check'],['diff','--cached','--name-only']]}
assert state['rev-parse HEAD']['stdout'].strip()=='7b9ff556956c9c8995262515f53ff5382ffacf1b'
assert state['branch --show-current']['stdout'].strip()=='P18/full-integration'
assert state['status --short']['stdout']==state['diff --cached --name-only']['stdout']==''
for sub in ['git','runtime/harness','runtime/capture','sensors','localization','tf','detector','depth','spatial','p15','p16/dashboard','p16/browser','p16/shutdown','p17','provenance','tests','shutdown']:(E/sub).mkdir(parents=True,exist_ok=True)
def save(p,x):(E/p).write_text(json.dumps(x,indent=2)+'\n')
save('git/initial_state.json',state)
exclude=Path(subprocess.check_output(['git','rev-parse','--git-path','info/exclude'],cwd=R,text=True).strip());exclude=exclude if exclude.is_absolute() else R/exclude
entry='/outputs/evidence/stop_b_p18_clean_repeatability_run/'
if entry not in exclude.read_text().splitlines():
 with exclude.open('a') as f:f.write('\n'+entry+'\n')
save('git/evidence_exclusion.json',{'path':str(exclude),'entry':entry,'source_changes':'NONE'})
preserved={}
for package,count in [(OLD,285),(SUP,49),(R/'outputs/evidence/stop_b_p18_integration_base',96),(R/'outputs/evidence/stop_b_p18_first_integrated_run',200)]:
 entries=(package/'SHA256SUMS.txt').read_text().splitlines();assert len(entries)==count
 for line in entries:
  h,p=line.split('  ',1);assert sha(package/p)==h,p
 preserved[package.name]={'PASS':True,'count':count,'manifest_sha256':sha(package/'SHA256SUMS.txt')}
z=R/'outputs/cache/stop_b_p18_first_integrated_run_retry1.zip';assert sha(z)=='afdf4aa12d589c5984d637fcb122f6ef2a810cfa1111434e9135fee63f3d2f2d'
save('provenance/preserved_before.json',{'packages':preserved,'retry_zip_sha256':sha(z),'dashboard_supplement_zip_supplied_sha256':'b52cf8db39c0a0fb936dc25eaf9f3a1af83b26a4310a3ee1e8fc5a671d28ae61','dashboard_supplement_zip_verification':'Not present under local outputs; its 49-artifact directory independently verified.'})
sources=json.loads((OLD/'provenance/source_hashes.json').read_text())
for item in sources:assert sha(item['path'])==item['sha256'],item['path']
assert len(sources)==102
save('provenance/source_hashes.json',sources)
assets=json.loads((OLD/'runtime/capture/assets.json').read_text())
assets.update(runtime_id=E.name,inspection_id=2026091904,repeatability_run=True)
assets.pop('retry_number')
assert sha(assets['checkpoint'])==assets['checkpoint_sha256']
save('runtime/capture/assets.json',assets)
bindings=[]
for name in ['evidence.py','p18_worker.py','p18_downstream.py']:
 src=OLD/'runtime/harness'/name;dest=E/'runtime/harness'/name;text=src.read_text()
 if name=='evidence.py':
  assert text.count(OLD.name)==1;text=text.replace(OLD.name,E.name)
 dest.write_text(text)
 bindings.append({'file':name,'accepted_source':str(src),'accepted_sha256':sha(src),'new_sha256':sha(dest),'difference':'Only PACKAGE directory binding' if name=='evidence.py' else 'Byte-identical'})
save('provenance/harness_bindings.json',bindings)
save('provenance/execution_identity.json',{'run_type':'CLEAN REPEATABILITY','authorized_attempts':1,'production_supervisor':str(R/'scripts/p18/supervisor.py'),'supervisor_sha256':sha(R/'scripts/p18/supervisor.py'),'supervisor_unchanged':True,'raw_legacy_labels_note':'Unchanged first-run supervisor/worker/downstream code retains first-run prose and a hard-coded REPEATABILITY_RUN=false safety label. This file and runtime_id are authoritative for current execution type; no launch/gate/scientific logic is modified to relabel it. START/RESET counters remain the actual counters.','previous_p15_id_must_not_be_reused':'P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd','clean_database_target':str(E/'p16/p18.sqlite3')})
assert not (E/'p16/p18.sqlite3').exists()
for name in ['p18_dashboard_browser_start.ps1','p18_dashboard_capture.ps1','p18_dashboard_cleanup.ps1']:
 src=SUP/'browser'/name;(E/'runtime/harness'/name).write_bytes(src.read_bytes())
save('provenance/browser_templates.json',{name:{'source':str(SUP/'browser'/name),'sha256':sha(SUP/'browser'/name)} for name in ['p18_dashboard_browser_start.ps1','p18_dashboard_capture.ps1','p18_dashboard_cleanup.ps1']})
sys.path.insert(0,str(E/'runtime/harness'))
from evidence import inventory
inv=inventory();assert inv['count']==0;save('runtime/initial_processes.json',inv)
for port in [8518]:
 with socket.socket() as s:s.bind(('127.0.0.1',port))
core=tempfile.mkdtemp(prefix='aegis-p18-repeat-core.')
save('runtime/preparation.json',{'core_directory':core,'SOURCE_CHANGES':'NONE','RELEVANT_RESIDUAL_PROCESS_COUNT':0,'source_hashes_verified':102,'checkpoint_sha256':assets['checkpoint_sha256'],'model_used':'Current Codex session; exact identity not exposed','reasoning_level':'Not exposed','model_transition':False,'requested_models':'Sol Medium runtime; Terra packaging if available'})
(E/'runtime/harness/p18_repeat_prepare.py').write_bytes(Path('/tmp/p18_repeat_prepare.py').read_bytes())
print(json.dumps({'prepared':str(E),'core':core,'sources':len(sources),'initial_residuals':0,'inspection_id':assets['inspection_id']},indent=2))
