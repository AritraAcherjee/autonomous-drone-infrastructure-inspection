"""Offline collection after the sole repeatability execution; never launch runtime."""
from pathlib import Path
from collections import defaultdict,Counter
from datetime import datetime,timezone
import json,hashlib,sys,subprocess,re,shutil,struct,sqlite3
R=Path('/mnt/c/Dev/aegisinspect-p18-integration');E=R/'outputs/evidence/stop_b_p18_clean_repeatability_run';C=E/'runtime/capture';OLD=R/'outputs/evidence/stop_b_p18_first_integrated_run_retry1';SUP=R/'outputs/evidence/stop_b_p18_retry1_dashboard_completion'
sys.path.insert(0,str(E/'runtime/harness'))
from evidence import inventory,digest,save
def read(rel):return json.loads((E/rel).read_text(encoding='utf-8-sig'))
def rows(name):
 p=C/(name+'.jsonl');return [json.loads(line) for line in p.read_text().splitlines() if line] if p.exists() else []
def put(rel,obj):
 p=E/rel;assert not p.exists(),p;save(p,obj)
result=read('runtime/capture/result.json')
assert read('runtime/launch_command.json').get('ended_utc'),'Supervisor has not ended'
put('runtime/accounting.json',{'run_type':'CLEAN REPEATABILITY','runtime_invocations':1,'P13_START_CALL_COUNT':result['safety']['P13_START_CALL_COUNT'],'RESET_CALL_COUNT':result['safety']['RESET_CALL_COUNT'],'execution_consumed':bool(result['safety']['P13_START_CALL_COUNT']),'automatic_retry':False,'legacy_label_correction':'The unchanged supervisor labels REPEATABILITY_RUN=false; this authorized execution is repeatability. Raw file is retained unchanged; this changes no runtime behavior.'})
inv=inventory();put('shutdown/final_linux_inventory.json',inv);assert inv['count']==0
ps=r'''$p=@(Get-CimInstance Win32_Process | Where-Object {$_.ProcessId -ne $PID -and (($_.Name -eq 'chrome.exe' -and $_.CommandLine -like '*p18_repeatability_profile*') -or ($_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*-File*' -and $_.CommandLine -like '*stop_b_p18_clean_repeatability_run*'))}); @{count=$p.Count;processes=@($p|Select-Object ProcessId,ParentProcessId,CommandLine)} | ConvertTo-Json -Depth 5'''
argv=['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-Command',ps]
p=subprocess.run(argv,capture_output=True,text=True,timeout=20)
put('shutdown/final_windows_inventory.json',{'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
assert p.returncode==0 and json.loads(p.stdout)['count']==0
sources=read('provenance/source_hashes.json')
for item in sources:assert digest(item['path'])==item['sha256'],item['path']
put('provenance/frozen_sources_after.json',{'PASS':True,'verified_inputs':len(sources),'inputs':sources})
before=read('provenance/preserved_before.json');after={}
for name,meta in before['packages'].items():
 package=E.parent/name;entries=(package/'SHA256SUMS.txt').read_text().splitlines()
 assert digest(package/'SHA256SUMS.txt')==meta['manifest_sha256']
 assert len(entries)==meta['count']
 for line in entries:
  h,rel=line.split('  ',1);assert digest(package/rel)==h,rel
 after[name]=meta
assert digest(R/'outputs/cache/stop_b_p18_first_integrated_run_retry1.zip')==before['retry_zip_sha256']
put('provenance/preserved_after.json',{'PASS':True,'packages':after,'retry_zip_sha256':before['retry_zip_sha256'],'dashboard_supplement_zip_note':before['dashboard_supplement_zip_verification']})
git={}
for args in [['rev-parse','--show-toplevel'],['branch','--show-current'],['rev-parse','HEAD'],['status','--short'],['diff','--check'],['diff','--cached','--check'],['diff','--cached','--name-only']]:
 p=subprocess.run(['git',*args],cwd=R,text=True,capture_output=True,check=True);git[' '.join(args)]={'stdout':p.stdout,'stderr':p.stderr,'exit_code':p.returncode}
assert git['rev-parse HEAD']['stdout'].strip()=='7b9ff556956c9c8995262515f53ff5382ffacf1b'
assert git['status --short']['stdout']==git['diff --cached --name-only']['stdout']==''
put('git/final_state.json',git)
events=rows('events')
put('runtime/launch_sequence.json',[r for r in events if r['event']=='launch'])
put('shutdown/parent_statuses.json',[r for r in events if r['event']=='parent_wait'])
children=[]
for log in sorted(C.glob('*.log')):
 for line in log.read_text(errors='replace').splitlines():
  dead=re.search(r'process has died \[pid (\d+), exit code (-?\d+), cmd (.*)\]',line)
  clean=re.search(r'process has finished cleanly \[pid (\d+)\]',line)
  if dead:children.append({'pid':int(dead[1]),'returncode':int(dead[2]),'log':str(log.relative_to(E)),'line':line})
  elif clean:children.append({'pid':int(clean[1]),'returncode':0,'log':str(log.relative_to(E)),'line':line})
put('shutdown/all_child_statuses.json',children)
core_dir=Path(read('runtime/preparation.json')['core_directory']);cores=[]
for core in sorted(core_dir.glob('core*')):
 if core.is_file():
  dest=E/'shutdown'/core.name;assert not dest.exists();shutil.copyfile(core,dest);assert digest(core)==digest(dest)
  cores.append({'source':str(core),'preserved':str(dest),'bytes':dest.stat().st_size,'sha256':digest(dest)})
put('shutdown/core_preservation.json',cores)
bridge=[r for r in children if 'parameter_bridge' in r['line']]
put('shutdown/vendor_initial_assessment.json',{'bridge':bridge,'controlled_shutdown':read('runtime/capture/shutdown_start.json'),'cores':cores,'raw_runtime_pass':result['runtime_pass'],'primary_errors':result['errors'],'RELEVANT_RESIDUAL_PROCESS_COUNT':0,'note':'If SIGSEGV occurred, stack/timing evidence must be inspected before final classification.'})

stats={}
start=read('runtime/capture/start_invocation.json') if (C/'start_invocation.json').exists() else None
for stream in ['clock','lidar','native','canonical','tf','imu']:
 samples=rows(stream)
 if not samples:continue
 item={'count':len(samples),'first_stamp_ns':samples[0]['stamp_ns'],'last_stamp_ns':samples[-1]['stamp_ns'],'maximum_callback_gap_sec':max((b['monotonic']-a['monotonic'] for a,b in zip(samples,samples[1:])),default=0)}
 if 'valid' in samples[0]:item['all_valid']=all(r['valid'] for r in samples)
 if stream in ('native','canonical'):
  item['all_frames_valid']=all(r['frame_id']=='odom' and r['child_frame_id']=='base_link' for r in samples)
  item['quaternion_norm_range']=[min(r['quaternion_norm'] for r in samples),max(r['quaternion_norm'] for r in samples)]
 if start:
  prior=[r for r in samples if r['utc']<=start['utc']]
  if prior:item['age_at_start_sec']=datetime.fromisoformat(start['utc']).timestamp()-datetime.fromisoformat(prior[-1]['utc']).timestamp()
 stats[stream]=item
put('runtime/liveness_summary.json',{'unchanged_guard_sec':2.0,'streams':stats,'failures':rows('failures')})
frames=rows('sensor_frames');frame_summary={}
for stream in sorted({r['stream'] for r in frames}):
 data=[r for r in frames if r['stream']==stream];frame_summary[stream]={'count':len(data),'frames':sorted({r['frame_id'] for r in data}),'first_stamp_ns':data[0]['stamp_ns'],'last_stamp_ns':data[-1]['stamp_ns']}
put('sensors/summary.json',{'frames':frame_summary,'other_streams':stats,'selected_cdr_hashes':{str(p.relative_to(E)):digest(p) for p in C.glob('selected*.cdr')}})
if (C/'icp_odometry_parameters.json').exists():
 params=read('runtime/capture/icp_odometry_parameters.json');oldparams=json.loads((OLD/'runtime/capture/icp_odometry_parameters.json').read_text())
 put('localization/configuration_comparison.json',{'full_parameter_dictionary_equal':params==oldparams,'current':params,'accepted_first_run':oldparams})
 assert params==oldparams
if (C/'worker_ready.json').exists():
 ready=read('runtime/capture/worker_ready.json');oldready=json.loads((OLD/'runtime/capture/worker_ready.json').read_text())
 assert ready['inference_arguments']==oldready['inference_arguments']
 put('detector/configuration_comparison.json',{'inference_arguments_equal':True,'arguments':ready['inference_arguments'],'checkpoint_sha256':ready['model']['checkpoint_sha256'],'model':'DET-FINAL-v1'})
if (C/'mapped_defect.json').exists():
 mapped=read('runtime/capture/mapped_defect.json');gids=read('runtime/capture/gid_owners.json');edges=defaultdict(set)
 for row in rows('tf')+rows('tf_static'):edges[(row['parent'],row['child'])].add(row['gid'])
 expected={('map','odom'):'/aegis/mapping/session_map_origin',('odom','base_link'):'/vio_adapter',('base_link','lidar_link'):'/aegis/robot_state_publisher',('base_link','imu_link'):'/aegis/robot_state_publisher',('base_link','camera_link'):'/aegis/robot_state_publisher',('camera_link','camera_optical_frame'):'/aegis/robot_state_publisher'}
 for edge,owner in expected.items():assert len(edges[edge])==1 and gids[next(iter(edges[edge]))]==owner
 lookups=rows('timestamped_lookup_attempts');assert all(not r['latest_fallback'] for r in lookups)
 assert mapped['P15_record']['defect_id']!='P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd'
 assert start and mapped['map_projection']['stamp_ns']>start['simulation_stamp_ns']
 assert rows('mapped_observation_traffic')[0]['payload']==mapped
 selected=[r for r in rows('detector_observations') if r['detection']==mapped['detection']];assert len(selected)==1 and selected[0]['projection_status']==0
 put('tf/ownership_derived.json',{'PASS':True,'edges':[{'parent':p,'child':c,'gids':sorted(g),'owners':[gids[x] for x in sorted(g)]} for (p,c),g in sorted(edges.items())],'competing_owners':0,'LATEST_TF_FALLBACK':'NO'})
 put('depth/summary.json',read('runtime/capture/depth_provenance.json'))
 put('spatial/summary.json',{'projection':mapped['map_projection'],'lookups':lookups,'exact_time':mapped['map_projection']['stamp_ns']==mapped['map_projection']['transform_stamp_ns']})
 put('detector/summary.json',{'selected':selected[0],'progress':read('runtime/capture/detector_progress.json'),'projection_outcomes':dict(Counter(r['projection_detail'] for r in rows('detector_observations')))})
 for src,dst in [('mapped_defect.json','mapped_defect.json'),('p15_state.json','state.json'),('p16_handoff_dto.json','p16_handoff_dto.json'),('p15_replay_dto.json','replay_dto.json')]:
  shutil.copyfile(C/src,E/'p15'/dst);assert digest(C/src)==digest(E/'p15'/dst)
 put('provenance/archival_copy_note.json',{'p15_artifacts':'Byte-identical copies from this runtime/capture; no reconstruction or substituted observation.'})
if (E/'provenance/lineage.json').exists():
 lineage=read('provenance/lineage.json');persisted=read('p16/persisted_record.json')
 assert lineage['detection']==mapped['detection']
 assert lineage['p15']['defect_id']==lineage['p16']['defect_id']==persisted['defect_id']
 assert persisted['confidence']==mapped['detection']['confidence']
 assert [persisted[k] for k in ['x_m','y_m','z_m']]==mapped['map_projection']['map_xyz']
 for obj,key,hkey in [(lineage['source_image'],'path','sha256'),(lineage['p15'],'artifact','sha256'),(lineage['p16'],'database','database_sha256'),(lineage['p17'],'report','sha256')]:assert digest(obj[key])==obj[hkey]
 screenshots={}
 for shot in sorted((E/'p16/dashboard').glob('*.png')):
  header=shot.read_bytes()[:24];assert header[:8]==b'\x89PNG\r\n\x1a\n';screenshots[shot.name]={'sha256':digest(shot),'dimensions':list(struct.unpack('>II',header[16:24]))}
 if screenshots:
  text=(E/'p16/dashboard/visible_text.txt').read_text()
  assert all(v in text for v in [persisted['defect_id'],repr(persisted['confidence']),persisted['class_name'],'UNREVIEWED','DET-FINAL-v1'])
  assert re.search(r'Observation count:\s*1',text)
  c=sqlite3.connect(Path(lineage['p16']['database']).as_uri()+'?mode=ro&immutable=1',uri=True);c.row_factory=sqlite3.Row
  stored=dict(c.execute('SELECT * FROM defects').fetchone());c.close()
  assert stored['defect_id']==persisted['defect_id'] and stored['confidence']==persisted['confidence']
  put('p16/screenshot_validation.json',{'PASS':True,'screenshots':screenshots,'record':stored,'database_sha256':digest(lineage['p16']['database']),'human_review_submitted':False})
 put('provenance/lineage_validation.json',{'SAME_OBSERVATION_LINEAGE':'PASS','runtime_id':E.name,'detection_id':lineage['detection']['detection_id'],'new_p15_id':persisted['defect_id'],'old_p15_id_reused':False,'artifact_hashes_match':True,'database_unchanged_after_browser':True,'exact_values_match':True,'interpretation':'New unreviewed detector output; no confirmed physical defect or engineering assessment.'})
put('provenance/scientific_configuration_comparison.json',{'PASS':True,'first_run':str(OLD),'production_head_unchanged':True,'source_inputs_unchanged':102,'liveness_threshold_sec':2.0,'allowed_identity_binding_changes':['evidence directory','inspection ID 2026091904','new empty database target','isolated Windows browser profile/port and new-record text readiness inputs'],'scientific_configuration_changed':False,'GT_OPERATIONAL_USE':'NO','source_changes':'NONE'})
(E/'runtime/harness/p18_repeat_collect.py').write_bytes(Path('/tmp/p18_repeat_collect.py').read_bytes())
print(json.dumps({'runtime_pass':result['runtime_pass'],'errors':result['errors'],'safety':result['safety'],'counts':result['counts'],'cores':cores,'bridge':bridge},indent=2))
