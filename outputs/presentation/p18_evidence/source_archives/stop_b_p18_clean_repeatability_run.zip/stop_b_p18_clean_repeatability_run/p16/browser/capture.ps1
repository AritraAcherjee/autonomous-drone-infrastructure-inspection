$ErrorActionPreference='Stop'
$root='C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_clean_repeatability_run\p16'
$chrome='C:\Program Files\Google\Chrome\Application\chrome.exe'
$profile='C:\Dev\aegisinspect-p18-integration\outputs\cache\p18_repeatability_profile'
$argsList=@('--headless=new','--no-first-run','--no-default-browser-check',"--user-data-dir=$profile",'--disable-gpu','--hide-scrollbars','--window-size=1920,2200','--remote-debugging-port=9244','about:blank')
$before=@(Get-NetTCPConnection -LocalPort 9244 -ErrorAction SilentlyContinue)
if ($before.Count -ne 0) { throw 'Port 9244 is not free' }
$proc=Start-Process -FilePath $chrome -ArgumentList $argsList -PassThru -RedirectStandardOutput "$root\browser\chrome_stdout.txt" -RedirectStandardError "$root\browser\chrome_stderr.txt"
$version=$null
for ($i=0;$i -lt 40;$i++) {
  try { $version=Invoke-RestMethod -Uri 'http://127.0.0.1:9244/json/version' -TimeoutSec 2; break } catch { Start-Sleep -Milliseconds 250 }
}
$listeners=@(Get-NetTCPConnection -LocalPort 9244 -State Listen -ErrorAction SilentlyContinue | Select-Object LocalAddress,LocalPort,State,OwningProcess)
$config=Join-Path $env:USERPROFILE '.wslconfig'
$processes=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'chrome.exe' -and $_.CommandLine -and $_.CommandLine.Contains($profile) } | Select-Object ProcessId,ParentProcessId,CommandLine)
$dashboardProbe=$null
try {$dashboardProbe=@{success=$true;response=(Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8518/_stcore/health' -TimeoutSec 5).Content}} catch {$dashboardProbe=@{success=$false;error=$_.Exception.Message}}
@{utc=[DateTime]::UtcNow.ToString('o');browser_side='Windows';automation_side='Windows PowerShell';chrome_path=$chrome;arguments=$argsList;root_pid=$proc.Id;listeners=$listeners;version=$version;processes=$processes;wslconfig_exists=(Test-Path $config);wslconfig_path=$config;wslconfig=$(if(Test-Path $config){Get-Content $config -Raw}else{$null});dashboard_probe=$dashboardProbe} | ConvertTo-Json -Depth 20 | Set-Content -Encoding UTF8 "$root\browser\windows_diagnosis.json"
if($null -eq $version){throw 'Windows-local CDP probe failed'}
Get-Content "$root\browser\windows_diagnosis.json" -Raw

try {
$ErrorActionPreference='Stop'
$root='C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_clean_repeatability_run\p16'
$tabs=Invoke-RestMethod -Uri 'http://127.0.0.1:9244/json/list' -TimeoutSec 5
$tab=@($tabs | Where-Object {$_.type -eq 'page'})[0]
$socket=[System.Net.WebSockets.ClientWebSocket]::new()
$socket.ConnectAsync([Uri]$tab.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult()
$script:cdpId=0
$script:events=[Collections.Generic.List[object]]::new()
function Cdp([string]$method, $parameters=@{}) {
 $script:cdpId++
 $id=$script:cdpId
 $message=@{id=$id;method=$method;params=$parameters}|ConvertTo-Json -Depth 30 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($message)
 $socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
 while($true) {
  $stream=[IO.MemoryStream]::new()
  $buffer=[byte[]]::new(1048576)
  $cancel=[Threading.CancellationTokenSource]::new(20000)
  try {
   do {
    $received=$socket.ReceiveAsync([ArraySegment[byte]]::new($buffer),$cancel.Token).GetAwaiter().GetResult()
    $stream.Write($buffer,0,$received.Count)
   } while(-not $received.EndOfMessage)
  } finally {$cancel.Dispose()}
  $text=[Text.Encoding]::UTF8.GetString($stream.ToArray());$stream.Dispose()
  $item=$text|ConvertFrom-Json
  if($item.id -eq $id) {if($null -ne $item.error){throw ($item.error|ConvertTo-Json)};return $item.result}
  if($item.method -in @('Runtime.exceptionThrown','Network.loadingFailed','Network.webSocketFrameError')) {$script:events.Add($item)}
 }
}
try {
 Cdp 'Page.enable' | Out-Null
 Cdp 'Runtime.enable' | Out-Null
 Cdp 'Network.enable' | Out-Null
 $version=Cdp 'Browser.getVersion'
 Cdp 'Emulation.setDeviceMetricsOverride' @{width=1920;height=2000;deviceScaleFactor=1;mobile=$false} | Out-Null
 Cdp 'Page.navigate' @{url='http://127.0.0.1:8518'} | Out-Null
 $required=@('P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13','0.011138029396533966','Honeycombing','UNREVIEWED','DET-FINAL-v1','Observation count:','Map XYZ (m):','Current review status:','Evidence')
 $ready=$false
 $deadline=[DateTime]::UtcNow.AddSeconds(50)
 do {
  $response=Cdp 'Runtime.evaluate' @{expression='document.body.innerText';returnByValue=$true}
  $body=$response.result.value
  $missing=@($required | Where-Object {-not $body.Contains($_)})
  if($missing.Count -eq 0){$ready=$true;break}
  Start-Sleep -Milliseconds 400
 } while([DateTime]::UtcNow -lt $deadline)
 [IO.File]::WriteAllText("$root\dashboard\visible_text.txt",$body,[Text.UTF8Encoding]::new($false))
 if(-not $ready){throw ('Dashboard missing: '+($missing -join ', '))}
 Cdp 'Runtime.evaluate' @{expression='document.fonts.ready';awaitPromise=$true;returnByValue=$true} | Out-Null
 Start-Sleep -Milliseconds 500
 $dom=Cdp 'Runtime.evaluate' @{expression='document.documentElement.outerHTML';returnByValue=$true}
 [IO.File]::WriteAllText("$root\dashboard\browser_dom.html",$dom.result.value,[Text.UTF8Encoding]::new($false))
 $layout=Cdp 'Page.getLayoutMetrics'
 $shot=Cdp 'Page.captureScreenshot' @{format='png';captureBeyondViewport=$true;fromSurface=$true}
 [IO.File]::WriteAllBytes("$root\dashboard\dashboard_overview.png",[Convert]::FromBase64String($shot.data))
 Cdp 'Emulation.setDeviceMetricsOverride' @{width=1600;height=1100;deviceScaleFactor=1;mobile=$false} | Out-Null
 Cdp 'Runtime.evaluate' @{expression="Array.from(document.querySelectorAll('h3')).find(e=>e.innerText.includes('AI suggestion')).scrollIntoView({block:'start'})";returnByValue=$true} | Out-Null
 Start-Sleep -Milliseconds 500
 $detail=Cdp 'Page.captureScreenshot' @{format='png';captureBeyondViewport=$false;fromSurface=$true}
 [IO.File]::WriteAllBytes("$root\dashboard\dashboard_detail.png",[Convert]::FromBase64String($detail.data))
 @{PASS=$true;utc=[DateTime]::UtcNow.ToString('o');browser_side='Windows';automation_side='Windows PowerShell .NET ClientWebSocket';endpoint=$tab.webSocketDebuggerUrl;dashboard_url='http://127.0.0.1:8518';browser_version=$version;required_text=$required;layout=$layout;events=$script:events;capture_method='Native Chrome Page.captureScreenshot; actual existing dashboard; no DOM content or pixel edits; viewport resize and ordinary scrolling only';review_submitted=$false;screenshots=@('dashboard_overview.png','dashboard_detail.png')} | ConvertTo-Json -Depth 30 | Set-Content -Encoding UTF8 "$root\browser\capture_result.json"
 Get-Content "$root\browser\capture_result.json" -Raw
} finally {$socket.Dispose()}

} finally {
$ErrorActionPreference='Stop'
$root='C:\Dev\aegisinspect-p18-integration\outputs\evidence\stop_b_p18_clean_repeatability_run\p16'
$profile='C:\Dev\aegisinspect-p18-integration\outputs\cache\p18_repeatability_profile'
$before=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'chrome.exe' -and $_.CommandLine -and $_.CommandLine.Contains($profile)} | Select-Object ProcessId,ParentProcessId,CommandLine)
$version=Invoke-RestMethod -Uri 'http://127.0.0.1:9244/json/version' -TimeoutSec 3
$socket=[Net.WebSockets.ClientWebSocket]::new()
$socket.ConnectAsync([Uri]$version.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$bytes=[Text.Encoding]::UTF8.GetBytes('{"id":1,"method":"Browser.close"}')
$socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$socket.Dispose()
for($i=0;$i -lt 10;$i++){
 Start-Sleep -Milliseconds 400
 $remaining=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'chrome.exe' -and $_.CommandLine -and $_.CommandLine.Contains($profile)})
 if($remaining.Count -eq 0){break}
}
@{utc=[DateTime]::UtcNow.ToString('o');method='CDP Browser.close on exact isolated instance';before=$before;remaining_count=$remaining.Count;remaining=@($remaining|Select-Object ProcessId,ParentProcessId,CommandLine)} | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 "$root\shutdown\windows_browser.json"
if($remaining.Count -ne 0){throw 'Owned browser residuals remain'}

}
