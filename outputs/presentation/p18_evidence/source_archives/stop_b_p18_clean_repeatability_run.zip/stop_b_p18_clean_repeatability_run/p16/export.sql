BEGIN TRANSACTION;
CREATE TABLE defects (
    defect_id TEXT PRIMARY KEY,

    inspection_id INTEGER NOT NULL,

    track_id TEXT,

    class_name TEXT NOT NULL,

    confidence REAL NOT NULL
        CHECK (
            confidence >= 0.0
            AND confidence <= 1.0
        ),

    x_m REAL NOT NULL,
    y_m REAL NOT NULL,
    z_m REAL NOT NULL,

    coordinate_frame TEXT NOT NULL,

    observation_count INTEGER NOT NULL
        CHECK (observation_count >= 1),

    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,

    model_version TEXT NOT NULL,

    review_status TEXT NOT NULL
        DEFAULT 'UNREVIEWED'
        CHECK (
            review_status IN (
                'UNREVIEWED',
                'CONFIRMED',
                'REJECTED',
                'NEEDS_INVESTIGATION'
            )
        ),

    review_notes TEXT,

    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,

    FOREIGN KEY (inspection_id)
        REFERENCES inspections(inspection_id)
        ON DELETE CASCADE
);
INSERT INTO "defects" VALUES('P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13',2026091904,NULL,'Honeycombing',1.1138029396533966e-02,3.88815829034595106e+00,7.11832151645037658e-02,-3.4923355787129795e-03,'map',1,'1970-01-01T00:00:28.249000Z','1970-01-01T00:00:28.249000Z','DET-FINAL-v1','UNREVIEWED',NULL,'2026-09-19T21:27:00Z','2026-09-19T21:27:00Z');
CREATE TABLE evidence (
    evidence_id INTEGER PRIMARY KEY AUTOINCREMENT,

    defect_id TEXT NOT NULL,

    frame_id TEXT NOT NULL,

    timestamp TEXT NOT NULL,

    image_path TEXT,
    crop_path TEXT,

    confidence REAL NOT NULL
        CHECK (
            confidence >= 0.0
            AND confidence <= 1.0
        ),

    bbox_x1 REAL NOT NULL,
    bbox_y1 REAL NOT NULL,
    bbox_x2 REAL NOT NULL,
    bbox_y2 REAL NOT NULL,

    FOREIGN KEY (defect_id)
        REFERENCES defects(defect_id)
        ON DELETE CASCADE,

    UNIQUE (
        defect_id,
        frame_id,
        bbox_x1,
        bbox_y1,
        bbox_x2,
        bbox_y2
    )
);
INSERT INTO "evidence" VALUES(1,'P15D-9b8ae056-1255-5cf4-ba40-e57a11f35e13','camera_optical_frame','1970-01-01T00:00:28.249000Z','/mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_clean_repeatability_run/runtime/capture/rgb_28249000000.png',NULL,1.1138029396533966e-02,14.036376953125,0.0,6.288465576171875e+02,480.0);
CREATE TABLE inspections (
    inspection_id INTEGER PRIMARY KEY AUTOINCREMENT,
    structure_id INTEGER NOT NULL,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    status TEXT NOT NULL
        CHECK (
            status IN (
                'PLANNED',
                'RUNNING',
                'PROCESSING',
                'REVIEW',
                'COMPLETED',
                'FAILED'
            )
        ),
    system_version TEXT NOT NULL,
    notes TEXT,
    FOREIGN KEY (structure_id)
        REFERENCES structures(structure_id)
        ON DELETE RESTRICT
);
INSERT INTO "inspections" VALUES(2026091904,1,'2026-09-19T21:26:09.942525Z',NULL,'PROCESSING','P18 7b9ff556956c9c8995262515f53ff5382ffacf1b','Detector classification: Honeycombing. Full detector confidence: 0.011138029396533966. Unreviewed machine output; no physical defect confirmation, engineering diagnosis or structural safety conclusion is asserted. Source observation is ROS simulation time 28249000000 ns. First/last seen and evidence timestamps are its epoch encoding, not wall-clock capture time. Map coordinates are metric and session-local to the operational odometry origin; no globally drift-corrected SLAM or ground-truth correction is used.');
CREATE TABLE structures (
    structure_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    location_text TEXT,
    created_at TEXT NOT NULL
);
INSERT INTO "structures" VALUES(1,'P18 Stop-B inspection_bay simulation session','Simulated infrastructure scene; container for this P18 runtime detector output.',NULL,'2026-09-19T21:27:00Z');
CREATE INDEX idx_structures_name
ON structures(name);
CREATE INDEX idx_inspections_structure
ON inspections(structure_id);
CREATE INDEX idx_inspections_status
ON inspections(status);
CREATE INDEX idx_defects_inspection
ON defects(inspection_id);
CREATE INDEX idx_defects_class
ON defects(class_name);
CREATE INDEX idx_defects_review_status
ON defects(review_status);
CREATE INDEX idx_defects_confidence
ON defects(confidence);
CREATE INDEX idx_defects_inspection_review
ON defects(inspection_id, review_status);
CREATE INDEX idx_evidence_defect
ON evidence(defect_id);
CREATE INDEX idx_evidence_defect_timestamp
ON evidence(defect_id, timestamp);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('structures',1);
INSERT INTO "sqlite_sequence" VALUES('inspections',2026091904);
INSERT INTO "sqlite_sequence" VALUES('evidence',1);
COMMIT;
