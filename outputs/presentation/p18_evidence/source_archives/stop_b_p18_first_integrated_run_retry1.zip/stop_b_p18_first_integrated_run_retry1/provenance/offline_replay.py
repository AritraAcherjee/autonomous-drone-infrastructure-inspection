"""Offline validation of recorded real inputs; no ROS runtime or new inference."""
from dataclasses import asdict
import json
from math import isclose
from pathlib import Path
import sys
from rclpy.duration import Duration
from rclpy.serialization import deserialize_message
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import Point, TransformStamped
from tf2_ros import Buffer
from aegisinspect_interfaces.srv import ProjectCamera
from aegisinspect_mapping.camera_projection import project
from aegisinspect_mapping.spatial_projection import camera_to_map, TfOwnership, simulation_datetime
from evidence import ROOT, save

sys.path.insert(0, '/mnt/c/Dev/aegisinspect-p18-integration')
from src.defect_mapping import MappedObservation, create_state, ingest_observation, export_state

run = ROOT
recorded = json.loads((run/'mapped_defect.json').read_text())
image = deserialize_message((run/'selected_rgb_monitor.cdr').read_bytes(), Image)
depth = deserialize_message((run/'selected_depth_monitor.cdr').read_bytes(), Image)
info = deserialize_message((run/'selected_info_monitor.cdr').read_bytes(), CameraInfo)
worker_image = deserialize_message((run/'selected_rgb.cdr').read_bytes(), Image)
assert worker_image == image
request = ProjectCamera.Request(header=image.header, mode=1)
request.left, request.top, request.right, request.bottom = recorded['roi']
camera = project(request, depth, info)
assert camera.status == 0
response = ProjectCamera.Response(header=image.header, status=0, point=Point(x=camera.xyz[0], y=camera.xyz[1], z=camera.xyz[2]))
buffer = Buffer(cache_time=Duration(seconds=120))
owners = TfOwnership()
gids = json.loads((run/'gid_owners.json').read_text())
for filename, static in (('tf_static.jsonl', True), ('tf.jsonl', False)):
    for line in (run/filename).read_text().splitlines():
        row = json.loads(line)
        tf = TransformStamped()
        tf.header.frame_id, tf.child_frame_id = row['parent'], row['child']
        tf.header.stamp.sec, tf.header.stamp.nanosec = divmod(row['stamp_ns'], 10**9)
        tf.transform.translation.x, tf.transform.translation.y, tf.transform.translation.z = row['translation']
        q = tf.transform.rotation
        q.x, q.y, q.z, q.w = row['rotation']
        owners.observe(row['parent'], row['child'], row['gid'])
        (buffer.set_transform_static if static else buffer.set_transform)(tf, gids[row['gid']])
mapped = camera_to_map(buffer, image.header, response, owners, gids)
for field in ('camera_xyz','map_xyz','translation','quaternion_xyzw'):
    assert all(isclose(a,b,rel_tol=0,abs_tol=1e-12) for a,b in zip(getattr(mapped,field),recorded['map_projection'][field]))
assert mapped.stamp_ns == recorded['map_projection']['stamp_ns'] == mapped.transform_stamp_ns
data = dict(recorded['P15_observation'])
data['timestamp'] = simulation_datetime(mapped.stamp_ns)
data['bbox_xyxy'] = tuple(data['bbox_xyxy'])
data['x_m'], data['y_m'], data['z_m'] = mapped.map_xyz
observation = MappedObservation(**data)
created = ingest_observation(create_state(observation.inspection_id), observation)
assert export_state(created.new_state) == json.loads((run/'p15_state.json').read_text())
save(ROOT/'offline_replay_validation.json', {'PASS':True,
    'new_runtime':False,'new_inference':False,'new_scientific_observation':False,
    'raw_worker_rgb_equals_monitor_rgb':True,'raw_depth_camera_info_projection_match':True,
    'actual_recorded_TF_exact_time_replay_match':True,'P15_state_exact_match':True,
    'observation_stamp_ns':mapped.stamp_ns,'replayed_map_projection':asdict(mapped)})
print('RAW_RGB_DEPTH_CAMERAINFO_ACTUAL_TF_P15_REPLAY=PASS')
