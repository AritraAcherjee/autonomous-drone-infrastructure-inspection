"""Write the completed retry report and hash its immutable evidence package."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
from datetime import datetime, timezone

R = Path('/mnt/c/Dev/aegisinspect-p18-integration')
E = R/'outputs/evidence/stop_b_p18_first_integrated_run_retry1'
def load(rel):
    return json.loads((E/rel).read_text())
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
tests = load('tests/summary.json')
lineage = load('provenance/lineage.json')
git = load('git/final_state.json')
launches = load('runtime/launch_sequence.json')
liveness = load('runtime/liveness_validation.json')['streams']
stats = load('detector/summary.json')['projection_outcomes']
children = load('shutdown/all_child_and_parent_statuses.json')
native = liveness['native']
def format_command(c):
    argv = c['argv']
    if argv[:4] == ['bash','--noprofile','--norc','-c']:
        return argv[4].rstrip()
    return shlex.join(argv)
launch_text = '\n'.join(f"{n}. `{row['name']}` (PID {row['pid']}, {row['utc']}):\n\n   ```bash\n   {shlex.join(row['argv'])}\n   ```\n" for n,row in enumerate(launches,1))
test_text = '\n'.join(f"{name}: **{spec['passed']} passed" + (f", {spec['subtests']} subtests passed" if spec['subtests'] else '') + "**; exit 0.\n\n```bash\n" + format_command(spec['command']) + "\n```\n" for name,spec in tests.items() if name in ('focused','ros_integration','p15_p16_p17'))
child_text = '\n'.join(f"| {row['pid']} | {row['returncode']} | `{row['log']}` |" for row in children['children'])
report = f'''# P18 FIRST INTEGRATED RUN — BLOCKED

The one authorized retry reached a genuine DET-FINAL-v1 → depth → camera XYZ → timestamped map XYZ → P15 → P16 → deterministic P17 data chain. It remains BLOCKED because the required dashboard browser screenshot could not be captured: `DASHBOARD_BROWSER_CAPTURE_FAILED`. Streamlit AppTest rendered the real persisted record successfully, but that does not replace the missing screenshot. No additional runtime or screenshot retry was attempted.

## A. Harness correction

The preserved first-run supervisor was `outputs/evidence/stop_b_p18_first_integrated_run/runtime/harness/p18_supervisor.py`. Its `P18Runtime.launch`, in the `spatial_detector` branch, waited for detector readiness, checked graph/ownership, then synchronously ran `git status --short` and `git rev-parse HEAD` before START-service readiness. ROS callbacks are serviced by inherited `SpatialRuntime.step → Gate.step → rclpy.spin_once(timeout_sec=0.02)` on that same thread. Inherited `SpatialRuntime.run` enables sensor liveness after sensor readiness, before localization/map/projection/detector readiness. Blocking Git work on that path could therefore starve subscriptions while the 2.0-second guard was active.

The unchanged preserved supervisor was promoted into tracked `scripts/p18/supervisor.py`, with both Git operations relocated to `verify_integrity_before_capture()`, invoked by `main()` before `rclpy.init()` and `P18Runtime()` construction. The expected runtime HEAD is read from the provenance assets so the committed harness can validate its own post-fix identity. The only other committed file is `tests/p18/test_supervisor_integrity.py`. There is no executor/thread redesign or scientific/configuration change.

- PRE_FIX_SHA: `e5fbfeef65a2851333bb2de0a222dc1df82163a6`
- POST_FIX_SHA: `7b9ff556956c9c8995262515f53ff5382ffacf1b`
- Commit: `fix(p18): prevent pre-start supervisor callback starvation`
- Exactly one new commit; exactly the two files above.
- Focused regression: 6 PASS. It exercises the actual entrypoint ordering with 2.1 seconds of slow integrity work before capture, rejects invalid integrity before ROS initialization, and executes the unchanged accepted guard to prove real clock/LiDAR staleness over 2.0 seconds still fails.
- The production liveness threshold remains exactly 2.0 seconds. Native odometry, canonical odometry, TF ownership, sensors and scientific settings remain frozen.

Exact original path/architecture: [patch/path_audit.json](patch/path_audit.json). Exact relocation diff against the preserved harness: [patch/supervisor_vs_preserved_harness.diff](patch/supervisor_vs_preserved_harness.diff). Exact committed diff: [patch/committed_source.diff](patch/committed_source.diff).

The runtime integrity check completed at `2026-09-19T20:31:38.661071+00:00`; observer creation was logged at `2026-09-19T20:31:39.150024+00:00`. No `ACTIVE_STREAM_LOST` failure recurred. Maximum recorded callback intervals were {liveness['lidar']['maximum_callback_interval_since_first_sample_sec']:.9f} s for LiDAR, {native['maximum_callback_interval_since_first_sample_sec']:.9f} s for native odometry, {liveness['canonical']['maximum_callback_interval_since_first_sample_sec']:.9f} s for canonical odometry, and {liveness['tf']['maximum_callback_interval_since_first_sample_sec']:.9f} s for TF. See [runtime/liveness_validation.json](runtime/liveness_validation.json).

## B. Git and validation

- Canonical repository: `/mnt/c/Dev/autonomous-drone-infrastructure-inspection`
- Worktree: `/mnt/c/Dev/aegisinspect-p18-integration`
- Branch: `P18/full-integration`
- HEAD and cached/live remote HEAD: `7b9ff556956c9c8995262515f53ff5382ffacf1b`
- Cached ahead/behind: `0 / 0`; normal push succeeded; LIVE_REMOTE_VERIFICATION={git['LIVE_REMOTE_VERIFICATION']}.
- Worktree CLEAN, staged files 0, `git diff --check` PASS, `git diff --cached --check` PASS.
- The P18 integration merge remains `e5fbfeef65a2851333bb2de0a222dc1df82163a6`; history was not rewritten.
- P17 predecessor remains unchanged at Git-authoritative 40-character `eb4013fa236ab758c6b84e1a3ae02579bbfe488f`, with a clean worktree. The extra-9 spelling in earlier prose is not a Git object identity.

Fresh preflight validation: **707 tests + 6 subtests PASS; 0 failures, 0 skips, 0 deselections**. This comprises 6 harness tests plus the accepted 701-test integration surface. No new ROS build was applicable: only the external supervisor and Python tests changed. All 100 prior scientific/source/configuration hashes matched, and the accepted seven-package targeted build remains applicable. Fresh overlay-prefix/linkage/import checks passed. The final hash audit verifies all 102 recorded inputs including the two new files. See [tests/summary.json](tests/summary.json), [patch/build_applicability.json](patch/build_applicability.json), and [git/final_state.json](git/final_state.json).

{test_text}

Offline replay after shutdown also passed using the already-recorded RGB/depth/CameraInfo/actual TF and P15 state; it did not initialize a new runtime or run inference. Exact command: [tests/offline_recorded_observation_replay/command.json](tests/offline_recorded_observation_replay/command.json).

## C. Retry accounting

- Retry launched: YES; runtime invocations: 1.
- P13_START_CALL_COUNT=1; RESET_CALL_COUNT=0.
- Retry consumed: YES.
- START requested at `2026-09-19T20:32:19.693058+00:00`; response `START accepted.` at `2026-09-19T20:32:19.800364+00:00` (simulation stamp `21611000000` ns).
- Pre-launch relevant residual process count: 0. All pre-START gates ran with their existing standards. Detector initialized before START.
- The clock subsequently reached `53726000000` ns, 32.115 simulation seconds after the START response. The frozen motion schedule is 20 seconds. Completion is only inferred from this captured interval; the final supervisor completion gate was not reached after the screenshot blocker. There is no separate captured final P13 state assertion.
- No second retry, repeatability run, final Stop-B freeze, canonical-main merge, Stop C or navigation work occurred.

See [runtime/start_accounting.json](runtime/start_accounting.json), [runtime/preflight.json](runtime/preflight.json), and [runtime/p13_state_derived.json](runtime/p13_state_derived.json).

## D. Runtime, launch sequence and genuine observation

The exact supervisor environment/command is saved in [runtime/launch_command.json](runtime/launch_command.json), and the actual launch records are in [runtime/launch_sequence.json](runtime/launch_sequence.json). ROS overlay prefixes are in [runtime/package_prefixes.json](runtime/package_prefixes.json). The capture supervisor was run as follows from the P18 worktree:

```bash
set -e
source /opt/ros/lyrical/setup.bash
source ros2_ws/install/local_setup.bash
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$PWD/outputs/evidence/stop_b_p18_first_integrated_run_retry1/runtime/harness:$PWD:$PYTHONPATH"
python3 -B /mnt/c/Dev/aegisinspect-p18-integration/scripts/p18/supervisor.py /tmp/aegis-p18-retry1-core._1k1x547
```

{launch_text}

Sensor evidence includes 48,341 clock callbacks, 537 valid LiDAR clouds, RGB/depth/CameraInfo frame metadata and serialized selected messages, and 10,291 IMU callbacks. Native ICP and canonical odometry each provided 308 valid recorded updates; `/vio_adapter` remained the sole actual `odom → base_link` owner. `/aegis/mapping/session_map_origin` owned the fixed session-local `map → odom` relation. `/aegis/robot_state_publisher` owned all four sensor extrinsics. No competing owner was found in actual TF edge messages. The ICP publisher endpoint does not imply it published the operational TF edge. All captured GT topic graphs had zero subscribers; GT_OPERATIONAL_USE=NO. No globally drift-corrected SLAM claim is made.

The selected genuine retry observation is:

| Field | Exact value |
| --- | --- |
| Detector | DET-FINAL-v1 |
| Checkpoint SHA-256 | `4c7a32c9b40c0795bbe59aca5952a0631e1524ec731ad2c7441cccb1b44f71c3` |
| Detection ID | `28.678000000-0` |
| Detector classification | Honeycombing, class ID 2 |
| Detector confidence | `0.026687312871217728` |
| Observation time | `28678000000` ns = 28.678 s ROS simulation time |
| Epoch encoding | `1970-01-01T00:00:28.678000Z` — simulation time, not wall-clock capture time |
| Original image | 640 × 480, `camera_optical_frame` |
| Original bbox XYXY | `[1.27386474609375, 3.7222900390625, 638.5529174804688, 480.0]` |
| Integer ROI | `[1, 3, 639, 480]` |
| Central depth region | `[160, 122, 479, 361]` |
| Valid / invalid depth samples | 76,241 / 0 |
| Metric optical-axis Z | `3.1262271404266357` m |
| Camera optical XYZ | `[-0.0028202001772945308, 0.0056404003545890615, 3.1262271404266357]` m |
| Map XYZ | `[3.888778309118922, 0.08248358558866703, -0.041401481379500414]` m |
| Requested / returned TF stamp | `28678000000` / `28678000000` ns |
| Latest-TF fallback | NO |
| P15 defect ID | `P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd` |
| Observation count / review | 1 / UNREVIEWED |

This is low-confidence detector output. It is not a confirmed physical defect, engineering diagnosis or safety conclusion. Severity, dimensions, urgency, deterioration grade and repair recommendations were not fabricated.

Depth used the unchanged central-ROI median of finite positive metric optical Z, with 0.5 central fraction and 0.5 minimum valid fraction. RGB/depth/CameraInfo have the exact selected timestamp. Intrinsics and raw CDR are preserved. Recorded TF lookup attempts waited for the exact requested timestamp; future-extrapolation failures were retained rather than substituted with latest TF.

The worker processed 5 frames, submitted 7 detections, and recorded 2 projection successes / 5 projection rejections. All outcomes are retained; projection-detail counts are `{json.dumps(stats, sort_keys=True)}`. One selected observation was mapped and persisted. No prior accepted observation was reused, and no locked GYU data was accessed.

Source image: [runtime/capture/rgb_28678000000.png](runtime/capture/rgb_28678000000.png). Selected observation: [p15/mapped_defect.json](p15/mapped_defect.json). TF ownership: [tf/ownership_derived.json](tf/ownership_derived.json). Spatial/lookup evidence: [spatial/summary.json](spatial/summary.json). Raw logs and graph are retained under `runtime/capture/`.

## E. P15, P16 and P17

P15 created `P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd` from this retry observation. Replay returned REPLAY, with observation count unchanged at 1 and state round-trip equality. [p15/mapped_defect.json](p15/mapped_defect.json) is a byte-identical archival copy of the runtime-created artifact; no values were edited.

P16 persisted that ID and exact class/confidence/map XYZ/timestamp in inspection `2026091903` using the existing schema. SQLite integrity returned `ok` and foreign-key checks were empty. Duplicate defect and duplicate evidence inserts were rejected with `DuplicateDefectError` and `DuplicateEvidenceError`, leaving one record, one evidence row, one observation, and all fields unchanged. Review remains UNREVIEWED.

- Database: [p16/p18.sqlite3](p16/p18.sqlite3)
- Persisted record: [p16/persisted_record.json](p16/persisted_record.json)
- SQL export: [p16/export.sql](p16/export.sql)
- Idempotency: [p16/idempotency.json](p16/idempotency.json)
- Real dashboard AppTest: [p16/dashboard_apptest.json](p16/dashboard_apptest.json), PASS; no human review submitted.
- Required browser screenshot: **ABSENT**. [p16/dashboard_capture_blocker.json](p16/dashboard_capture_blocker.json) and [runtime/capture/dashboard_capture.log](runtime/capture/dashboard_capture.log) preserve the failure.

The browser helper could not connect to the isolated installed Chrome CDP endpoint within its timeout. Chrome stderr advertised a DevTools listener; a deeper networking/browser cause has not been proven. The blocked result is not a claim that P16 persistence or AppTest failed. No screenshot was fabricated and no extra capture attempt was made.

P17 report: [p17/inspection_report.md](p17/inspection_report.md). Two independent renders were identical, the database stayed unchanged, full confidence/coordinates/identity/provenance/count/simulation timestamps/review status were preserved, and unsupported engineering fields were absent. See [p17/validation.json](p17/validation.json). Report SHA-256: `{lineage['p17']['sha256']}`.

## F. Same-observation lineage

[provenance/lineage.json](provenance/lineage.json) binds DET-FINAL-v1 → detection `28.678000000-0` → robust depth → camera XYZ → exact-time map XYZ → P15 ID → P16 record → deterministic P17 report. [provenance/lineage_validation.json](provenance/lineage_validation.json) verifies recorded detector output equals the ROS mapped payload, raw worker RGB equals the independent monitor RGB, camera XYZ reprojects from captured depth/intrinsics, map XYZ replays from actual recorded TF at the observation timestamp, P15 state matches, and saved downstream hashes remain unchanged.

| Artifact | SHA-256 |
| --- | --- |
| Source image | `{lineage['source_image']['sha256']}` |
| Runtime mapped P15 artifact | `{lineage['p15']['sha256']}` |
| P16 SQLite database | `{lineage['p16']['database_sha256']}` |
| P17 report | `{lineage['p17']['sha256']}` |

This offline validation used only captured retry data; it was not another runtime/inference attempt. Passing data lineage does not waive the missing screenshot or complete the interrupted final acceptance steps.

## G. Controlled shutdown and vendor limitation

Controlled shutdown began at `2026-09-19T20:32:53.902502+00:00`, after the browser blocker and after the spatial/P16/P17 artifacts had been created. Process groups received bounded SIGINT shutdown. Linux process cleanup reached zero. A separate Windows inventory found eight processes in the exact isolated Chrome tree; root PID 34616, profile path and debug port were verified before targeted tree cleanup. Subsequent independent Windows and Linux inventories both returned zero.

PARAMETER_BRIDGE_VENDOR_TEARDOWN_DEFECT_REPRODUCED=YES. Bridge PID 1609930 received SIGINT then exited with SIGSEGV (-11). The preserved core shows a Fast DDS DataReaderImpl read/take stack and another exit thread in `tracetools_fini`/`dlclose`, matching the known teardown signature. The defect is not fixed. No bridge crash during active runtime was recorded. This shutdown recurrence is separate from the blocking screenshot failure.

The full P18 evidence package was **not complete** before shutdown because screenshots/final acceptance steps were missing. The raw inherited `runtime_evidence_complete_utc` in `runtime/capture/result.json` refers only to the spatial stage; `runtime_pass=false` and `shutdown_start.json`'s `active_runtime_evidence_complete=false` retain the actual full-run status. Raw evidence was not rewritten to hide this distinction.

| Child PID | Exit code | Log |
| --- | --- | --- |
{child_text}

All launch parents returned 0 except dashboard capture (1); Gazebo, adapter, map publisher and camera projection -2 statuses are associated with controlled SIGINT. Full parent/child records: [shutdown/all_child_and_parent_statuses.json](shutdown/all_child_and_parent_statuses.json).

Core: [shutdown/core.1609930](shutdown/core.1609930), 236,142,592 bytes, SHA-256 `85785c52a1391f3bae19e80e29688ea03d0200331024e68030728b053141eeee`. Stack: [shutdown/gdb/stdout.txt](shutdown/gdb/stdout.txt). Assessment: [shutdown/assessment.json](shutdown/assessment.json). Final residual proofs: [shutdown/final_linux_processes.json](shutdown/final_linux_processes.json), [shutdown/final_windows_browser_processes.json](shutdown/final_windows_browser_processes.json).

**RELEVANT_RESIDUAL_PROCESS_COUNT=0.**

## H. Evidence preservation and handback

Evidence directory: `/mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_first_integrated_run_retry1/`.

The original failed run remains unchanged and verifies **200/200** artifacts; the accepted integration-base package remains unchanged and verifies **96/96**. Supplied predecessor ZIP hashes are recorded in `patch/path_audit.json`; those ZIP files were not present in the inspected directories, so their bytes were not independently reverified. The actual predecessor manifests were reverified.

All files in this retry package except `SHA256SUMS.txt` itself are hashed in [SHA256SUMS.txt](SHA256SUMS.txt). Sealing command: `sha256sum --check --quiet SHA256SUMS.txt`, executed in this package. Manifest/ZIP verification receipts are stored alongside the archive in `outputs/cache/stop_b_p18_first_integrated_run_retry1.seal.json`, outside the sealed package to avoid a self-referential manifest or ZIP hash. The archive path is `outputs/cache/stop_b_p18_first_integrated_run_retry1.zip`; its SHA-256 is recorded in that receipt and a sibling `.zip.sha256` file.

**STOP AND RETURN TO 00.** The sole authorized retry is consumed. The dashboard capture blocker requires a subsequent 00 decision; no further retry, repeatability, freeze, canonical merge or Stop C action was performed.
'''
assert not (E/'REPORT.md').exists()
(E/'REPORT.md').write_text(report)
assert not (E/'SHA256SUMS.txt').exists()
files = sorted(p for p in E.rglob('*') if p.is_file())
assert not any(p.is_symlink() for p in files)
(E/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(E).as_posix()}\n' for p in files))
check = subprocess.run(['sha256sum', '--check', '--quiet', 'SHA256SUMS.txt'], cwd=E, capture_output=True, text=True)
assert check.returncode == 0, (check.stdout, check.stderr)
receipt = {'package': str(E), 'utc': datetime.now(timezone.utc).isoformat(), 'artifact_count': len(files),
           'manifest_sha256': sha(E/'SHA256SUMS.txt'), 'manifest_verification': 'PASS',
           'command': ['sha256sum','--check','--quiet','SHA256SUMS.txt'], 'exit_code': check.returncode,
           'stdout': check.stdout, 'stderr': check.stderr, 'package_bytes': sum(p.stat().st_size for p in files)}
target = R/'outputs/cache/stop_b_p18_first_integrated_run_retry1.seal.json'
assert not target.exists()
target.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
