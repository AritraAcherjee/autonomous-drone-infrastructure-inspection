"""Seal summaries of the completed, blocked retry; never start ROS or inference."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter, defaultdict
import hashlib
import json
import re
import shlex
import subprocess
import sys

REPO = Path('/mnt/c/Dev/aegisinspect-p18-integration')
E = REPO / 'outputs/evidence/stop_b_p18_first_integrated_run_retry1'
C = E / 'runtime/capture'
sys.path.insert(0, str(E / 'runtime/harness'))
from evidence import digest, inventory, save, utc

def read(rel):
    return json.loads((E / rel).read_text())

def rows(name):
    return [json.loads(s) for s in (C / (name + '.jsonl')).read_text().splitlines() if s]

def put(rel, data):
    target = E / rel
    assert not target.exists(), target
    save(target, data)

def command(argv, cwd=REPO):
    start = utc()
    result = subprocess.run(argv, cwd=cwd, text=True, capture_output=True, timeout=45)
    return {'argv': argv, 'cwd': str(cwd), 'started_utc': start, 'ended_utc': utc(),
            'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}

git = {}
for label, args in {
    'root': ['rev-parse', '--show-toplevel'], 'common_dir': ['rev-parse', '--git-common-dir'],
    'branch': ['branch', '--show-current'], 'head': ['rev-parse', 'HEAD'],
    'parents': ['show', '-s', '--format=%P', 'HEAD'],
    'message': ['show', '-s', '--format=%s', 'HEAD'],
    'commit_files': ['diff-tree', '--no-commit-id', '--name-only', '-r', 'HEAD'],
    'status': ['status', '--short'], 'staged': ['diff', '--cached', '--name-only'],
    'diff_check': ['diff', '--check'], 'cached_diff_check': ['diff', '--cached', '--check'],
    'cached_head': ['rev-parse', 'refs/remotes/origin/P18/full-integration'],
    'ahead_behind': ['rev-list', '--left-right', '--count', 'HEAD...refs/remotes/origin/P18/full-integration'],
    'fix_commit_count': ['rev-list', '--count', 'e5fbfeef65a2851333bb2de0a222dc1df82163a6..HEAD'],
}.items():
    git[label] = command(['git', *args])
    assert git[label]['exit_code'] == 0, git[label]
head = git['head']['stdout'].strip()
assert head == '7b9ff556956c9c8995262515f53ff5382ffacf1b'
assert git['branch']['stdout'].strip() == 'P18/full-integration'
assert git['parents']['stdout'].strip() == 'e5fbfeef65a2851333bb2de0a222dc1df82163a6'
assert git['fix_commit_count']['stdout'].strip() == '1'
assert git['status']['stdout'] == git['staged']['stdout'] == ''
assert git['cached_head']['stdout'].strip() == head
assert git['ahead_behind']['stdout'].split() == ['0', '0']
assert set(git['commit_files']['stdout'].splitlines()) == {'scripts/p18/supervisor.py', 'tests/p18/test_supervisor_integrity.py'}
git['live_remote'] = command(['git', 'ls-remote', '--exit-code', 'origin', 'refs/heads/P18/full-integration'])
if git['live_remote']['exit_code'] == 0:
    assert git['live_remote']['stdout'].split()[0] == head
    git['LIVE_REMOTE_VERIFICATION'] = 'PASS'
else:
    assert 'Could not resolve host' in git['live_remote']['stderr'], git['live_remote']
    git['LIVE_REMOTE_VERIFICATION'] = 'BLOCKED_BY_NETWORK'
git['p17_status'] = command(['git', 'status', '--short'], Path('/mnt/c/Dev/aegisinspect-p17-reporting'))
git['p17_head'] = command(['git', 'rev-parse', 'HEAD'], Path('/mnt/c/Dev/aegisinspect-p17-reporting'))
assert git['p17_status']['stdout'] == '' and git['p17_status']['exit_code'] == 0
assert git['p17_head']['stdout'].strip() == 'eb4013fa236ab758c6b84e1a3ae02579bbfe488f'
put('git/final_state.json', git)

preserved = {}
for name, count in [('stop_b_p18_integration_base', 96), ('stop_b_p18_first_integrated_run', 200)]:
    package = E.parent / name
    entries = (package / 'SHA256SUMS.txt').read_text().splitlines()
    checked = []
    for line in entries:
        expected, rel = line.split('  ', 1)
        actual = digest(package / rel)
        assert actual == expected, (name, rel)
        checked.append({'path': rel, 'sha256': actual})
    assert len(checked) == count
    preserved[name] = {'PASS': True, 'verified_artifacts': count,
                       'manifest_sha256': digest(package / 'SHA256SUMS.txt'), 'entries': checked}
put('provenance/preserved_packages_final_verification.json', preserved)
source_hashes = read('provenance/source_hashes.json')
for item in source_hashes:
    assert digest(item['path']) == item['sha256'], item['path']
assert len(source_hashes) == 102
put('provenance/final_source_verification.json', {'PASS': True, 'verified_inputs': len(source_hashes), 'inputs': source_hashes})

linux = inventory()
assert linux['count'] == 0
put('shutdown/final_linux_processes.json', linux)
ps = "$ErrorActionPreference='Stop'; $profile='C:\\Dev\\aegisinspect-p18-integration\\outputs\\cache\\p18_browser_profile'; $remaining=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'chrome.exe' -and $_.CommandLine -and $_.CommandLine.Contains($profile) }); @{residual_count=$remaining.Count; processes=@($remaining | Select-Object ProcessId,ParentProcessId,CommandLine)} | ConvertTo-Json -Depth 4; if ($remaining.Count -ne 0) { exit 2 }"
windows = command(['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe', '-NoProfile', '-NonInteractive', '-Command', ps])
assert windows['exit_code'] == 0 and json.loads(windows['stdout'])['residual_count'] == 0, windows
put('shutdown/final_windows_browser_processes.json', windows)

result = read('runtime/capture/result.json')
start = read('runtime/capture/start_invocation.json')
response = read('runtime/capture/start_response.json')
integrity = read('git/pre_capture_integrity.json')
assert result['errors'] == ['DASHBOARD_BROWSER_CAPTURE_FAILED']
assert result['safety']['P13_START_CALL_COUNT'] == 1 and result['safety']['RESET_CALL_COUNT'] == 0
assert response['success'] and start['invocation_count'] == 1
assert integrity['utc'] < rows('supervisor_start')[0]['utc'] < start['utc']
events = rows('events')
put('runtime/launch_sequence.json', [r for r in events if r['event'] == 'launch'])
put('runtime/start_accounting.json', {'retry_launched': True, 'retry_consumed': True,
    'P13_START_CALL_COUNT': 1, 'RESET_CALL_COUNT': 0, 'runtime_invocations': 1,
    'start_invocation': start, 'start_response': response, 'additional_runtime_after_blocker': False})

liveness = {}
start_seconds = datetime.fromisoformat(start['utc']).timestamp()
for stream in ['clock', 'lidar', 'native', 'canonical', 'tf', 'imu']:
    samples = rows(stream)
    before = [r for r in samples if r['utc'] <= start['utc']]
    item = {'samples': len(samples), 'first_stamp_ns': samples[0]['stamp_ns'], 'last_stamp_ns': samples[-1]['stamp_ns'],
            'maximum_callback_interval_since_first_sample_sec': max((b['monotonic'] - a['monotonic'] for a, b in zip(samples, samples[1:])), default=0),
            'last_pre_start_callback_age_sec': start_seconds - datetime.fromisoformat(before[-1]['utc']).timestamp(),
            'post_start_samples': sum(r['utc'] > start['utc'] for r in samples)}
    if 'valid' in samples[0]:
        item['all_samples_valid'] = all(r['valid'] for r in samples)
        assert item['all_samples_valid']
    liveness[stream] = item
put('runtime/liveness_validation.json', {'unchanged_guard_sec': 2.0, 'active_stream_failures': [],
    'runtime_failure_log': rows('failures'), 'integrity_completed_before_ros_init': True,
    'integrity_utc': integrity['utc'], 'supervisor_created_utc': rows('supervisor_start')[0]['utc'],
    'streams': liveness, 'note': 'Callback intervals summarize recorded service times; all original live guards remained enabled.'})

sensor_samples = rows('sensor_frames')
sensor_summary = {}
for stream in sorted({r['stream'] for r in sensor_samples}):
    sample = [r for r in sensor_samples if r['stream'] == stream]
    sensor_summary[stream] = {'count': len(sample), 'frame_ids': sorted({r['frame_id'] for r in sample}),
                              'first_stamp_ns': sample[0]['stamp_ns'], 'last_stamp_ns': sample[-1]['stamp_ns']}
put('sensors/summary.json', {'camera_depth_info': sensor_summary, 'other_streams': liveness,
    'selected_raw_files': {str(p.relative_to(E)): digest(p) for p in C.glob('selected*.cdr')}})
put('localization/summary.json', {'native': liveness['native'], 'canonical': liveness['canonical'],
    'native_owner': '/icp_odometry', 'canonical_owner': '/vio_adapter', 'canonical_topic': '/aegis/localization/vio/odom',
    'GT_OPERATIONAL_USE': 'NO', 'scientific_parameters_changed': False,
    'parameters_artifact': 'runtime/capture/icp_odometry_parameters.json', 'accepted_scientific_ancestor': '8ff6f6ed842333565ada94b87327dfcd1a1923c2'})
clock = rows('clock')
put('runtime/p13_state_derived.json', {'START_calls': 1, 'RESET_calls': 0, 'START_accepted': True,
    'start_response_simulation_stamp_ns': response['simulation_stamp_ns'], 'last_observed_simulation_stamp_ns': clock[-1]['stamp_ns'],
    'elapsed_simulation_seconds_since_start_response': (clock[-1]['stamp_ns'] - response['simulation_stamp_ns']) / 1e9,
    'supervisor_final_completion_gate_executed': False,
    'interpretation': 'The saved clock spans the frozen 20-second motion schedule. Completion is an inference from the accepted schedule, not a separately captured final state or a completed P18 acceptance gate.',
    'trajectory_source_sha256': digest(REPO/'ros2_ws/src/aegisinspect_sim/src/deterministic_motion_system.cpp')})

gids = read('runtime/capture/gid_owners.json')
edges = defaultdict(set)
for row in rows('tf') + rows('tf_static'):
    edges[(row['parent'], row['child'])].add(row['gid'])
expected = {('map', 'odom'): '/aegis/mapping/session_map_origin', ('odom', 'base_link'): '/vio_adapter',
            ('base_link', 'lidar_link'): '/aegis/robot_state_publisher', ('base_link', 'imu_link'): '/aegis/robot_state_publisher',
            ('base_link', 'camera_link'): '/aegis/robot_state_publisher', ('camera_link', 'camera_optical_frame'): '/aegis/robot_state_publisher'}
for edge, owner in expected.items():
    assert len(edges[edge]) == 1 and gids[next(iter(edges[edge]))] == owner
assert set(edges) == set(expected)
put('tf/ownership_derived.json', {'PASS': True, 'method': 'Actual recorded TF edge publisher GIDs joined to captured ROS endpoint identities; derived offline after shutdown.',
    'edges': [{'parent': p, 'child': c, 'gids': sorted(g), 'owners': [gids[x] for x in sorted(g)]} for (p,c),g in sorted(edges.items())],
    'competing_edge_owners': 0, 'note': 'Publisher endpoints alone do not imply published TF edges. Native ICP has a TF endpoint, but recorded odom -> base_link messages came solely from /vio_adapter.'})
graph = rows('graph')[-1]
assert all(not row['topics']['/aegis/sim/ground_truth/pose']['subscriptions'] for row in rows('graph'))
put('runtime/last_captured_ros_graph.json', graph)

lineage = read('provenance/lineage.json')
mapped = read('runtime/capture/mapped_defect.json')
observations = rows('detector_observations')
selected = [r for r in observations if r['detection']['detection_id'] == lineage['detection']['detection_id']]
assert len(selected) == 1 and selected[0]['projection_status'] == 0
assert selected[0]['detection'] == lineage['detection'] == mapped['detection']
assert rows('mapped_observation_traffic')[0]['payload'] == mapped
lookups = rows('timestamped_lookup_attempts')
assert not any(r['latest_fallback'] for r in lookups)
assert any(r['success'] and r['returned_stamp_ns'] == lineage['timestamp_ns'] for r in lookups)
put('detector/summary.json', {'selected_detection': selected[0], 'ready': read('runtime/capture/worker_ready.json'),
    'progress': read('runtime/capture/detector_progress.json'), 'projection_outcomes': dict(Counter(r['projection_detail'] for r in observations)),
    'source_image': lineage['source_image'], 'interpretation': 'Low-confidence UNREVIEWED detector output; not a confirmed physical defect.'})
put('depth/summary.json', lineage['depth'])
put('spatial/summary.json', {'projection': lineage['camera_to_map'], 'lookup_attempts': lookups,
    'no_latest_tf_fallback': True, 'offline_raw_replay': read('runtime/capture/offline_replay_validation.json')})
copies = {}
for old, new in [('mapped_defect.json', 'p15/mapped_defect.json'), ('p15_state.json', 'p15/state.json'),
                 ('p15_replay_dto.json', 'p15/replay_dto.json'), ('p16_handoff_dto.json', 'p15/p16_handoff_dto.json')]:
    target = E/new
    assert not target.exists()
    target.write_bytes((C/old).read_bytes())
    assert digest(target) == digest(C/old)
    copies[new] = {'copied_from': 'runtime/capture/'+old, 'sha256': digest(target), 'method': 'byte-identical archive organization after completed runtime; no data reconstruction'}
put('provenance/artifact_copies.json', copies)
for obj, pathkey, hashkey in [(lineage['source_image'], 'path', 'sha256'), (lineage['p15'], 'artifact', 'sha256'),
                              (lineage['p16'], 'database', 'database_sha256'), (lineage['p17'], 'report', 'sha256')]:
    assert digest(obj[pathkey]) == obj[hashkey]
persisted = read('p16/persisted_record.json')
assert persisted['defect_id'] == lineage['p15']['defect_id'] == lineage['p16']['defect_id']
assert persisted['confidence'] == lineage['detection']['confidence']
assert [persisted[k] for k in ('x_m', 'y_m', 'z_m')] == lineage['camera_to_map']['map_xyz']
assert persisted['observation_count'] == 1 and persisted['review_status'] == 'UNREVIEWED'
put('provenance/lineage_validation.json', {'PASS': True, 'same_observation': True, 'observation_id': lineage['detection']['detection_id'],
    'defect_id': persisted['defect_id'], 'timestamp_ns': lineage['timestamp_ns'], 'raw_worker_monitor_rgb_equal': True,
    'raw_depth_camera_info_actual_tf_p15_replay': read('runtime/capture/offline_replay_validation.json'),
    'artifact_hashes_match': True, 'database_and_report_unchanged_since_runtime': True,
    'scope': 'Data lineage only; overall retry remains BLOCKED because required browser screenshot evidence is absent.'})

browser = read('p16/dashboard/cdp_runtime.json')
assert not list((E/'p16/dashboard').glob('*.png'))
put('p16/dashboard_capture_blocker.json', {'classification': 'DASHBOARD_BROWSER_CAPTURE_FAILED',
    'error': 'Could not connect to isolated installed Chrome CDP endpoint',
    'dashboard_apptest': 'PASS', 'browser_screenshots': [], 'cdp_runtime': browser,
    'proven_scope': 'The accepted screenshot helper did not discover a reachable CDP endpoint before its timeout. Chrome stderr advertised a DevTools listener. A deeper cause has not been proven.',
    'additional_capture_attempts': 0, 'original_logs': ['runtime/capture/dashboard_capture.log', 'p16/dashboard/cdp_browser_stderr.txt']})

child_statuses = []
for path in sorted(C.glob('*.log')):
    for line in path.read_text(errors='replace').splitlines():
        dead = re.search(r'process has died \[pid (\d+), exit code (-?\d+), cmd (.*)\]', line)
        clean = re.search(r'process has finished cleanly \[pid (\d+)\]', line)
        if dead:
            child_statuses.append({'pid': int(dead[1]), 'returncode': int(dead[2]), 'log': str(path.relative_to(E)), 'line': line})
        elif clean:
            child_statuses.append({'pid': int(clean[1]), 'returncode': 0, 'log': str(path.relative_to(E)), 'line': line})
put('shutdown/all_child_and_parent_statuses.json', {'children': child_statuses, 'parents': [r for r in events if r['event'] == 'parent_wait']})
gdb = (E/'shutdown/gdb/stdout.txt').read_text()
assert all(s in gdb for s in ['SIGSEGV', 'DataReaderImpl::take', 'tracetools_fini', 'dlclose'])
p13log = (C/'p13.log').read_text()
assert p13log.index('signal_handler(signum=2)') < p13log.index('exit code -11')
assert any(r['pid'] == 1609930 and r['returncode'] == -11 for r in child_statuses)
put('shutdown/assessment.json', {'PARAMETER_BRIDGE_VENDOR_TEARDOWN_DEFECT_REPRODUCED': 'YES',
    'bridge_pid': 1609930, 'exit_code': -11, 'controlled_shutdown_utc': result['shutdown_start_utc'],
    'after_controlled_shutdown_began': True, 'after_selected_spatial_and_p16_p17_evidence': True,
    'full_required_evidence_complete': False,
    'stack_signature': 'Fast DDS DataReaderImpl read/take stack; separate exit thread in tracetools_fini/dlclose; SIGSEGV after SIGINT.',
    'core': read('shutdown/core_preservation.json'), 'gdb_log': 'shutdown/gdb/stdout.txt',
    'not_fixed': True, 'primary_blocker': 'DASHBOARD_BROWSER_CAPTURE_FAILED',
    'linux_residual_count': 0, 'owned_windows_browser_residual_count': 0, 'RELEVANT_RESIDUAL_PROCESS_COUNT': 0,
    'windows_cleanup': 'The supervisor removed Linux processes. Independent Windows inventory found the owned isolated Chrome tree; exact PID/profile/port verification preceded bounded taskkill /T /F. Subsequent independent inventory was zero.',
    'raw_result_field_caveat': 'runtime/capture/result.json runtime_evidence_complete_utc is inherited from the spatial stage only. runtime_pass=false and shutdown_start active_runtime_evidence_complete=false are authoritative for full-run completion.'})

test_summary = {'focused': {'passed': 6, 'subtests': 0, 'command': read('regression/focused/command.json')},
    'ros_integration': {'passed': 292, 'subtests': 6, 'command': read('tests/ros_integration/command.json')},
    'p15_p16_p17': {'passed': 409, 'subtests': 0, 'command': read('tests/p15_p16_p17/command.json')},
    'total_tests': 707, 'total_subtests': 6, 'failures': 0, 'skips': 0, 'deselections': 0,
    'build': read('patch/build_applicability.json'), 'offline_recorded_data_replay': 'PASS; no new runtime/inference'}
put('tests/summary.json', test_summary)
put('result.json', {'classification': 'P18 FIRST INTEGRATED RUN — BLOCKED', 'blocker': 'DASHBOARD_BROWSER_CAPTURE_FAILED',
    'harness_correction': 'PASS', 'PRE_FIX_SHA': 'e5fbfeef65a2851333bb2de0a222dc1df82163a6', 'POST_FIX_SHA': head,
    'retry_launched': True, 'retry_consumed': True, 'P13_START_CALL_COUNT': 1, 'RESET_CALL_COUNT': 0,
    'data_chain_same_observation_validated': True, 'dashboard_apptest': 'PASS', 'required_dashboard_screenshot': 'ABSENT',
    'full_runtime_evidence_complete': False, 'tests': {'passed':707,'subtests_passed':6,'failed':0,'skipped':0,'deselected':0},
    'PARAMETER_BRIDGE_VENDOR_TEARDOWN_DEFECT_REPRODUCED': 'YES', 'RELEVANT_RESIDUAL_PROCESS_COUNT': 0,
    'LIVE_REMOTE_VERIFICATION': git['LIVE_REMOTE_VERIFICATION'], 'cached_ahead_behind': [0,0], 'worktree': 'CLEAN',
    'frozen_scientific_contracts_changed': False, 'GT_OPERATIONAL_USE': 'NO', 'prior_observation_reused': False,
    'another_retry': False, 'repeatability_run': False, 'final_stop_b_freeze': False, 'canonical_main_merge': False, 'stop_c_started': False})
print(json.dumps({'summary_complete': True, 'head': head, 'remote': git['LIVE_REMOTE_VERIFICATION'], 'liveness': liveness,
                  'preserved_manifests': {k:v['verified_artifacts'] for k,v in preserved.items()}, 'residual_count': 0}, indent=2))
