BEGIN TRANSACTION;
CREATE TABLE defects (
    defect_id TEXT PRIMARY KEY,

    inspection_id INTEGER NOT NULL,

    track_id TEXT,

    class_name TEXT NOT NULL,

    confidence REAL NOT NULL
        CHECK (
            confidence >= 0.0
            AND confidence <= 1.0
        ),

    x_m REAL NOT NULL,
    y_m REAL NOT NULL,
    z_m REAL NOT NULL,

    coordinate_frame TEXT NOT NULL,

    observation_count INTEGER NOT NULL
        CHECK (observation_count >= 1),

    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,

    model_version TEXT NOT NULL,

    review_status TEXT NOT NULL
        DEFAULT 'UNREVIEWED'
        CHECK (
            review_status IN (
                'UNREVIEWED',
                'CONFIRMED',
                'REJECTED',
                'NEEDS_INVESTIGATION'
            )
        ),

    review_notes TEXT,

    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,

    FOREIGN KEY (inspection_id)
        REFERENCES inspections(inspection_id)
        ON DELETE CASCADE
);
INSERT INTO "defects" VALUES('P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd',2026091903,NULL,'Honeycombing',2.66873128712177276e-02,3.88877830911892186e+00,8.24835855886670299e-02,-4.14014813795004141e-02,'map',1,'1970-01-01T00:00:28.678000Z','1970-01-01T00:00:28.678000Z','DET-FINAL-v1','UNREVIEWED',NULL,'2026-09-19T20:32:29Z','2026-09-19T20:32:29Z');
CREATE TABLE evidence (
    evidence_id INTEGER PRIMARY KEY AUTOINCREMENT,

    defect_id TEXT NOT NULL,

    frame_id TEXT NOT NULL,

    timestamp TEXT NOT NULL,

    image_path TEXT,
    crop_path TEXT,

    confidence REAL NOT NULL
        CHECK (
            confidence >= 0.0
            AND confidence <= 1.0
        ),

    bbox_x1 REAL NOT NULL,
    bbox_y1 REAL NOT NULL,
    bbox_x2 REAL NOT NULL,
    bbox_y2 REAL NOT NULL,

    FOREIGN KEY (defect_id)
        REFERENCES defects(defect_id)
        ON DELETE CASCADE,

    UNIQUE (
        defect_id,
        frame_id,
        bbox_x1,
        bbox_y1,
        bbox_x2,
        bbox_y2
    )
);
INSERT INTO "evidence" VALUES(1,'P15D-07c3b5e0-f167-5f8f-9833-a90bea88dcdd','camera_optical_frame','1970-01-01T00:00:28.678000Z','/mnt/c/Dev/aegisinspect-p18-integration/outputs/evidence/stop_b_p18_first_integrated_run_retry1/runtime/capture/rgb_28678000000.png',NULL,2.66873128712177276e-02,1.27386474609375,3.7222900390625,6.3855291748046875e+02,480.0);
CREATE TABLE inspections (
    inspection_id INTEGER PRIMARY KEY AUTOINCREMENT,
    structure_id INTEGER NOT NULL,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    status TEXT NOT NULL
        CHECK (
            status IN (
                'PLANNED',
                'RUNNING',
                'PROCESSING',
                'REVIEW',
                'COMPLETED',
                'FAILED'
            )
        ),
    system_version TEXT NOT NULL,
    notes TEXT,
    FOREIGN KEY (structure_id)
        REFERENCES structures(structure_id)
        ON DELETE RESTRICT
);
INSERT INTO "inspections" VALUES(2026091903,1,'2026-09-19T20:31:38.668310Z',NULL,'PROCESSING','P18 7b9ff556956c9c8995262515f53ff5382ffacf1b','Detector classification: Honeycombing. Full detector confidence: 0.026687312871217728. Unreviewed machine output; no physical defect confirmation, engineering diagnosis or structural safety conclusion is asserted. Source observation is ROS simulation time 28678000000 ns. First/last seen and evidence timestamps are its epoch encoding, not wall-clock capture time. Map coordinates are metric and session-local to the operational odometry origin; no globally drift-corrected SLAM or ground-truth correction is used.');
CREATE TABLE structures (
    structure_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    location_text TEXT,
    created_at TEXT NOT NULL
);
INSERT INTO "structures" VALUES(1,'P18 Stop-B inspection_bay simulation session','Simulated infrastructure scene; container for this P18 runtime detector output.',NULL,'2026-09-19T20:32:29Z');
CREATE INDEX idx_structures_name
ON structures(name);
CREATE INDEX idx_inspections_structure
ON inspections(structure_id);
CREATE INDEX idx_inspections_status
ON inspections(status);
CREATE INDEX idx_defects_inspection
ON defects(inspection_id);
CREATE INDEX idx_defects_class
ON defects(class_name);
CREATE INDEX idx_defects_review_status
ON defects(review_status);
CREATE INDEX idx_defects_confidence
ON defects(confidence);
CREATE INDEX idx_defects_inspection_review
ON defects(inspection_id, review_status);
CREATE INDEX idx_evidence_defect
ON evidence(defect_id);
CREATE INDEX idx_evidence_defect_timestamp
ON evidence(defect_id, timestamp);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('structures',1);
INSERT INTO "sqlite_sequence" VALUES('inspections',2026091903);
INSERT INTO "sqlite_sequence" VALUES('evidence',1);
COMMIT;
