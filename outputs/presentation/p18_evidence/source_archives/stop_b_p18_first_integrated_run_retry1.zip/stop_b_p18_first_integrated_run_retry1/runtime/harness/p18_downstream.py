"""Automatic live P18 P15 -> P16 -> P17 handoff; no prior record inputs."""
from dataclasses import asdict, fields
from datetime import datetime
import json
import os
from pathlib import Path
import sqlite3
import sys

from evidence import ROOT, REPO, PACKAGE, save, digest, utc
sys.path.insert(0, str(REPO))
from src.storage.models import StructureCreate, InspectionCreate, InspectionStatus, MappedDefectRecord, EvidenceCreate
from src.storage.service import InspectionService
from src.storage.repository import DuplicateDefectError, DuplicateEvidenceError
from src.integrations.p16_p17_adapter import build_inspection_report
from src.reporting.rendering import render_report
from dashboard.components import defect_table_rows, evidence_table_rows

def main():
    mapped = json.loads((ROOT/'mapped_defect.json').read_text())
    dto = json.loads((ROOT/'p16_handoff_dto.json').read_text())
    assets = json.loads((ROOT/'assets.json').read_text())
    invocation = json.loads((ROOT/'runtime_invocation.json').read_text())
    detector = mapped['detection']
    p15 = mapped['P15_record']
    values = dict(dto['defect_record'])
    assert values['inspection_id'] == assets['inspection_id'] != 2026091901
    assert values['defect_id'] != 'P15D-10627c5f-3f84-5c64-ab2d-3e574b6e97ee'
    assert values['defect_id'] == p15['defect_id']
    ns = detector['stamp_sec']*10**9 + detector['stamp_nanosec']
    assert ns == mapped['map_projection']['stamp_ns'] == mapped['map_projection']['transform_stamp_ns']
    assert detector['detection_id'] == mapped['P15_observation']['detection_id']
    for key,value in values.items():
        if key in ('first_seen','last_seen'):
            assert datetime.fromisoformat(value)==datetime.fromisoformat(p15[key])
        elif key=='track_id':
            assert value==p15['canonical_track_id']
        else:
            assert value==p15[key],key
    assert values['confidence'] == detector['confidence']
    assert [values[k] for k in ['x_m','y_m','z_m']] == mapped['map_projection']['map_xyz']
    for key in ['first_seen','last_seen']:
        values[key] = datetime.fromisoformat(values[key])
    record=MappedDefectRecord(**values)
    evidence=[]
    for row in dto['evidence']:
        row=dict(row)
        row['timestamp']=datetime.fromisoformat(row['timestamp'])
        assert Path(row['image_path']).is_relative_to(PACKAGE)
        assert Path(row['image_path']).is_file()
        evidence.append(EvidenceCreate(**row))
    assert len(evidence)==1
    db=PACKAGE/'p16/p18.sqlite3'
    assert not db.exists(),'P18 database must be newly created once'
    service=InspectionService.from_database_path(db)
    service.initialize()
    structure=service.create_structure(StructureCreate(name='P18 Stop-B inspection_bay simulation session',description='Simulated infrastructure scene; container for this P18 runtime detector output.',location_text=None))
    notes=(f'Detector classification: {record.class_name}. Full detector confidence: {record.confidence!r}. '
           'Unreviewed machine output; no physical defect confirmation, engineering diagnosis or structural safety conclusion is asserted. '
           f'Source observation is ROS simulation time {ns} ns. First/last seen and evidence timestamps are its epoch encoding, not wall-clock capture time. '
           'Map coordinates are metric and session-local to the operational odometry origin; no globally drift-corrected SLAM or ground-truth correction is used.')
    inspection=service.create_inspection(InspectionCreate(structure_id=structure.structure_id,started_at=datetime.fromisoformat(invocation['utc']),completed_at=None,status=InspectionStatus.PROCESSING,system_version='P18 '+assets['p18_head'],notes=notes),inspection_id=record.inspection_id)
    saved=service.ingest_mapped_defect(record)
    stored_evidence=[service.add_evidence(row) for row in evidence]
    saved=service.get_defect(record.defect_id)
    for field in fields(record):
        assert getattr(saved,field.name)==getattr(record,field.name),field.name
    for stored,original in zip(stored_evidence,evidence):
        for field in fields(original):
            assert getattr(stored,field.name)==getattr(original,field.name),field.name
    assert saved.review_status.value=='UNREVIEWED' and saved.review_notes is None
    duplicates=[]
    for operation,error in [(lambda:service.ingest_mapped_defect(record),DuplicateDefectError),(lambda:service.add_evidence(evidence[0]),DuplicateEvidenceError)]:
        try:
            operation()
        except error as exc:
            duplicates.append({'type':type(exc).__name__,'message':str(exc)})
        else:
            raise AssertionError('Duplicate insert was unexpectedly accepted')
    assert len(service.list_inspection_defects(record.inspection_id))==1
    assert len(service.list_evidence(record.defect_id))==1
    assert saved==service.get_defect(record.defect_id)
    save(PACKAGE/'p16/persisted_record.json',asdict(saved))
    save(PACKAGE/'p16/persisted_evidence.json',[asdict(row) for row in stored_evidence])
    save(PACKAGE/'p16/inspection_container.json',{'structure':asdict(structure),'inspection':asdict(inspection)})
    save(PACKAGE/'p16/idempotency.json',{'PASS':True,'duplicates':duplicates,'record_count':1,'evidence_count':1,'observation_count':saved.observation_count,'all_fields_unchanged':True,'contract':'Create-only persistence rejects duplicates; P15 replay preserves the original state.'})
    with sqlite3.connect(db) as connection:
        integrity=connection.execute('PRAGMA integrity_check').fetchall()
        fk=connection.execute('PRAGMA foreign_key_check').fetchall()
        assert integrity==[('ok',)] and not fk
        (PACKAGE/'p16/export.sql').write_text('\n'.join(connection.iterdump())+'\n')
    save(PACKAGE/'p16/database_validation.json',{'integrity_check':integrity,'foreign_key_check':fk,'schema_source_sha256':digest(REPO/'database/schema.sql')})
    before=digest(db)
    model=build_inspection_report(service,record.inspection_id)
    report=render_report(model)
    assert report==render_report(build_inspection_report(service,record.inspection_id))
    assert digest(db)==before
    assert repr(record.confidence) in report
    assert record.defect_id in report and record.class_name in report
    for field in ['Severity','Dimensions','Repair recommendation','Safety classification','Deterioration grade']:
        assert not any(line.lower().startswith('- '+field.lower()+':') for line in report.splitlines())
    report_path=PACKAGE/'p17/inspection_report.md'
    report_path.write_text(report)
    save(PACKAGE/'p17/report_model.json',asdict(model))
    save(PACKAGE/'p17/validation.json',{'PASS':True,'two_independent_reads_equal':True,'database_unchanged':True,'unsupported_engineering_fields_absent':True,'report_sha256':digest(report_path)})
    os.environ['AEGISINSPECT_DB_PATH']=str(db)
    from streamlit.testing.v1 import AppTest
    app=AppTest.from_file(REPO/'dashboard/app.py',default_timeout=30).run()
    assert not app.exception,str(app.exception)
    markdown=[x.value for x in app.markdown]
    captions=[x.value for x in app.caption]
    infos=[x.value for x in app.info]
    tables=[x.value.to_dict(orient='records') for x in app.dataframe]
    text='\n'.join(markdown+captions+infos)
    for required in [record.defect_id,repr(record.confidence),record.class_name,'UNREVIEWED',record.first_seen.isoformat()]:
        assert required in text,required
    assert tables[0][0]['Confidence']==repr(record.confidence)
    assert tables[0][0]['Frame']=='map' and tables[0][0]['Observations']==1
    assert len(tables[0])==len(tables[1])==1
    assert digest(db)==before
    save(PACKAGE/'p16/dashboard_apptest.json',{'PASS':True,'markdown':markdown,'captions':captions,'information':infos,'tables':tables,'database_unchanged':True,'human_review_submitted':False})
    lineage={'runtime_id':assets['runtime_id'],'p18_head':assets['p18_head'],'source':'This first P18 runtime only; no prior accepted observation was consumed.',
        'detector':{'model_version':'DET-FINAL-v1','checkpoint_sha256':assets['checkpoint_sha256']},'detection':detector,
        'source_image':{'path':mapped['image_path'],'sha256':digest(mapped['image_path'])},
        'depth':json.loads((ROOT/'depth_provenance.json').read_text()),'camera_to_map':mapped['map_projection'],
        'p15':{'defect_id':record.defect_id,'observation_id':mapped['P15_observation']['observation_id'],'artifact':str(ROOT/'mapped_defect.json'),'sha256':digest(ROOT/'mapped_defect.json'),'replay':mapped['aggregation']},
        'p16':{'defect_id':saved.defect_id,'database':str(db),'database_sha256':before,'persisted_record':str(PACKAGE/'p16/persisted_record.json')},
        'p17':{'report':str(report_path),'sha256':digest(report_path)},'same_observation':True,'timestamp_ns':ns,'timestamp_domain':'ROS simulation','GT_OPERATIONAL_USE':'NO'}
    save(PACKAGE/'provenance/lineage.json',lineage)
    save(ROOT/'downstream_complete.json',{'utc':utc(),'PASS':True,'defect_id':record.defect_id,'confidence':record.confidence,'report':str(report_path),'database':str(db),'dashboard_apptest':'PASS'})
    print('P18_P16_P17_AND_DASHBOARD_APPTEST=PASS '+record.defect_id,flush=True)

if __name__=='__main__':
    main()
