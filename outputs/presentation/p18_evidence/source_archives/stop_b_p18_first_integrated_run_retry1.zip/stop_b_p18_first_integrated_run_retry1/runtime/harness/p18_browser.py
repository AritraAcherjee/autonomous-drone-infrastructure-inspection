"""Parameterize the accepted unedited Chrome screenshot capture for P18."""
import json
from evidence import PACKAGE, ROOT, PREVIOUS, digest, save

source_path=PREVIOUS/'stop_b_p16_p17_real_handoff/capture_dashboard_ready.py'
source=source_path.read_text()
mapped=json.loads((ROOT/'mapped_defect.json').read_text())
record=mapped['P15_record']
required=[record['defect_id'],repr(record['confidence']),record['class_name'],'UNREVIEWED']
old="required=['P15D-10627c5f-3f84-5c64-ab2d-3e574b6e97ee','0.004553093574941158','Honeycombing','UNREVIEWED','21.813000']"
assert source.count(old)==1
source=source.replace(old,'required='+repr(required))
source=source.replace('from evidence import ROOT, save, utc','from evidence import PACKAGE, save, utc\nROOT=PACKAGE/\'p16\'')
source=source.replace('aegisinspect-07-vio','aegisinspect-p18-integration').replace('p16_p17_browser_profile','p18_browser_profile').replace('9227','9238').replace('8517','8518')
save(PACKAGE/'provenance/browser_reuse.json',{'accepted_source':str(source_path),'accepted_source_sha256':digest(source_path),'changes':'P18 output root, isolated browser profile/ports, current runtime record required text only; screenshot pixels are not edited.'})
exec(compile(source,str(source_path),'exec'),{'__name__':'__main__','__file__':str(source_path)})
