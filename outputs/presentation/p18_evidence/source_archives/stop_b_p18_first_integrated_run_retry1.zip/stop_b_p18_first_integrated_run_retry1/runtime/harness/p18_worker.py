"""Run unchanged accepted detector/spatial/P15 logic on new P18 sensor traffic."""
import importlib.util
import json
from pathlib import Path
import sys

from evidence import ROOT, PREVIOUS

path = PREVIOUS / 'stop_b_map_frame_spatial_chain/spatial_worker.py'
spec = importlib.util.spec_from_file_location('p18_accepted_spatial_worker', path)
accepted = importlib.util.module_from_spec(spec)
spec.loader.exec_module(accepted)

class P18Worker(accepted.SpatialWorker):
    def _image_callback(self, msg):
        # Admit only traffic after this P18 START response. Inference and all
        # scientific transformations remain inherited without parameter changes.
        marker = ROOT / 'detector_release.json'
        if not marker.is_file():
            return
        threshold = json.loads(marker.read_text())['minimum_observation_stamp_ns']
        if accepted.stamp(msg) < threshold:
            return
        super()._image_callback(msg)

def main():
    accepted.rclpy.init()
    node = None
    try:
        node = P18Worker()
        accepted.rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        accepted.rclpy.try_shutdown()

if __name__ == '__main__':
    main()
