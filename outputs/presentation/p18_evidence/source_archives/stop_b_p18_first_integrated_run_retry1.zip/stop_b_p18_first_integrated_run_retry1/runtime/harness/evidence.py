"""P18 evidence bookkeeping; no launch on import."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

REPO = Path('/mnt/c/Dev/aegisinspect-p18-integration')
PACKAGE = REPO / 'outputs/evidence/stop_b_p18_first_integrated_run_retry1'
ROOT = PACKAGE / 'runtime/capture'
PREVIOUS = Path('/mnt/c/Dev/aegisinspect-07-vio/outputs/evidence')

def utc():
    return datetime.now(timezone.utc).isoformat()

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2, default=lambda x: x.isoformat(), allow_nan=False) + '\n')
    temporary.replace(path)

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def inventory():
    result = subprocess.run(['ps', '-eo', 'pid=,ppid=,pgid=,sid=,stat=,lstart=,comm=,args=', '-ww'], capture_output=True, text=True, check=True)
    relevant = []
    for line in result.stdout.splitlines():
        fields = line.split(None, 11)
        if len(fields) != 12 or int(fields[0]) == os.getpid():
            continue
        comm, args = fields[10:]
        match = (
            comm.startswith(('parameter_brid', 'motion_control', 'robot_state_pub', 'gz-sim', 'gzserver', 'gzclient', 'icp_odometry', 'rgbd_odometry', 'ov_msckf', 'static_transfor'))
            or (comm.startswith(('python', 'ros2', 'vio_adapter', 'camera_project', 'detector_proje', 'streamlit')) and any(x in args for x in ('ros2 launch aegisinspect_', 'vio_adapter_node.py', 'camera_projection_node.py', 'detector_projection_node.py', 'spatial_worker.py', 'p18_worker.py', 'p18_downstream.py', 'streamlit run', 'ov_msckf', 'openvins')))
            or (comm in ('ruby', 'gz', 'sh', 'gz sim server') and 'inspection_bay' in args)
            or ('gz-sim-main' in args and not comm.startswith(('bash', 'codex')))
        )
        if match:
            relevant.append(line)
    return {'utc': utc(), 'count': len(relevant), 'processes': relevant, 'full_ps': result.stdout}
