$ErrorActionPreference = 'Stop'
$remaining = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -eq 'chrome.exe' -and $_.CommandLine -like '*p16_p17_browser_profile*'
} | Select-Object ProcessId,ParentProcessId,CommandLine)
$result = @{timestamp=[DateTime]::UtcNow.ToString('o'); residual_task_browser_count=$remaining.Count; processes=$remaining}
$result | ConvertTo-Json -Depth 5
if ($remaining.Count -ne 0) { exit 1 }
