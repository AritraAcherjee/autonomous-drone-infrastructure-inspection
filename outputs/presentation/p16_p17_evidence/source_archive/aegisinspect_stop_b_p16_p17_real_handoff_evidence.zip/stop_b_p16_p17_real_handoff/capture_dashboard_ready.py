"""Wait for real dashboard content via CDP, then save unedited Chrome pixels."""
import asyncio
import base64
import json
import subprocess
import time
import urllib.request
from evidence import ROOT, save, utc
import websockets

COMMAND = ['/mnt/c/Program Files/Google/Chrome/Application/chrome.exe',
    '--headless=new', '--no-first-run', '--no-default-browser-check',
    '--user-data-dir=C:\\Dev\\aegisinspect-07-vio\\outputs\\cache\\p16_p17_browser_profile',
    '--disable-gpu', '--hide-scrollbars', '--window-size=1920,2200',
    '--remote-debugging-port=9227', 'about:blank']

async def capture():
    started = utc()
    out = (ROOT/'dashboard'/'cdp_browser_stdout.txt').open('wb')
    err = (ROOT/'dashboard'/'cdp_browser_stderr.txt').open('wb')
    proc = subprocess.Popen(COMMAND, stdout=out, stderr=err)
    metadata = {'command': COMMAND, 'start': started, 'WSL_process_id': proc.pid}
    save(ROOT/'dashboard'/'cdp_runtime.json', metadata)
    endpoint = None
    try:
        deadline = time.monotonic()+20
        while time.monotonic()<deadline:
            try:
                with urllib.request.urlopen('http://127.0.0.1:9227/json/list', timeout=2) as response:
                    tabs = json.load(response)
                endpoint = next(tab['webSocketDebuggerUrl'] for tab in tabs if tab['type']=='page')
                break
            except (OSError, StopIteration):
                await asyncio.sleep(.3)
        assert endpoint, 'Could not connect to isolated installed Chrome CDP endpoint'
        async with websockets.connect(endpoint, max_size=20_000_000) as socket:
            seq=0
            events=[]
            async def cdp(method, params=None):
                nonlocal seq
                seq+=1
                await socket.send(json.dumps({'id': seq, 'method': method, 'params': params or {}}))
                while True:
                    item=json.loads(await asyncio.wait_for(socket.recv(), 15))
                    if item.get('id')==seq:
                        assert 'error' not in item, item
                        return item.get('result', {})
                    if item.get('method') in ['Runtime.exceptionThrown', 'Network.webSocketCreated', 'Network.webSocketClosed', 'Network.webSocketFrameError', 'Network.loadingFailed']:
                        events.append(item)
            await cdp('Page.enable')
            await cdp('Runtime.enable')
            await cdp('Network.enable')
            version=await cdp('Browser.getVersion')
            await cdp('Emulation.setDeviceMetricsOverride', {'width':1920,'height':2200,'deviceScaleFactor':1,'mobile':False})
            await cdp('Page.navigate', {'url':'http://localhost:8517'})
            required=['P15D-10627c5f-3f84-5c64-ab2d-3e574b6e97ee','0.004553093574941158','Honeycombing','UNREVIEWED','21.813000']
            deadline=time.monotonic()+40
            while time.monotonic()<deadline:
                result=await cdp('Runtime.evaluate', {'expression':'document.body.innerText','returnByValue':True})
                body=result['result'].get('value','')
                if all(item in body for item in required): break
                await asyncio.sleep(.5)
            (ROOT/'dashboard'/'ready_browser_text.txt').write_text(body)
            assert all(item in body for item in required), 'Dashboard did not present exact accepted record within 40 seconds'
            await cdp('Runtime.evaluate', {'expression':'document.fonts.ready', 'awaitPromise':True})
            dom=await cdp('Runtime.evaluate', {'expression':'document.documentElement.outerHTML','returnByValue':True})
            (ROOT/'dashboard'/'ready_browser_dom.html').write_text(dom['result']['value'])
            screenshot=await cdp('Page.captureScreenshot', {'format':'png','captureBeyondViewport':True,'fromSurface':True})
            (ROOT/'dashboard'/'real_dashboard_ready.png').write_bytes(base64.b64decode(screenshot['data']))
            metadata.update({'browser_version':version,'ready':True,'required_text_present':required,
                'screenshot':'real_dashboard_ready.png','method':'Chrome CDP captureScreenshot after content readiness; no DOM or pixel editing',
                'no_human_review_action':True,'events':events})
            save(ROOT/'dashboard'/'cdp_runtime.json',metadata)
            await socket.send(json.dumps({'id':seq+1,'method':'Browser.close'}))
        proc.wait(timeout=15)
    finally:
        if proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired: metadata['cleanup_unresolved']=True
        metadata.update({'end':utc(),'exit_status':proc.poll()})
        save(ROOT/'dashboard'/'cdp_runtime.json',metadata)
        out.close();err.close()
    print(json.dumps(metadata,indent=2))

if __name__=='__main__': asyncio.run(capture())
