# P16/P17 REAL HANDOFF — PASS

The accepted real DET-FINAL-v1 observation flowed unchanged through P16 persistence,
the actual dashboard, and the existing deterministic P17 pipeline. This is an
integration result only. Detector classification Honeycombing at confidence
**0.004553093574941158** is extremely low-confidence, UNREVIEWED machine output;
it is not physical confirmation, an engineering diagnosis, or a safety conclusion.

## A. Provenance

- Repository: `/mnt/c/Dev/aegisinspect-07-vio`.
- Branch: `07/lidar-icp-fallback`.
- Starting and ending HEAD: `190bf7653b203c97418842474aa7cbd8016bfd44`.
- Live `origin/07/lidar-icp-fallback` equals that SHA; clean worktree and diff check PASS.
- Accepted input: `../stop_b_map_frame_spatial_chain/corrected_capture/mapped_defect.json`.
- Accepted DTO: `../stop_b_map_frame_spatial_chain/corrected_capture/p16_handoff_dto.json`.
- Defect ID: `P15D-10627c5f-3f84-5c64-ab2d-3e574b6e97ee`.
- Observation/detection ID: `21.813000000-0`; inspection ID: `2026091901`.
- Both input copies are byte-identical to their originals. All 521 original accepted
  artifacts still verify. Original manifest SHA256 remains
  `f6010a7a6b63765281f2819ce0b461b14450cb9f3965aa423c8a06a60d5ef97e`.
- Existing P17 branch was inspected at `66d33acd00704d2f79b157471702e3709ce9d716`
  in detached `/tmp/aegis-stopb-p16p17.J0c6Zg/source`, with live remote parity.
  It includes existing P16; no merge was performed. Canonical main remains clean at
  `3fc6ac001e71c1ab56b2b810cd2d595358a55e28`.

See `git/initial/`, `git/final_state.json`, `provenance/ARCHITECTURE.md`.

## B. P16 persistence

Existing `InspectionService` APIs populated an isolated SQLite 3.46.1 database at
`database/real_handoff.sqlite3`. Existing schema is unchanged; `PRAGMA user_version=0`,
schema source SHA256 `1217e4a5ed243829cfeef6d1d332ca1eab5705852df3d20d5f6d8187b8d42ecc`.
Integrity check: `ok`; foreign-key check: empty.

Exact command, from the localization repository:

```sh
/tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python -B outputs/evidence/stop_b_p16_p17_real_handoff/run_handoff.py
```

The harness loads the unchanged DTO into existing dataclasses, parses its datetimes,
then calls `ingest_mapped_defect` and `add_evidence`. It does not hand-edit the DTO.
Every persisted DTO field was compared to the input before and after dashboard use.

- Class: Honeycombing; confidence: `0.004553093574941158`.
- Map XYZ (meters): `(3.9000027127470087, -0.09877989958311785, 0.0032930137079122536)`.
- Frame: `map`; observation count: `1`.
- First seen = last seen = evidence time: `1970-01-01T00:00:21.813000Z`.
  These datetimes encode **ROS simulation 21.813 s, not wall-clock capture time**.
- Review status: `UNREVIEWED`; review notes: null; no human decision was submitted.
- Evidence row ID: `1`; source frame: `camera_optical_frame`.
- Original evidence path resolves to
  `/mnt/c/Dev/aegisinspect-07-vio/outputs/evidence/stop_b_map_frame_spatial_chain/corrected_capture/rgb_21813000000.png`.
- Model: DET-FINAL-v1; track ID and crop path remain absent, not inferred.

The new inspection container preserves upstream ID 2026091901. It is explicitly a
simulation evidence session, not a surveyed physical structure. Original P13 log
`corrected_capture/p13.log:7` records world `inspection_bay.sdf`. Inspection started_at
uses original runtime invocation `2026-09-19T04:02:49.673541Z`; completed_at and location
remain unavailable. PROCESSING is an ingestion workflow state, not a defect review.

Artifacts: `database/persisted_record.json`, `persisted_evidence.json`,
`inspection_container.json`, `metadata.json`, and portable `safe_export.sql`.

## C. Duplicate/replay

- Record count before initial insertion: 0; after initial insertion: 1.
- Record count before replay: 1; after replay: 1.
- Existing create-only contract returns `DuplicateDefectError`; no merge/update occurs.
- Same evidence replay returns `DuplicateEvidenceError`; evidence count remains 1.
- Final observation count: 1. First_seen, last_seen, all other defect fields, audit
  timestamps and evidence fields remain unchanged. Identity and linkage are deterministic.

No second distinct observation was invented. See `database/replay.json`.

## D. Dashboard

Existing `dashboard/app.py` ran against this SQLite database on `127.0.0.1:8517`, with
Streamlit 1.64.0 installed only in an isolated virtual environment from repository
`requirements-p16.txt`. Full dependency versions/install command are preserved.

Actual Windows Chrome 153.0.8010.48 screenshots, visually inspected:

- `dashboard/dashboard_overview.png`
- `dashboard/dashboard_detail.png`

These unedited screenshots show the accepted ID, class, full confidence, map frame,
coordinates, observation count, first/last seen, evidence reference and UNREVIEWED
status. Existing coordinate display formatting remains; exact stored numbers are in
the underlying render data and P17. No severity, dimensions, urgency, engineering
assessment or safety conclusion was added. Confirmed count is zero. No review form
was submitted. Low confidence and simulation-time semantics are explicit in notes.

Underlying proof: `dashboard/native_browser_dom.html`, `native_browser_text.txt`,
`native_capture.json`, `streamlit_render_data.json`, `displayed_record_data.json`.
AppTest also loaded the actual app/data without exceptions or database mutation.

The first CLI screenshot (`real_dashboard.png`) captured loading only and is NOT
accepted dashboard evidence. The Linux-to-Windows CDP attempt could not connect.
Native Windows CDP then successfully waited for exact record content before capture.
All failed capture diagnostics are retained; no screenshot was fabricated.

## E. P17

Report: `report/inspection_2026091901.md`.

The unchanged `build_inspection_report` adapter reads the persisted record through
InspectionService. The unchanged `render_report` generates deterministic Markdown.
Two independent reads/renders are byte-identical; a final render after dashboard
use is identical too. Reporting does not modify the database.

Report SHA256: `b5d506de2136349bafbec15aa225eb255ecb7c0ede348e2b29f98bc439c2551e`.
It preserves exact confidence `0.004553093574941158`, full XYZ, map frame, count,
timestamps, source/bbox/evidence/model provenance and UNREVIEWED status. Missing
optional fields remain Unavailable. No unsupported engineering or safety claim is
made; the report explicitly distinguishes machine output from physical confirmation.

Machine-readable report: `report/report_model.json`; determinism proof:
`report/determinism.json`.

## F. Lineage

`provenance/lineage.json` contains the unbroken chain:

DET-FINAL-v1 → detection `21.813000000-0` → real depth ROI → camera XYZ → exact
timestamped map XYZ → P15 defect → P16 same defect/inspection IDs → P17 same record.

- Checkpoint SHA256: `4c7a32c9b40c0795bbe59aca5952a0631e1524ec731ad2c7441cccb1b44f71c3`.
- Mapped input SHA256: `6d1644b8cd01e23449bf55fd85ca4ac2766b4261df4466f09efbfdbe84525567`.
- DTO SHA256: `42aa03601008156f30a2ca3668f4e8cd38b6209b03fd0c1db6986f975f2a2e82`.
- Source image SHA256: `4a673b0bf8a28ba9276474234403b03d32f4d63d5b348e7b7cacbe946229ecd0`.
- Bbox: `[31.05999755859375, 0, 640, 480]`, original image 640×480.
- Depth: median positive finite optical-axis Z, 73,200 valid samples, 0 invalid;
  `3.6500000953674316` meters; accepted ROI provenance copied unchanged.
- Camera XYZ: `(0.0987810269730641, -0.0032927008991021365, 3.6500000953674316)`.
- Observation and transform timestamp: `21813000000` ns simulation time.
- TF chain preserved: map → odom → base_link → camera_link → camera_optical_frame.

NO_UNEXPLAINED_IDENTITY_SUBSTITUTION=true. GT_OPERATIONAL_USE=NO. This task did not
run detection, depth projection, localization or scientific motion again; it consumed
the accepted artifacts and retained their independently verified provenance.

## G. Tests

Working directory: `/tmp/aegis-stopb-p16p17.J0c6Zg/source`.

Existing baseline command:

```sh
python3 -B -m pytest -p no:cacheprovider -q tests/storage tests/integrations tests/reporting
```

206 passed before correction. Nine focused regressions initially failed, proving
subsecond loss, missing explicit inspection identity support and rounded confidence.

Focused corrected command:

```sh
/tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python -B -m pytest -p no:cacheprovider -q tests/storage/test_real_handoff_precision.py
```

9 passed. Final regression command:

```sh
/tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python -B -m pytest -p no:cacheprovider -q -ra tests/storage tests/integrations tests/reporting
```

215 passed in 0.38s, 0 failed, 0 skipped, 0 deselected; includes the nine new tests.
Coverage includes P15/P16 DTOs, persistence/restart/schema, replay, review isolation,
deterministic P17 rendering/validation, timestamp precision and low-confidence UI.
Real AppTest command (localization repository cwd):

```sh
/tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python -B outputs/evidence/stop_b_p16_p17_real_handoff/validate_dashboard.py
```

PASS; this assertion script is separate from the 215 pytest count. Raw commands,
stdout/stderr and red/green evidence are under `tests/` and `command_transcript.json`.

## H. Git / corrections / cleanup

Three minimal P16 boundary corrections were necessary: preserve timestamp fractions,
support optional upstream inspection identity without changing the schema/DTO, and
display confidence without rounding. Existing auto-ID and review behavior remain.

Exactly five changed files in the detached P17 checkout:

1. `dashboard/app.py`
2. `dashboard/components.py`
3. `src/storage/repository.py`
4. `src/storage/service.py`
5. `tests/storage/test_real_handoff_precision.py` (new)

Exact full diff: `git/complete_source.diff`; durable file copies:
`git/changed_file_snapshots/`; source hashes: `provenance/source_hashes.json`.
All `git diff --check` checks PASS. Changes remain UNCOMMITTED for 00. No commit,
push or merge occurred during this handoff. Original main/07 worktrees are clean.
The detached worktree is intentionally dirty with only these five paths.

Schema, DTO, P15, P17, detector, localization, depth, coordinates and scientific
configuration are unchanged. No START, RESET, scientific rerun, or P18 execution.

Dashboard controlled SIGINT at `2026-09-19T05:13:01.485107+00:00`; child status 0.
Isolated browser closed via Browser.close. Verified task server/browser residuals: 0.
Temporary source checkout and virtual environment remain available for 00 review.

## I. Evidence integrity

Evidence root: `/mnt/c/Dev/aegisinspect-07-vio/outputs/evidence/stop_b_p16_p17_real_handoff/`.

Required artifacts are present: this report; byte-identical input/DTO copies; SQLite
database and SQL export; persisted record/replay JSON; real screenshots and underlying
data; deterministic P17 report/model; lineage/hashes; tests; exact source diff; Git
states; runtime/cleanup logs; `SHA256SUMS.txt` and `manifest_verification.json`.

All files except SHA256SUMS.txt itself are hashed. Final manifest verification PASS.
No original accepted P15 evidence was edited and no generated evidence was committed.

STOP — RETURN TO 00. Do not start P18.
