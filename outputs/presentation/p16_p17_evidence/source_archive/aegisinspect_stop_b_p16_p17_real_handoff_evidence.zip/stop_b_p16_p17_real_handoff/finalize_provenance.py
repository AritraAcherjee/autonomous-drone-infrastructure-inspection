"""Read-only final provenance checks; preserve uncommitted correction for 00."""
from dataclasses import asdict, fields
from datetime import datetime
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
from evidence import ROOT, REPO, ACCEPTED, digest, save, utc

SOURCE = Path('/tmp/aegis-stopb-p16p17.J0c6Zg/source')
MAIN = Path('/mnt/c/Dev/autonomous-drone-infrastructure-inspection')
CHANGED = ['dashboard/app.py', 'dashboard/components.py', 'src/storage/repository.py',
           'src/storage/service.py', 'tests/storage/test_real_handoff_precision.py']
commands=[]
def command(cwd, argv, allowed=(0,)):
    proc=subprocess.run(argv,cwd=cwd,capture_output=True,text=True)
    commands.append({'cwd':str(cwd),'argv':argv,'returncode':proc.returncode,
                     'stdout':proc.stdout,'stderr':proc.stderr,'utc':utc()})
    assert proc.returncode in allowed, commands[-1]
    return proc.stdout
def git(cwd,*args): return command(cwd,['git',*args])
def state(path):
    return {'repository':str(path),'branch':git(path,'branch','--show-current').strip(),
            'HEAD':git(path,'rev-parse','HEAD').strip(),'status_short':git(path,'status','--short'),
            'diff_check':git(path,'diff','--check'),'cached_diff':git(path,'diff','--cached','--name-status')}

sys.path.insert(0,str(SOURCE))
from src.storage.service import InspectionService
from src.integrations.p16_p17_adapter import build_inspection_report
from src.reporting.rendering import render_report

primary=state(REPO)
canonical=state(MAIN)
isolated=state(SOURCE)
assert primary['branch']=='07/lidar-icp-fallback'
assert primary['HEAD']=='190bf7653b203c97418842474aa7cbd8016bfd44'
assert not primary['status_short'] and not canonical['status_short']
assert canonical['HEAD']=='3fc6ac001e71c1ab56b2b810cd2d595358a55e28'
assert isolated['HEAD']=='66d33acd00704d2f79b157471702e3709ce9d716' and not isolated['branch']
assert not isolated['cached_diff']
changed=sorted(git(SOURCE,'diff','--name-only').splitlines()+git(SOURCE,'ls-files','--others','--exclude-standard').splitlines())
assert changed==sorted(CHANGED), changed
remote=git(REPO,'ls-remote','origin','refs/heads/07/lidar-icp-fallback','refs/heads/P16/inspection-persistence-dashboard','refs/heads/P17/reporting')
remote_refs={line.split()[1]:line.split()[0] for line in remote.splitlines()}
assert remote_refs['refs/heads/07/lidar-icp-fallback']==primary['HEAD']
assert remote_refs['refs/heads/P17/reporting']==isolated['HEAD']
assert remote_refs['refs/heads/P16/inspection-persistence-dashboard']=='f757951598dd9cb6ebcb93aaed16554b6a0e929c'
git(SOURCE,'merge-base','--is-ancestor',canonical['HEAD'],isolated['HEAD'])
git(SOURCE,'merge-base','--is-ancestor','f757951598dd9cb6ebcb93aaed16554b6a0e929c',isolated['HEAD'])
save(ROOT/'git'/'final_state.json', {'utc':utc(),'localization':primary,'canonical_main':canonical,
    'isolated_reporting':isolated,'changed_files':CHANGED,'remote_refs':remote_refs,
    'localization_local_remote_parity':'PASS','reporting_base_remote_parity':'PASS',
    'scoped_changes_uncommitted':True,'no_commit_no_push_no_merge_this_handoff':True})
patch=git(SOURCE,'diff','--binary','--full-index')
new_file=command(SOURCE,['git','diff','--no-index','--binary','--full-index','/dev/null',CHANGED[-1]],(1,))
(ROOT/'git'/'complete_source.diff').write_text(patch+new_file)
save(ROOT/'git'/'diff_scope.json', {'changed_files':CHANGED,'tracked_diff_stat':git(SOURCE,'diff','--stat'),
    'new_test_lines':len((SOURCE/CHANGED[-1]).read_text().splitlines()),
    'diff_check':'PASS','source_worktree':str(SOURCE),'preservation_status':'UNCOMMITTED for 00'})
for path in CHANGED:
    destination=ROOT/'git'/'changed_file_snapshots'/path
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(SOURCE/path,destination)
tracked=git(SOURCE,'ls-files','src/storage','src/reporting','src/integrations/p15_p16_adapter.py',
            'src/integrations/p16_p17_adapter.py','dashboard','database/schema.sql','requirements-p16.txt',
            'tests/storage','tests/reporting','tests/integrations').splitlines()
save(ROOT/'provenance'/'source_hashes.json', {
    path:digest(SOURCE/path) for path in sorted(set(tracked+CHANGED)) if (SOURCE/path).is_file()})
for frozen in ['database/schema.sql','src/storage/models.py','src/integrations/p15_p16_adapter.py',
               'src/integrations/p16_p17_adapter.py','src/reporting/rendering.py']:
    assert not git(SOURCE,'diff','HEAD','--',frozen), frozen
save(ROOT/'provenance'/'scope_audit.json', {'changed_files':CHANGED,'schema_unchanged':True,
    'DTO_models_unchanged':True,'P15_unchanged':True,'P17_pipeline_unchanged':True,
    'localization_unchanged':True,'detector_unchanged':True,'spatial_coordinates_unchanged':True,
    'GT_OPERATIONAL_USE':'NO','P13_START_CALL_COUNT_THIS_TASK':0,'ICP_START_CALL_COUNT_THIS_TASK':0,
    'RESET_CALL_COUNT_THIS_TASK':0,'P18_STARTED':False})
dto=json.loads((ROOT/'input'/'p16_handoff_dto.json').read_text())
db=ROOT/'database'/'real_handoff.sqlite3'
service=InspectionService.from_database_path(db)
record=service.get_defect(dto['defect_record']['defect_id'])
for key,value in dto['defect_record'].items():
    assert getattr(record,key)==(datetime.fromisoformat(value) if key in ['first_seen','last_seen'] else value), key
assert record.review_status.value=='UNREVIEWED' and record.review_notes is None
assert len(service.list_defects())==len(service.list_evidence(record.defect_id))==1
report=ROOT/'report'/'inspection_2026091901.md'
assert render_report(build_inspection_report(service,record.inspection_id))==report.read_text()
assert json.loads((ROOT/'dashboard'/'native_capture.json').read_text(encoding='utf-8-sig'))['ready']
assert json.loads((ROOT/'dashboard'/'runtime.json').read_text())['exit_status']==0
assert json.loads((ROOT/'dashboard'/'cleanup_linux.json').read_text())['residual_dashboard_count']==0
assert json.loads((ROOT/'dashboard'/'native_cleanup_command'/'stdout.txt').read_text())['residual_task_browser_count']==0
with sqlite3.connect(f'file:{db}?mode=ro',uri=True) as connection:
    assert connection.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert not connection.execute('PRAGMA foreign_key_check').fetchall()
assert digest(ACCEPTED/'SHA256SUMS.txt')=='f6010a7a6b63765281f2819ce0b461b14450cb9f3965aa423c8a06a60d5ef97e'
for filename in ['mapped_defect.json','p16_handoff_dto.json']:
    assert digest(ROOT/'input'/filename)==digest(ACCEPTED/'corrected_capture'/filename)
save(ROOT/'provenance'/'final_data_validation.json', {'result':'PASS','DTO_unchanged':True,
    'all_persisted_values_still_equal':True,'report_still_equal_after_dashboard':True,
    'no_review_mutation':True,'database_integrity':'ok','accepted_manifest_unchanged':True,
    'database_sha256':digest(db),'report_sha256':digest(report),
    'dashboard_screenshots_visually_inspected':True,'residual_task_server_and_browser_count':0})
save(ROOT/'git'/'final_commands.json',commands)
existing_commands=[]
for path in sorted(ROOT.rglob('command.json')):
    existing_commands.append({'artifact':str(path.relative_to(ROOT)),**json.loads(path.read_text())})
save(ROOT/'command_transcript.json',{'recorded_commands':existing_commands,'final_provenance_commands':commands,
    'runtime_commands':['dashboard/runtime.json','dashboard/browser_capture.json','dashboard/cdp_runtime.json','dashboard/native_capture.json'],
    'scope':'Executed test, ingestion, provenance, dependency, server, browser and cleanup commands; raw stdout/stderr alongside each recorded command.'})
print(json.dumps({'result':'final provenance PASS','localization_HEAD':primary['HEAD'],
    'parity':'PASS','main_and_07_clean':True,'isolated_uncommitted_files':CHANGED,
    'database_integrity':'PASS','original_P15_unchanged':True,'owned_runtime_residuals':0},indent=2))
