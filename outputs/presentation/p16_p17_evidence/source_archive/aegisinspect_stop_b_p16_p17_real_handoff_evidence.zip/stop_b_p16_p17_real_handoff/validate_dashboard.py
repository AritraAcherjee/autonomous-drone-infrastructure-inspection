"""Exercise actual Streamlit app data; browser screenshot is separately required."""
import os
import sys
from pathlib import Path
from evidence import ROOT, digest, save

source = Path('/tmp/aegis-stopb-p16p17.J0c6Zg/source')
sys.path.insert(0, str(source))
os.environ['AEGISINSPECT_DB_PATH'] = str(ROOT/'database'/'real_handoff.sqlite3')
from streamlit.testing.v1 import AppTest

before = digest(Path(os.environ['AEGISINSPECT_DB_PATH']))
app = AppTest.from_file(source/'dashboard'/'app.py', default_timeout=30).run()
assert not app.exception, str(app.exception)
markdown = [x.value for x in app.markdown]
captions = [x.value for x in app.caption]
infos = [x.value for x in app.info]
tables = [x.value.to_dict(orient='records') for x in app.dataframe]
text = '\n'.join(markdown+captions+infos)
assert 'P15D-10627c5f-3f84-5c64-ab2d-3e574b6e97ee' in text
assert '0.004553093574941158' in text and 'Honeycombing' in text and 'UNREVIEWED' in text
assert '1970-01-01T00:00:21.813000+00:00' in text
assert tables[0][0]['Confidence'] == '0.004553093574941158'
assert tables[0][0]['Frame'] == 'map' and tables[0][0]['Observations'] == 1
assert len(tables[0]) == len(tables[1]) == 1
assert not any(t in text for t in ['Confirmed Honeycombing', '**Severity:**', '**Dimensions:**', '**Safety classification:**'])
assert digest(Path(os.environ['AEGISINSPECT_DB_PATH'])) == before
save(ROOT/'dashboard'/'streamlit_render_data.json', {
    'result': 'PASS', 'exceptions': [], 'markdown': markdown, 'captions': captions,
    'information': infos, 'tables': tables, 'metrics': [{'label': x.label, 'value': x.value} for x in app.metric],
    'no_review_form_submitted': True, 'database_unchanged': True,
    'scope': 'AppTest validates real app rendering data; actual browser PNG separately required.'})
print('PASS: real Streamlit app loaded accepted SQLite record, exact confidence and timestamps, no review mutation.')
