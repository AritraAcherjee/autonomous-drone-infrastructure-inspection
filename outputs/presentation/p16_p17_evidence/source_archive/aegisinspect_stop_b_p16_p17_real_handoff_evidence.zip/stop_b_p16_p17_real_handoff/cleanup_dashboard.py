"""Stop only the exact dashboard child launched for this handoff."""
import json
import os
from pathlib import Path
import signal
import time
from evidence import ROOT, save, utc

runtime = json.loads((ROOT/'dashboard'/'runtime.json').read_text())
pid = runtime['pid']
cmdline = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
expected = [x.encode() for x in runtime['command']]
assert cmdline[:-1] == expected, (cmdline, expected)
result = {'pid':pid, 'cmdline_verified':True, 'signal':'SIGINT', 'shutdown_start_utc':utc()}
os.kill(pid, signal.SIGINT)
deadline = time.monotonic()+20
while Path(f'/proc/{pid}').exists() and time.monotonic()<deadline:
    time.sleep(.1)
result['end_utc'] = utc()
result['residual_dashboard_count'] = int(Path(f'/proc/{pid}').exists())
save(ROOT/'dashboard'/'cleanup_linux.json', result)
assert result['residual_dashboard_count'] == 0, result
print(result)
