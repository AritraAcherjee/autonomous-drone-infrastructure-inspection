"""Start only the existing P16 UI on loopback, with the real evidence database."""
import os
import subprocess
from evidence import ROOT, save, utc

source = '/tmp/aegis-stopb-p16p17.J0c6Zg/source'
command = ['/tmp/aegis-stopb-p16p17.J0c6Zg/venv/bin/python', '-B', '-m', 'streamlit', 'run',
           source+'/dashboard/app.py', '--server.address=127.0.0.1', '--server.port=8517',
           '--server.headless=true', '--server.fileWatcherType=none', '--browser.gatherUsageStats=false']
env = dict(os.environ, AEGISINSPECT_DB_PATH=str(ROOT/'database'/'real_handoff.sqlite3'))
with (ROOT/'dashboard'/'server_stdout.txt').open('wb') as stdout, (ROOT/'dashboard'/'server_stderr.txt').open('wb') as stderr:
    process = subprocess.Popen(command, cwd=source, env=env, stdout=stdout, stderr=stderr)
    metadata = {'command': command, 'cwd': source, 'AEGISINSPECT_DB_PATH': env['AEGISINSPECT_DB_PATH'],
                'pid': process.pid, 'ppid': os.getpid(), 'pgid': os.getpgid(process.pid),
                'sid': os.getsid(process.pid), 'start': utc(), 'bind': '127.0.0.1:8517'}
    save(ROOT/'dashboard'/'runtime.json', metadata)
    print(metadata, flush=True)
    metadata['exit_status'] = process.wait()
    metadata['end'] = utc()
    save(ROOT/'dashboard'/'runtime.json', metadata)
    print(metadata, flush=True)
