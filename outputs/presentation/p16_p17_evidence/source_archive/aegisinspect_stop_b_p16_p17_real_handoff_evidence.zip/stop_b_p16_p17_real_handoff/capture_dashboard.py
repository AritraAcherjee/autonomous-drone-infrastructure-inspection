"""Capture unaltered pixels and DOM from installed Chrome, isolated profile."""
import subprocess
import urllib.request
from evidence import ROOT, save, utc

url = 'http://localhost:8517'
with urllib.request.urlopen(url+'/_stcore/health', timeout=10) as response:
    health = response.read().decode()
assert health == 'ok', health
command = ['/mnt/c/Program Files/Google/Chrome/Application/chrome.exe',
    '--headless=new', '--no-first-run', '--no-default-browser-check',
    '--user-data-dir=C:\\Dev\\aegisinspect-07-vio\\outputs\\cache\\p16_p17_browser_profile',
    '--disable-gpu', '--hide-scrollbars', '--window-size=1920,2900', '--virtual-time-budget=20000',
    '--screenshot=C:\\Dev\\aegisinspect-07-vio\\outputs\\evidence\\stop_b_p16_p17_real_handoff\\dashboard\\real_dashboard.png',
    '--dump-dom', url]
started = utc()
with (ROOT/'dashboard'/'browser_dom.html').open('wb') as out, (ROOT/'dashboard'/'browser_stderr.txt').open('wb') as err:
    result = subprocess.run(command, stdout=out, stderr=err, timeout=55)
save(ROOT/'dashboard'/'browser_capture.json', {'command': command, 'start': started, 'end': utc(),
    'returncode': result.returncode, 'url': url, 'health': health, 'method': 'native Chrome headless screenshot; no image editing'})
dom = (ROOT/'dashboard'/'browser_dom.html').read_text(errors='replace')
checks = {key: key in dom for key in ['P15D-10627c5f-3f84-5c64-ab2d-3e574b6e97ee', '0.004553093574941158', 'Honeycombing', 'UNREVIEWED']}
save(ROOT/'dashboard'/'browser_dom_checks.json', checks)
print({'returncode': result.returncode, 'screenshot_exists': (ROOT/'dashboard'/'real_dashboard.png').is_file(), 'DOM': checks})
