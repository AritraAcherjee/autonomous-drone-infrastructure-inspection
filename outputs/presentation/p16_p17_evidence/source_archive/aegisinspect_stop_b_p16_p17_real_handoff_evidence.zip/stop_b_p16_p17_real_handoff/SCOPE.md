# Authorized real P15 -> P16 -> P17 handoff

Use only accepted mapped_defect.json and p16_handoff_dto.json, unchanged.
Preserved localization branch: 07/lidar-icp-fallback at independently verified
190bf7653b203c97418842474aa7cbd8016bfd44, equal to live origin.

Prove persistence, replay, real dashboard screenshot, deterministic report and
lineage. Extremely low confidence must remain explicit; no physical confirmation,
human review decision, engineering inference, severity, dimensions or safety claims.
Prefer existing code; only small non-scientific corrections preserving schemas and
upstream records are authorized. No original-evidence edit, scientific runtime,
START, RESET, localization/spatial change, merge to main or P18. Source corrections
remain uncommitted for 00. Tests may use clearly separate synthetic fixtures;
runtime handoff evidence must come only from the accepted real model observation.
