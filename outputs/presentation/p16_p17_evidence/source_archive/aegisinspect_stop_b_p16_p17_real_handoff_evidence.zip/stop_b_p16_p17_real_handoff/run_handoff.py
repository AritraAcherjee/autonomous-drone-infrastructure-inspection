"""Consume immutable accepted P15 DTO via P16, then read it through P17."""
from dataclasses import asdict, fields
from datetime import datetime
import json
from pathlib import Path
import shutil
import sqlite3
import sys

from evidence import ROOT, ACCEPTED, digest, save, utc

SOURCE = Path('/tmp/aegis-stopb-p16p17.J0c6Zg/source')
sys.path.insert(0, str(SOURCE))
from src.storage.models import StructureCreate, InspectionCreate, InspectionStatus, MappedDefectRecord, EvidenceCreate
from src.storage.service import InspectionService
from src.storage.repository import DuplicateDefectError, DuplicateEvidenceError
from src.integrations.p16_p17_adapter import build_inspection_report
from src.reporting.rendering import render_report
from dashboard.components import defect_table_rows, evidence_table_rows

def main():
    for name in ['input', 'database', 'dashboard', 'report', 'provenance', 'tests', 'git']:
        (ROOT/name).mkdir(exist_ok=True)
    accepted = ACCEPTED/'corrected_capture'
    originals = {}
    for filename in ['mapped_defect.json', 'p16_handoff_dto.json']:
        path = accepted/filename
        copied = ROOT/'input'/filename
        assert not copied.exists(), f'Refusing to overwrite {copied}'
        shutil.copyfile(path, copied)
        assert digest(path) == digest(copied)
        originals[str(path)] = digest(path)
    mapped = json.loads((accepted/'mapped_defect.json').read_text())
    dto = json.loads((accepted/'p16_handoff_dto.json').read_text())
    record_data = dict(dto['defect_record'])
    p15 = mapped['P15_record']
    assert record_data['defect_id'] == 'P15D-10627c5f-3f84-5c64-ab2d-3e574b6e97ee'
    for key in record_data:
        if key in ['first_seen', 'last_seen']:
            assert datetime.fromisoformat(record_data[key]) == datetime.fromisoformat(p15[key])
        elif key == 'track_id':
            assert record_data[key] == p15['canonical_track_id']
        else:
            assert record_data[key] == p15[key], key
    assert record_data['class_name'] == 'Honeycombing'
    assert record_data['confidence'] == 0.004553093574941158
    assert record_data['coordinate_frame'] == 'map' and record_data['observation_count'] == 1
    assert mapped['map_projection']['stamp_ns'] == mapped['map_projection']['transform_stamp_ns'] == 21813000000
    for key in ['first_seen', 'last_seen']:
        record_data[key] = datetime.fromisoformat(record_data[key])
    record = MappedDefectRecord(**record_data)
    evidence_inputs = []
    for item in dto['evidence']:
        item = dict(item)
        item['timestamp'] = datetime.fromisoformat(item['timestamp'])
        assert Path(item['image_path']).is_file()
        evidence_inputs.append(EvidenceCreate(**item))
    assert len(evidence_inputs) == 1
    db = ROOT/'database'/'real_handoff.sqlite3'
    assert not db.exists(), 'Refusing to rerun or replace the real database'
    service = InspectionService.from_database_path(db)
    service.initialize()
    structure = service.create_structure(StructureCreate(
        name='Stop-B inspection_bay simulation session',
        description='Evidence-session container for the accepted real DET-FINAL-v1 model observation from simulated RGB-D; not a surveyed physical structure.',
        location_text=None))
    invocation = json.loads((accepted/'runtime_invocation.json').read_text())
    notes = (
        'Detector classification: Honeycombing. Detector confidence: 0.004553093574941158. '
        'Extremely low confidence; unreviewed machine output, not physical defect confirmation or an engineering/safety conclusion. '
        'Coordinates are metric in a session-local map, not globally drift-corrected. '
        'First/last seen and evidence time encode ROS simulation 21.813 s as 1970-01-01T00:00:21.813000Z; this is not wall-clock capture time. '
        'Inspection started_at records the accepted runtime invocation UTC; no completed_at is asserted.'
    )
    inspection = service.create_inspection(InspectionCreate(
        structure_id=structure.structure_id,
        started_at=datetime.fromisoformat(invocation['utc']), completed_at=None,
        status=InspectionStatus.PROCESSING,
        system_version='P15 190bf7653b203c97418842474aa7cbd8016bfd44; P17 66d33acd00704d2f79b157471702e3709ce9d716 + scoped P16 boundary corrections',
        notes=notes), inspection_id=record.inspection_id)
    before_insert = len(service.list_inspection_defects(record.inspection_id))
    inserted = service.ingest_mapped_defect(record)
    inserted_evidence = [service.add_evidence(item) for item in evidence_inputs]
    saved = service.get_defect(record.defect_id)
    for field in fields(record):
        assert getattr(saved, field.name) == getattr(record, field.name), field.name
    for stored, source in zip(service.list_evidence(record.defect_id), evidence_inputs):
        for field in fields(source):
            assert getattr(stored, field.name) == getattr(source, field.name), field.name
    assert saved.review_status.value == 'UNREVIEWED' and saved.review_notes is None
    before_replay = len(service.list_inspection_defects(record.inspection_id))
    try:
        service.ingest_mapped_defect(record)
    except DuplicateDefectError as exc:
        duplicate = {'type': type(exc).__name__, 'message': str(exc)}
    else:
        raise AssertionError('Replay unexpectedly inserted a second defect')
    try:
        service.add_evidence(evidence_inputs[0])
    except DuplicateEvidenceError as exc:
        duplicate_evidence = {'type': type(exc).__name__, 'message': str(exc)}
    else:
        raise AssertionError('Replay unexpectedly inserted second evidence')
    after_replay = len(service.list_inspection_defects(record.inspection_id))
    assert before_insert == 0 and before_replay == after_replay == 1
    assert saved == service.get_defect(record.defect_id)
    assert inserted_evidence == service.list_evidence(record.defect_id)
    save(ROOT/'database'/'persisted_record.json', asdict(saved))
    save(ROOT/'database'/'persisted_evidence.json', [asdict(x) for x in inserted_evidence])
    save(ROOT/'database'/'inspection_container.json', {'structure': asdict(structure), 'inspection': asdict(inspection), 'source': str(accepted/'runtime_invocation.json')})
    save(ROOT/'database'/'replay.json', {
        'record_count_before_insert': before_insert, 'record_count_before': before_replay,
        'record_count_after': after_replay, 'duplicate_replay_disposition': duplicate,
        'evidence_replay_disposition': duplicate_evidence, 'evidence_count_after': len(inserted_evidence),
        'final_observation_count': saved.observation_count, 'first_seen': saved.first_seen,
        'last_seen': saved.last_seen, 'all_fields_unchanged': True,
        'contract': 'Create-only ingestion rejects duplicates; it does not merge or increment on replay.'})
    with sqlite3.connect(db) as connection:
        schema = connection.execute("SELECT type,name,sql FROM sqlite_master ORDER BY type,name").fetchall()
        metadata = {'engine': 'SQLite', 'sqlite_version': sqlite3.sqlite_version,
                    'path': str(db), 'user_version': connection.execute('PRAGMA user_version').fetchone()[0],
                    'integrity_check': connection.execute('PRAGMA integrity_check').fetchall(),
                    'foreign_key_check': connection.execute('PRAGMA foreign_key_check').fetchall(),
                    'schema': schema, 'schema_source_sha256': digest(SOURCE/'database/schema.sql')}
        (ROOT/'database'/'safe_export.sql').write_text('\n'.join(connection.iterdump())+'\n')
    assert metadata['integrity_check'] == [('ok',)] and not metadata['foreign_key_check']
    save(ROOT/'database'/'metadata.json', metadata)
    initial_db_hash = digest(db)
    report_model = build_inspection_report(service, record.inspection_id)
    report = render_report(report_model)
    report_repeat = render_report(build_inspection_report(service, record.inspection_id))
    assert report == report_repeat and digest(db) == initial_db_hash
    assert repr(record.confidence) in report and '1970-01-01T00:00:21.813000Z' in report
    assert 'Confirmed Honeycombing' not in report
    for name in ['Severity', 'Dimensions', 'Repair recommendation', 'Safety classification']:
        assert not any(line.lower().startswith(f'- {name.lower()}:') for line in report.splitlines())
    report_path = ROOT/'report'/'inspection_2026091901.md'
    report_path.write_text(report)
    save(ROOT/'report'/'report_model.json', asdict(report_model))
    save(ROOT/'report'/'determinism.json', {'two_independent_reads_equal': True, 'database_unchanged_by_reporting': True,
        'renderer': 'src.reporting.rendering.render_report', 'adapter': 'src.integrations.p16_p17_adapter.build_inspection_report',
        'sha256': digest(report_path), 'unsupported_fields_absent': True})
    save(ROOT/'dashboard'/'displayed_record_data.json', {
        'defects': defect_table_rows([saved]), 'evidence': evidence_table_rows(inserted_evidence),
        'detail_record': asdict(saved), 'human_review_submitted': False})
    depth = json.loads((accepted/'depth_provenance.json').read_text())
    shutil.copyfile(accepted/'depth_provenance.json', ROOT/'provenance'/'depth_provenance.json')
    image = Path(mapped['image_path'])
    shutil.copyfile(image, ROOT/'input'/image.name)
    lineage = {
        'created_utc': utc(), 'accepted_inputs': originals,
        'accepted_manifest_sha256': digest(ACCEPTED/'SHA256SUMS.txt'),
        'localization_preservation_sha': '190bf7653b203c97418842474aa7cbd8016bfd44',
        'reporting_base_sha': '66d33acd00704d2f79b157471702e3709ce9d716',
        'detector': mapped['checkpoint'], 'detection': mapped['detection'],
        'source_image': {'path': str(image), 'sha256': digest(image), 'copy': str(ROOT/'input'/image.name)},
        'depth': depth, 'camera_to_map': mapped['map_projection'], 'tf_chain': mapped['tf_chain'],
        'source_timestamp_semantics': mapped['timestamp_domain'],
        'P15': mapped['P15_record'], 'P16': {'database': str(db), 'defect_id': saved.defect_id,
            'inspection_id': saved.inspection_id, 'evidence_ids': [x.evidence_id for x in inserted_evidence]},
        'P17': {'path': str(report_path), 'sha256': digest(report_path), 'defect_id': report_model.defects[0].defect_id},
        'NO_UNEXPLAINED_IDENTITY_SUBSTITUTION': True,
        'GT_OPERATIONAL_USE': mapped['GT_OPERATIONAL_USE'],
        'no_scientific_runtime_started_this_task': True,
    }
    save(ROOT/'provenance'/'lineage.json', lineage)
    save(ROOT/'input'/'validation.json', {'accepted_inputs_copied_byte_for_byte': True,
        'all_DTO_fields_equal_to_P15': True, 'all_persisted_DTO_fields_equal': True,
        'timestamp_fraction_preserved': True, 'evidence_path_resolves': True,
        'inspection_id_preserved': record.inspection_id, 'review_status': saved.review_status.value,
        'confidence': saved.confidence, 'map_xyz': [saved.x_m, saved.y_m, saved.z_m]})
    print(json.dumps({'result': 'P16 persistence/replay and P17 deterministic rendering PASS',
                      'defect_id': saved.defect_id, 'database': str(db), 'report': str(report_path)}, indent=2))

if __name__ == '__main__': main()
