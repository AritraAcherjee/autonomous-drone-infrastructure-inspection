"""Seal every artifact, verify, then verify again including verification metadata."""
import subprocess
from evidence import ROOT, digest, save, utc

manifest=ROOT/'SHA256SUMS.txt'
verification=ROOT/'manifest_verification.json'
assert not manifest.exists() and not verification.exists(), 'Evidence already sealed'
def write_manifest():
    files=sorted(path for path in ROOT.rglob('*') if path.is_file() and path!=manifest)
    assert all(not path.is_symlink() for path in files)
    manifest.write_text(''.join(f'{digest(path)}  {path.relative_to(ROOT).as_posix()}\n' for path in files))
    return len(files)
def verify():
    result=subprocess.run(['sha256sum','--check','--quiet','SHA256SUMS.txt'],cwd=ROOT,capture_output=True,text=True)
    assert result.returncode==0, (result.stdout,result.stderr)
    return result
first_count=write_manifest()
verify()
save(verification, {'algorithm':'SHA-256','command':['sha256sum','--check','--quiet','SHA256SUMS.txt'],
    'cwd':str(ROOT),'result':'PASS','bootstrap_artifact_count':first_count,
    'final_artifact_count':first_count+1,'verification_metadata_included_in_final_manifest':True,
    'manifest_itself_excluded':True,'utc':utc(),
    'procedure':'Bootstrap check passed; final manifest includes this metadata and is rechecked without modifying any hashed artifact.'})
final_count=write_manifest()
assert final_count==first_count+1
verify()
print(f'FINAL MANIFEST PASS: {final_count} artifacts; SHA256SUMS.txt SHA256={digest(manifest)}')
