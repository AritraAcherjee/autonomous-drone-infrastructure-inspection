"""Bookkeeping for the authorized P16/P17 handoff; no localization runtime."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
ACCEPTED=ROOT.parent/'stop_b_map_frame_spatial_chain'
def utc(): return datetime.now(timezone.utc).isoformat()
def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2,default=lambda x:x.isoformat())+'\n')
def digest(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
def record(label,argv):
    dest=ROOT/label
    dest.mkdir(parents=True,exist_ok=False)
    start=utc()
    with (dest/'stdout.txt').open('wb') as out,(dest/'stderr.txt').open('wb') as err:
        proc=subprocess.run(argv,cwd=REPO,stdout=out,stderr=err)
    save(dest/'command.json',{'argv':argv,'cwd':str(REPO),'start':start,'end':utc(),'returncode':proc.returncode})
    print((dest/'stdout.txt').read_text(errors='replace'),end='')
    print((dest/'stderr.txt').read_text(errors='replace'),end='',file=sys.stderr)
    return proc.returncode
if __name__=='__main__':
    if sys.argv[1]=='record': raise SystemExit(record(sys.argv[2],sys.argv[3:]))
