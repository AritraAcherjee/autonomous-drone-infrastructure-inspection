$ErrorActionPreference = 'Stop'
$evidenceRoot = 'C:\Dev\aegisinspect-07-vio\outputs\evidence\stop_b_p16_p17_real_handoff\dashboard'
$taskProcesses = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -eq 'chrome.exe' -and $_.CommandLine -like '*p16_p17_browser_profile*'
})
$taskProcesses | Select-Object ProcessId,ParentProcessId,CreationDate,CommandLine |
    ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 "$evidenceRoot\windows_browser_processes.json"
$owners = @($taskProcesses | Where-Object { $_.CommandLine -like '*--remote-debugging-port=9227*' -and $_.CommandLine -notlike '*--type=*' })
if ($owners.Count -ne 1) { throw 'Ambiguous task-isolated browser identity' }
$tabs = Invoke-RestMethod 'http://127.0.0.1:9227/json/list'
$tab = @($tabs | Where-Object { $_.type -eq 'page' })
if ($tab.Count -ne 1) { throw 'Ambiguous task-isolated browser tab' }
$socket = [System.Net.WebSockets.ClientWebSocket]::new()
$socket.ConnectAsync([Uri]$tab[0].webSocketDebuggerUrl, [Threading.CancellationToken]::None).GetAwaiter().GetResult()
$script:sequence = 0
$script:events = [Collections.Generic.List[object]]::new()

function Send-CDP([string]$method, [hashtable]$parameters = @{}, [bool]$wait = $true) {
    $script:sequence += 1
    $payload = @{id=$script:sequence; method=$method; params=$parameters} | ConvertTo-Json -Compress -Depth 20
    $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
    $segment = [ArraySegment[byte]]::new($bytes)
    $token = [Threading.CancellationTokenSource]::new(20000)
    try {
        $socket.SendAsync($segment, [Net.WebSockets.WebSocketMessageType]::Text, $true, $token.Token).GetAwaiter().GetResult()
        if (-not $wait) { return }
        while ($true) {
            $buffer = [byte[]]::new(65536)
            $memory = [IO.MemoryStream]::new()
            do {
                $received = $socket.ReceiveAsync([ArraySegment[byte]]::new($buffer), $token.Token).GetAwaiter().GetResult()
                if ($received.MessageType -eq [Net.WebSockets.WebSocketMessageType]::Close) { throw 'Browser closed unexpectedly' }
                $memory.Write($buffer,0,$received.Count)
            } while (-not $received.EndOfMessage)
            $message = [Text.Encoding]::UTF8.GetString($memory.ToArray()) | ConvertFrom-Json
            $memory.Dispose()
            if ($message.id -eq $script:sequence) {
                if ($message.error) { throw ($message.error | ConvertTo-Json) }
                return $message.result
            }
            if ($message.method -in @('Runtime.exceptionThrown','Network.webSocketCreated','Network.webSocketFrameError','Network.loadingFailed')) {
                $script:events.Add($message)
            }
        }
    } finally { $token.Dispose() }
}

$capture = @{start=[DateTime]::UtcNow.ToString('o'); process_id=$owners[0].ProcessId; command=$owners[0].CommandLine; endpoint=$tab[0].webSocketDebuggerUrl}
try {
    $null = Send-CDP 'Page.enable'
    $null = Send-CDP 'Runtime.enable'
    $null = Send-CDP 'Network.enable'
    $capture.browser_version = Send-CDP 'Browser.getVersion'
    $null = Send-CDP 'Emulation.setDeviceMetricsOverride' @{width=1920;height=1600;deviceScaleFactor=1;mobile=$false}
    $null = Send-CDP 'Page.navigate' @{url='http://localhost:8517'}
    $required = @('P15D-10627c5f-3f84-5c64-ab2d-3e574b6e97ee','0.004553093574941158','Honeycombing','UNREVIEWED','21.813000')
    $deadline = [DateTime]::UtcNow.AddSeconds(40)
    do {
        $result = Send-CDP 'Runtime.evaluate' @{expression='document.body.innerText';returnByValue=$true}
        $body = $result.result.value
        $missing = @($required | Where-Object { -not $body.Contains($_) })
        if ($missing.Count -eq 0) { break }
        Start-Sleep -Milliseconds 500
    } while ([DateTime]::UtcNow -lt $deadline)
    [IO.File]::WriteAllText("$evidenceRoot\native_browser_text.txt", $body)
    if ($missing.Count -ne 0) { throw "Dashboard readiness failed: $missing" }
    $null = Send-CDP 'Runtime.evaluate' @{expression='document.fonts.ready';awaitPromise=$true}
    $dom = Send-CDP 'Runtime.evaluate' @{expression='document.documentElement.outerHTML';returnByValue=$true}
    [IO.File]::WriteAllText("$evidenceRoot\native_browser_dom.html", $dom.result.value)
    $pixels = Send-CDP 'Page.captureScreenshot' @{format='png';captureBeyondViewport=$true;fromSurface=$true}
    [IO.File]::WriteAllBytes("$evidenceRoot\dashboard_overview.png", [Convert]::FromBase64String($pixels.data))
    $null = Send-CDP 'Runtime.evaluate' @{expression="document.querySelector('[data-testid=stMain]').scrollTop = 750";returnByValue=$true}
    $null = Send-CDP 'Runtime.evaluate' @{expression='new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))';awaitPromise=$true}
    $pixels = Send-CDP 'Page.captureScreenshot' @{format='png';captureBeyondViewport=$true;fromSurface=$true}
    [IO.File]::WriteAllBytes("$evidenceRoot\dashboard_detail.png", [Convert]::FromBase64String($pixels.data))
    $capture.ready = $true
    $capture.required_text_present = $required
    $capture.method = 'Unedited Chrome Page.captureScreenshot after exact record text readiness; ordinary viewport scrolling only'
    $capture.screenshots = @('dashboard_overview.png','dashboard_detail.png')
    $capture.no_review_form_submitted = $true
} finally {
    $capture.events = @($script:events.ToArray())
    $capture.end = [DateTime]::UtcNow.ToString('o')
    try { $null = Send-CDP 'Browser.close' @{} $false } catch { $capture.close_error = $_.ToString() }
    $socket.Dispose()
    $capture | ConvertTo-Json -Depth 20 | Set-Content -Encoding UTF8 "$evidenceRoot\native_capture.json"
}
$capture | ConvertTo-Json -Depth 10
